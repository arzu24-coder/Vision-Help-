from fastapi import APIRouter, Depends, HTTPException
from app.database.schemas import UserCreate, UserOut
from app.database.models import User
from app.database.crud import create_user, get_user_by_email
from .jwt_handler import create_token
from app.database.__init__ import get_database

router = APIRouter(prefix="/auth", tags=["Auth"])

@router.post("/register")
async def register(user: UserCreate, db=Depends(get_database)):
    existing = await get_user_by_email(db, user.email)
    if existing:
        raise HTTPException(status_code=400, detail="Email exists")
    user_data = user.dict()
    user_id = await create_user(db, user_data)
    return {"id": user_id, "msg": "User registered"}

@router.post("/login")
async def login(user: UserCreate, db=Depends(get_database)):
    existing = await get_user_by_email(db, user.email)
    if not existing or existing["role"] != user.role:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_token(str(existing["_id"]), existing["role"])
    return {"access_token": token, "token_type": "bearer"}
