from fastapi import Header, HTTPException, Depends, Request, status
from typing import Optional
from app.database.__init__ import get_database
from .jwt_handler import decode_token

# Admin email configuration
ADMIN_EMAIL = "arzumehreen050@gmail.com"


    # Fallback if admin_config is not available
ADMIN_ROLES = ["admin", "super_admin", "moderator"]
def is_super_admin(email: str) -> bool:
    return email.lower() == ADMIN_EMAIL.lower()
def is_admin_role(role: str) -> bool:
    return role.lower() in [r.lower() for r in ADMIN_ROLES]
def is_admin(email: str = None, role: str = None) -> bool:
    if email and is_super_admin(email):
            return True
    if role and is_admin_role(role):
            return True
    return False

async def get_current_user(authorization: Optional[str] = Header(None), db=Depends(get_database)):
    # Debugging log for Authorization header
    print(f"Authorization header received: {authorization}")

    if not authorization:
        print("Authorization header is missing.")  # Debugging log
        raise HTTPException(status_code=401, detail="Authorization header missing. Please provide Bearer token.")

    if not authorization.startswith("Bearer "):
        print("Invalid Authorization header format.")  # Debugging log
        raise HTTPException(status_code=401, detail="Invalid Authorization header format. Expected 'Bearer <token>'.")

    token = authorization.replace("Bearer ", "").strip()
    try:
        # Decode the token to extract user information
        user_data = decode_token(token)
        print(f"Decoded token data: {user_data}")  # Debugging log for token data

        user_id = user_data.get("user_id")
        if not user_id:
            print("Token is missing user_id.")  # Debugging log
            raise HTTPException(status_code=401, detail="Invalid token: Missing user_id.")

        # Fetch user data from the vision_users collection
        user = await db["vision_users"].find_one({"_id": user_id})
        if not user:
            print(f"User with user_id {user_id} not found in the database.")  # Debugging log
            raise HTTPException(status_code=401, detail="User not found in the database.")

        # Debugging log for user data
        print(f"User found in database: {user}")

        # Return the user data
        return {
            "user_id": str(user["_id"]),  # Ensure user_id is a string
            "email": user["email"],
            "role": user["role"],
            "is_employer": user.get("is_employer", False),
            "name": user.get("name", ""),
        }
    except Exception as e:
        print(f"Error during token validation: {str(e)}")  # Debugging log for errors
        raise HTTPException(status_code=401, detail=f"Invalid token: {str(e)}")

async def get_current_admin_user(request: Request):
    user = await get_current_user(request)
    
    # Check if user is super admin by email
    user_email = user.get("sub") or user.get("email")
    if is_super_admin(user_email):
        return user
    
    # Check if user has admin role
    user_role = user.get("role", "").lower()
    if not is_admin_role(user_role):
        raise HTTPException(
            status_code=403, 
            detail=f"Admin access required. Current role: '{user_role}'. Only admins or {ADMIN_EMAIL} can access this."
        )
    
    return user

def require_admin():
    return Depends(get_current_admin_user)

def require_admin_or_role(allowed_roles: list):
    async def role_checker(user=Depends(get_current_user)):
        user_email = user.get("sub") or user.get("email")
        user_role = user.get("role", "").lower()
        
        # Super admin always has access
        if is_super_admin(user_email):
            return user
            
        # Check if user has admin role or one of the allowed roles
        if not (is_admin_role(user_role) or user_role in [role.lower() for role in allowed_roles]):
            raise HTTPException(
                status_code=403, 
                detail=f"Access denied. Required roles: {allowed_roles} or admin, but user has role: '{user_role}'"
            )
        return user
    return role_checker

def require_super_admin():
    async def super_admin_checker(user=Depends(get_current_user)):
        user_email = user.get("sub") or user.get("email")
        if not is_super_admin(user_email):
            raise HTTPException(
                status_code=403,
                detail=f"Super admin access required. Only {ADMIN_EMAIL} can access this."
            )
        return user
    return super_admin_checker

# Alternative simpler approach - create direct dependency functions
async def get_current_super_admin_user(user=Depends(get_current_user)):
    user_email = user.get("sub") or user.get("email")
    if not is_super_admin(user_email):
        raise HTTPException(
            status_code=403,
            detail=f"Super admin access required. Only {ADMIN_EMAIL} can access this."
        )
    return user

def require_role(role: str):
    async def role_checker(user = Depends(get_current_user)):
        if role == "admin" and user.get("sub") == ADMIN_EMAIL:
            return user
        if user.get("role") != role and user.get("sub") != ADMIN_EMAIL:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Only {role} or admin can access this resource"
            )
        return user
    return role_checker

async def is_admin(user: dict, db) -> bool:
    if not user:
        return False
        
    # Get user email - handle different auth providers that might use different fields
    email = user.get("email") or user.get("sub") or ""
    
    # Log the email being checked (temporary for debugging)
    print(f"Checking admin access for: {email}")
    
    # Admin emails - add your email here
    admin_emails = ["arzumehreen050@gmail.com", "admin@visionhelp.org"]
    
    # Direct check for hardcoded admin emails first (faster)
    if email.lower() in [admin_email.lower() for admin_email in admin_emails]:
        return True
    
    # If not in hardcoded list, check database
    if db and email:
        try:
            user_doc = await db.vision_users.find_one({"email": email.lower()})
            if user_doc and user_doc.get("role") in ["admin", "superadmin"]:
                return True
        except Exception as e:
            print(f"Error checking admin in database: {str(e)}")
    
    return False
    print(f"Checking admin access for: {email}")
    
    # Admin emails - add your email here
    admin_emails = ["arzumehreen050@gmail.com", "admin@visionhelp.org"]
    
    # Direct check for hardcoded admin emails first (faster)
    if email.lower() in [admin_email.lower() for admin_email in admin_emails]:
        return True
    
    # If not in hardcoded list, check database
    if db and email:
        try:
            user_doc = await db.vision_users.find_one({"email": email.lower()})
            if user_doc and user_doc.get("role") in ["admin", "superadmin"]:
                return True
        except Exception as e:
            print(f"Error checking admin in database: {str(e)}")
    
    return False
