from jose import jwt, JWTError
from jose.exceptions import ExpiredSignatureError, JWTClaimsError
from datetime import datetime, timedelta
from fastapi.security import OAuth2PasswordBearer  # Import OAuth2PasswordBearer

SECRET_KEY = "iLPceCf3HeWJzcFHwdOJkroxwAxDGazIrolBLMymCAo"  # ✅ Match auth_utils.py
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_HOURS = 24

# Define oauth2_scheme for token-based authentication
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")

def create_access_token(data: dict, expires_delta: timedelta = None) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(hours=ACCESS_TOKEN_EXPIRE_HOURS))
    to_encode.update({"exp": expire})

    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

# -------------------------------
# 2️⃣ Decode & Verify Token
# -------------------------------
def decode_token(token: str) -> dict:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")
    except Exception as e:
        raise HTTPException(status_code=401, detail=f"Token decode failed: {str(e)}")

def verify_token_info(token: str):
    try:
        verified = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return {"status": "valid", "payload": verified}
    except ExpiredSignatureError:
        return {"status": "expired", "message": "Token expired"}
    except JWTError as e:
        return {"status": "invalid", "message": str(e)}
    except Exception as e:
        return {"status": "error", "message": str(e)}
