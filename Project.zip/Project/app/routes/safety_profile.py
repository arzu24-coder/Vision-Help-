from fastapi import APIRouter, HTTPException, Depends, Header
from typing import List, Optional
from datetime import datetime
from motor.motor_asyncio import AsyncIOMotorDatabase
from bson import ObjectId

from app.database.__init__ import get_database
from app.database.models.safety_profile import SafetyProfileDB, SafetyTaskDB, SafetySOSDB
from app.database.schemas.safety_profile import (
    SafetyProfileCreate,
    SafetyProfileUpdate,
    SafetyProfileOut,
    TaskCreate,
    TaskResponse,
    SOSCreate,
    SOSResponse,
)
from app.auth.deps import get_current_user
from app.database.crud.safety_profile import check_safety_access, process_family_members

router = APIRouter(prefix="/safety", tags=["Safety Profiles"])

# ---------------- PROFILE ROUTES ----------------
@router.post("/profiles", response_model=SafetyProfileOut)
async def create_profile(
    profile: SafetyProfileCreate, 
    db: AsyncIOMotorDatabase = Depends(get_database),
    current_user: dict = Depends(get_current_user)
):
    user_id = current_user.get("user_id")
    if not user_id:
        raise HTTPException(status_code=401, detail="Authentication required")
    
    # Check if profile already exists for this user
    existing_profile = await db["safety_profiles"].find_one({"user_id": user_id})
    if existing_profile:
        raise HTTPException(status_code=400, detail="Safety profile already exists for this user")
    
    # Convert profile to dict and prepare data
    profile_dict = profile.dict()
    
    # Process safe zones to match expected format
    safe_zones = profile_dict.get("safe_zones", [])
    
    # Process family members - ensure they exist in the users collection
    from app.database.crud.safety_profile import process_family_members
    family_members = await process_family_members(profile_dict.get("family_members", []), db)
    
    # Add the admin as a family member with admin role if not already present
    admin_email = "arzumehreen050@gmail.com"
    admin_in_family = any(member.get("email") == admin_email for member in family_members)
    
    if not admin_in_family:
        # Find or create admin user
        admin_user = await db["vision_users"].find_one({"email": admin_email})
        if admin_user:
            admin_member = {
                "email": admin_email,
                "role": "admin",
                "user_id": str(admin_user["_id"])
            }
        else:
            # Create a placeholder admin user if not found
            admin_id = str(ObjectId())
            admin_member = {
                "email": admin_email,
                "role": "admin",
                "user_id": admin_id
            }
        
        family_members.append(admin_member)
    
    # Create the complete profile document
    profile_data = {
        "user_id": user_id,
        "emergency_contacts": profile_dict.get("emergency_contacts", []),
        "safe_zones": safe_zones,
        "family_visibility": profile_dict.get("family_visibility", True),
        "admin_visibility": True,  # Always allow admin visibility for safety reasons
        "family_members": family_members,
        "is_active": True,
        "created_at": datetime.now(),
        "updated_at": datetime.now()  # Set updated_at to created_at initially
    }
    
    # Set special admin status if needed
    if current_user.get("sub") == admin_email:
        profile_data["is_admin_profile"] = True
    
    result = await db["safety_profiles"].insert_one(profile_data)
    profile_data["id"] = str(result.inserted_id)
    
    return profile_data


@router.get("/profiles", response_model=List[SafetyProfileOut])
async def get_profiles(
    db: AsyncIOMotorDatabase = Depends(get_database),
    current_user: dict = Depends(get_current_user)
):
    user_id = current_user.get("user_id")
    user_email = current_user.get("sub")
    
    # If admin, return profiles with admin_visibility=True
    if user_email == "arzumehreen050@gmail.com":
        profiles = await db["safety_profiles"].find({"admin_visibility": True}).to_list(100)
    else:
        # For regular users, return their own profile
        own_profile_query = {"user_id": user_id}
        
        # Also check family visibility by email in family_members list
        family_access_query = {
            "family_visibility": True,
            "family_members.email": user_email
        }
        
        profiles = await db["safety_profiles"].find({
            "$or": [own_profile_query, family_access_query]
        }).to_list(100)
    
    # Convert _id to id for each profile
    for profile in profiles:
        profile["id"] = str(profile["_id"])
        
    return profiles


@router.get("/profiles/{profile_id}", response_model=SafetyProfileOut)
async def get_profile(
    profile_id: str,
    db: AsyncIOMotorDatabase = Depends(get_database),
    current_user: dict = Depends(get_current_user)
):
    user_id = current_user.get("user_id")
    user_email = current_user.get("sub")
    
    # Get the profile - first try by profile ID
    profile = await db["safety_profiles"].find_one({"_id": ObjectId(profile_id)})
    
    # If not found, try by user_id
    if not profile:
        profile = await db["safety_profiles"].find_one({"user_id": profile_id})
    
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    
    # Check access permissions
    has_access = False
    
    # 1. Profile owner can always access their own profile
    if profile["user_id"] == user_id:
        has_access = True
    
    # 2. Admin can access if admin_visibility is true
    elif user_email == "arzumehreen050@gmail.com" and profile.get("admin_visibility", True):
        has_access = True
    
    # 3. Family members can access if family_visibility is true and email matches
    elif profile.get("family_visibility", True):
        for member in profile.get("family_members", []):
            if isinstance(member, dict) and member.get("email") == user_email:
                has_access = True
                break
    
    if not has_access:
        raise HTTPException(status_code=403, detail="You don't have permission to view this safety profile")
    
    # Convert _id to id
    profile["id"] = str(profile["_id"])
    
    # Ensure updated_at is never null in response
    if profile.get("updated_at") is None:
        profile["updated_at"] = profile.get("created_at")
    
    return profile


@router.put("/profiles/{profile_id}", response_model=SafetyProfileOut)
async def update_profile(
    profile_id: str, 
    profile_update: SafetyProfileUpdate, 
    db: AsyncIOMotorDatabase = Depends(get_database),
    current_user: dict = Depends(get_current_user)
):
    user_id = current_user.get("user_id")
    user_email = current_user.get("sub")
    
    # First try by profile ID (ObjectId)
    try:
        profile_object_id = ObjectId(profile_id)
        existing_profile = await db["safety_profiles"].find_one({"_id": profile_object_id})
    except:
        existing_profile = None
    
    # If not found, try by user_id
    if not existing_profile:
        existing_profile = await db["safety_profiles"].find_one({"user_id": profile_id})
    
    if not existing_profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    
    # Store the profile's user_id for permission checks
    profile_user_id = existing_profile["user_id"]
    
    # Check permission to update
    if user_id != profile_user_id and user_email != "arzumehreen050@gmail.com":
        raise HTTPException(status_code=403, detail="You don't have permission to update this safety profile")
    
    # Convert update data to dict and filter out None values
    update_data = {k: v for k, v in profile_update.dict(exclude_unset=True).items() if v is not None}
    
    # Special handling for admin - they can update all fields
    if user_email != "arzumehreen050@gmail.com":
        # Regular users can't modify admin_visibility
        if "admin_visibility" in update_data:
            del update_data["admin_visibility"]
    
    # Always set updated_at timestamp to current time
    update_data["updated_at"] = datetime.now()
    
    # Find which ID to use for the update
    update_filter = {"_id": existing_profile["_id"]}
    
    # Perform the update
    result = await db["safety_profiles"].find_one_and_update(
        update_filter,
        {"$set": update_data},
        return_document=True
    )

    if not result:
        raise HTTPException(status_code=404, detail="Profile update failed")

    # Make sure id is present in the response
    result["id"] = str(result["_id"])
    
    return result


@router.post("/profiles/{profile_id}/family", response_model=SafetyProfileOut)
async def add_family_member(
    profile_id: str,
    family_member: dict,  # Changed from family_member_id to accept a family member object
    db: AsyncIOMotorDatabase = Depends(get_database),
    current_user: dict = Depends(get_current_user)
):
    user_id = current_user.get("user_id")
    user_email = current_user.get("sub")
    
    # Get the profile
    try:
        profile_object_id = ObjectId(profile_id)
        profile = await db["safety_profiles"].find_one({"_id": profile_object_id})
    except:
        profile = await db["safety_profiles"].find_one({"user_id": profile_id})
    
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    
    # Check if user is authorized to add family members
    if profile["user_id"] != user_id and user_email != "arzumehreen050@gmail.com":
        raise HTTPException(status_code=403, detail="Only profile owner or admin can add family members")
    
    # Validate family member data
    if not isinstance(family_member, dict) or "email" not in family_member:
        raise HTTPException(status_code=400, detail="Family member must have an email")
    
    # Set default role if not provided
    if "role" not in family_member:
        family_member["role"] = "viewer"
    
    # Process and add the family member
    from app.database.crud.safety_profile import add_family_member_to_profile
    result = await add_family_member_to_profile(
        profile_id if isinstance(profile_id, str) else str(profile_id),
        family_member,
        db
    )
    
    if not result:
        raise HTTPException(status_code=500, detail="Failed to add family member")
    
    # Convert _id to id for the response
    result["id"] = str(result["_id"])
    
    # Ensure updated_at is never null in response
    if result.get("updated_at") is None:
        result["updated_at"] = result.get("created_at")
    
    return result


# ---------------- SAFETY TASK ROUTES ----------------
@router.post("/tasks", response_model=TaskResponse)
async def create_task(
    task: TaskCreate, 
    db: AsyncIOMotorDatabase = Depends(get_database),
    current_user: dict = Depends(get_current_user)
):
    user_id = current_user.get("user_id")
    
    # Check if profile exists
    profile = await db["safety_profiles"].find_one({"user_id": user_id})
    if not profile:
        raise HTTPException(status_code=404, detail="Safety profile not found. Please create a profile first.")
    
    # Create new task with proper handling for optional fields
    new_task = {
        "user_id": user_id,
        "task_name": task.description,
        "due_time": task.due_time or datetime.now(),
        "status": "pending",
        "visible_to_family": task.visible_to_family if hasattr(task, 'visible_to_family') else profile.get("family_visibility", True),
        "visible_to_admin": task.visible_to_admin if hasattr(task, 'visible_to_admin') else profile.get("admin_visibility", True),
        "created_at": datetime.now()
    }

    result = await db["safety_tasks"].insert_one(new_task)
    return TaskResponse(
        id=str(result.inserted_id),
        description=task.description,
        due_time=new_task["due_time"],
        completed=False,
        missed=False,
        visible_to_family=new_task["visible_to_family"],
        visible_to_admin=new_task["visible_to_admin"]
    )


@router.get("/tasks", response_model=List[TaskResponse])
async def list_tasks(
    user_id: Optional[str] = None,
    db: AsyncIOMotorDatabase = Depends(get_database),
    current_user: dict = Depends(get_current_user)
):
    requesting_user_id = current_user.get("user_id")
    user_email = current_user.get("sub")
    
    # If no user_id specified, use the current user's ID
    if not user_id:
        user_id = requesting_user_id
    
    # Check access permissions if viewing someone else's tasks
    if user_id != requesting_user_id:
        has_access = await check_safety_access(
            requesting_user_id, 
            user_id, 
            current_user,
            db
        )
        
        if not has_access:
            raise HTTPException(status_code=403, detail="You don't have permission to view these tasks")
    
    # Determine which tasks to return based on permissions
    if user_email == "arzumehreen050@gmail.com":
        # Admins can see tasks that are visible to admins
        query = {"user_id": user_id, "visible_to_admin": True}
    elif user_id == requesting_user_id:
        # Users can see all their own tasks
        query = {"user_id": user_id}
    else:
        # Family members can see tasks that are visible to family
        query = {"user_id": user_id, "visible_to_family": True}
    
    tasks = await db["safety_tasks"].find(query).sort("due_time", 1).to_list(100)
    
    return [
        TaskResponse(
            id=str(t["_id"]),
            description=t["task_name"],
            due_time=t.get("due_time", datetime.utcnow()),
            completed=t["status"] == "completed",
            missed=t["status"] == "missed",
            visible_to_family=t.get("visible_to_family", True),
            visible_to_admin=t.get("visible_to_admin", True),
            completed_at=t.get("completed_at") if t["status"] == "completed" else None,
            completed_by=t.get("completed_by") if t["status"] == "completed" else None
        )
        for t in tasks
    ]


@router.post("/tasks/{task_id}/complete", response_model=TaskResponse)
async def complete_task(
    task_id: str,
    db: AsyncIOMotorDatabase = Depends(get_database),
    current_user: dict = Depends(get_current_user)
):
    user_id = current_user.get("user_id")
    user_email = current_user.get("sub")
    
    # Find the task
    try:
        task_object_id = ObjectId(task_id)
        task = await db["safety_tasks"].find_one({"_id": task_object_id})
    except:
        task = None
    
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    # Check permission to complete this task
    if task["user_id"] != user_id and user_email != "arzumehreen050@gmail.com":
        raise HTTPException(status_code=403, detail="You don't have permission to complete this task")
    
    # Set completion time
    completion_time = datetime.now()
    
    # Mark task as completed
    result = await db["safety_tasks"].find_one_and_update(
        {"_id": task_object_id},
        {
            "$set": {
                "status": "completed",
                "completed_at": completion_time,
                "completed_by": user_id
            }
        },
        return_document=True
    )

    # Create a complete response with all required fields
    return TaskResponse(
        id=str(result["_id"]),
        description=result["task_name"],
        due_time=result.get("due_time", datetime.utcnow()),
        completed=True,
        missed=False,
        visible_to_family=result.get("visible_to_family", True),
        visible_to_admin=result.get("visible_to_admin", True),
        completed_at=result.get("completed_at", completion_time),  # Ensure completed_at is returned
        completed_by=result.get("completed_by", user_id)  # Ensure completed_by is returned
    )


# ---------------- SOS ROUTES ----------------
@router.post("/sos", response_model=SOSResponse)
async def send_sos(
    sos: SOSCreate,
    db: AsyncIOMotorDatabase = Depends(get_database),
    current_user: dict = Depends(get_current_user)
):
    user_id = current_user.get("user_id")
    user_email = current_user.get("sub")
    
    # Get user profile for visibility settings
    profile = await db["safety_profiles"].find_one({"user_id": user_id})
    if not profile:
        # Create a default profile if one doesn't exist
        profile_data = {
            "user_id": user_id,
            "emergency_contacts": [],
            "safe_zones": [],
            "family_visibility": True,
            "admin_visibility": True,    
            "family_members": [{"email": "arzumehreen050@gmail.com", "role": "admin"}],
            "is_active": True,
            "created_at": datetime.now()
        }
        
        profile_result = await db["safety_profiles"].insert_one(profile_data)
        profile = profile_data
        profile["_id"] = profile_result.inserted_id
    
    # Prepare location data
    location = None
    geo_lat = sos.geo_lat or 0
    geo_lng = sos.geo_lng or 0
    
    # If location is provided correctly, use it
    if sos.location and hasattr(sos.location, 'lat') and hasattr(sos.location, 'lng'):
        location = {
            "lat": sos.location.lat,
            "lng": sos.location.lng,
            "address": getattr(sos.location, 'address', None),
            "name": getattr(sos.location, 'name', None)
        }
        geo_lat = sos.location.lat
        geo_lng = sos.location.lng
    
    # Create new SOS alert with proper location handling
    new_sos = {
        "user_id": user_id,
        "user_email": user_email,
        "message": sos.message,
        "geo_lat": geo_lat,
        "geo_lng": geo_lng,
        "location": location,
        "triggered_at": sos.triggered_at or datetime.now(),
        "resolved": False,
        "visible_to_family": profile.get("family_visibility", True),
        "visible_to_admin": profile.get("admin_visibility", True)
    }
  
    result = await db["safety_sos"].insert_one(new_sos)
    
    # Get emergency contacts from profile
    emergency_contacts = profile.get("emergency_contacts", [])
    
    # TODO: Implement actual notification to emergency contacts
    # This would be handled by an external service or background task
    
    return SOSResponse(
        id=str(result.inserted_id),
        message=sos.message,
        location=location,
        geo_lat=geo_lat,
        geo_lng=geo_lng,
        triggered_at=new_sos["triggered_at"],
        resolved=False,
        visible_to_family=new_sos["visible_to_family"],
        visible_to_admin=new_sos["visible_to_admin"],
        notified_contacts=len(emergency_contacts)
    )


@router.get("/sos", response_model=List[SOSResponse])
async def list_sos_alerts(
    user_id: Optional[str] = None,
    db: AsyncIOMotorDatabase = Depends(get_database),
    current_user: dict = Depends(get_current_user)
):
    requesting_user_id = current_user.get("user_id")
    user_email = current_user.get("sub")
    
    # If no user_id specified, use the current user's ID
    if not user_id:
        user_id = requesting_user_id
    
    # Check access permissions if viewing someone else's SOS alerts
    if user_id != requesting_user_id:
        has_access = await check_safety_access(
            requesting_user_id, 
            user_id, 
            current_user,
            db
        )
        
        if not has_access:
            raise HTTPException(status_code=403, detail="You don't have permission to view these SOS alerts")
    
    # Determine which alerts to return based on permissions
    if user_email == "arzumehreen050@gmail.com":
        # Admins can see alerts that are visible to admins
        query = {"user_id": user_id, "visible_to_admin": True}
    elif user_id == requesting_user_id:
        # Users can see all their own alerts
        query = {"user_id": user_id}
    else:
        # Family members can see alerts that are visible to family
        query = {"user_id": user_id, "visible_to_family": True}
    
    sos_alerts = await db["safety_sos"].find(query).sort("triggered_at", -1).to_list(100)
    
    return [
        SOSResponse(
            id=str(alert["_id"]),
            message=alert["message"],
            location=alert.get("location"),
            geo_lat=alert.get("geo_lat", 0),
            geo_lng=alert.get("geo_lng", 0),
            triggered_at=alert["triggered_at"],
            resolved=alert["resolved"],
            resolved_at=alert.get("resolved_at"),
            resolved_by=alert.get("resolved_by"),
            visible_to_family=alert.get("visible_to_family", True),
            visible_to_admin=alert.get("visible_to_admin", True),
            notified_contacts=0
        )
        for alert in sos_alerts
    ]


@router.post("/sos/{sos_id}/resolve", response_model=SOSResponse)
async def resolve_sos(
    sos_id: str,
    db: AsyncIOMotorDatabase = Depends(get_database),
    current_user: dict = Depends(get_current_user)
):
    user_id = current_user.get("user_id")
    user_email = current_user.get("sub")
    
    # Find the SOS alert
    sos_alert = await db["safety_sos"].find_one({"_id": ObjectId(sos_id)})
    if not sos_alert:
        raise HTTPException(status_code=404, detail="SOS alert not found")
    
    # Check if user has permission to resolve this alert
    if sos_alert["user_id"] != user_id and user_email != "arzumehreen050@gmail.com":
        # Check if user is a family member
        profile = await db["safety_profiles"].find_one({"user_id": sos_alert["user_id"]})
        if not profile or user_id not in profile.get("family_members", []):
            raise HTTPException(status_code=403, detail="You don't have permission to resolve this SOS alert")
    
    # Mark SOS alert as resolved
    result = await db["safety_sos"].find_one_and_update(
        {"_id": ObjectId(sos_id)},
        {
            "$set": {
                "resolved": True,
                "resolved_at": datetime.now(),
                "resolved_by": user_id
            }
        },
        return_document=True,
    )

    return SOSResponse(
        id=str(result["_id"]),
        message=result["message"],
        location=result.get("location"),
        triggered_at=result["triggered_at"],
        resolved=True,
        resolved_at=result.get("resolved_at"),
        resolved_by=result.get("resolved_by"),
        visible_to_family=result.get("visible_to_family", True),
        visible_to_admin=result.get("visible_to_admin", True),
        notified_contacts=0  # We don't store this info in the database
    )
