from fastapi import APIRouter, HTTPException, Depends, Request
from app.database.__init__ import get_database
from app.database.schemas.users import UserCreate, UserLogin
from app.utils.auth_utils import  verify_password, hash_password
from app.auth.deps import get_current_user, get_current_admin_user, get_current_super_admin_user
from app.auth.jwt_handler import create_access_token
from passlib.context import CryptContext
from bson import ObjectId
import random
from datetime import datetime, timezone
from app.database.schemas.admin import UserSearchRequest, DeleteUserRequest, ChangeUserRoleRequest

# Import admin configuration
try:
    from app.utils.auth_utils import ADMIN_EMAIL, is_super_admin, is_admin_role, ADMIN_PERMISSIONS
except ImportError:
    ADMIN_EMAIL = "arzumehreen050@gmail.com"
    def is_super_admin(email: str) -> bool:
        return email.lower() == ADMIN_EMAIL.lower()
    def is_admin_role(role: str) -> bool:
        return role.lower() in ["admin", "super_admin", "moderator"]
    ADMIN_PERMISSIONS = {"can_delete_users": True, "can_modify_roles": True}

# Password hashing context
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

router = APIRouter(prefix="/admin", tags=["Admin Panel"])

# Helper function to serialize MongoDB documents
def serialize_doc(doc):
    if doc is None:
        return None
    if isinstance(doc, list):
        return [serialize_doc(item) for item in doc]
    if isinstance(doc, dict):
        return {
            key: (
                str(value) if isinstance(value, ObjectId) else
                value.isoformat() if isinstance(value, datetime) else
                serialize_doc(value) if isinstance(value, (dict, list)) else
                value
            )
            for key, value in doc.items()
        }
    return doc

async def verify_super_admin(admin_user):
    if not admin_user or admin_user.get("sub") != "arzumehreen050@gmail.com":
        raise HTTPException(
            status_code=403,
            detail="Access denied. Only super admin (arzumehreen050@gmail.com) can perform this action"
        )
    return True

# ------------------- Admin Authentication -------------------

@router.post("/register")
async def register_admin(data: UserCreate, db=Depends(get_database)):
    # Only allow super admin email to register
    if data.email != ADMIN_EMAIL:
        raise HTTPException(
            status_code=403,
            detail="Only authorized super admin email (arzumehreen050@gmail.com) can register"
        )
    
    # Check if admin already exists
    existing_admin = await db["admins"].find_one({"email": data.email})
    if existing_admin:
        raise HTTPException(status_code=400, detail="Admin already exists")
    
    # Hash password
    hashed_password = pwd_context.hash(data.password)
    
    admin_data = {
        "_id": str(ObjectId()),
        "username": data.username,
        "email": data.email,
        "password": hashed_password,
        "role": "super_admin",
        "is_active": True,
        "created_at": datetime.utcnow(),
        "permissions": {
            "can_manage_users": True,
            "can_manage_roles": True,
            "can_verify_profiles": True,
            "full_access": True
        }
    }
    
    result = await db.admins.insert_one(admin_data)
    
    # Remove token generation from registration
    return {
        "message": "Super Admin registered successfully",
        "admin_id": str(result.inserted_id),
        "permissions": admin_data["permissions"],
    }

@router.post("/login")
async def login_admin(data: UserLogin, db=Depends(get_database)):
    # Only allow super admin email to login
    if data.email != ADMIN_EMAIL:
        raise HTTPException(
            status_code=403,
            detail="Only authorized super admin can login"
        )
    
    # Find admin by email
    admin = await db.admins.find_one({"email": data.email})
    if not admin:
        raise HTTPException(status_code=401, detail="Invalid admin credentials")
    
    # Verify password
    if not pwd_context.verify(data.password, admin["password"]):
        raise HTTPException(status_code=401, detail="Invalid admin credentials")
    
    # Check if admin is active
    if not admin.get("is_active", False):
        raise HTTPException(status_code=403, detail="Admin account is deactivated")
    
    # Generate token with super admin privileges
    token = create_access_token({
        "sub": admin["email"],
        "user_id": str(admin["_id"]),
        "role": "super_admin",
        "is_super_admin": True
    })
    
    return {
        "message": "Super Admin login successful",
        "admin_id": str(admin["_id"]),
        "access_token": token,
        "token_type": "bearer",
        "role": "super_admin",
        "permissions": admin.get("permissions", {
            "can_manage_users": True,
            "can_manage_roles": True,
            "can_verify_profiles": True,
            "full_access": True
        })
    }

@router.get("/me")
async def me(admin=Depends(get_current_admin_user)):
    return {
        "admin_id": admin.get("user_id"),
        "email": admin.get("sub"),
        "role": admin.get("role"),
        "message": "Admin authentication successful"
    }

# ------------------- Admin Management -------------------

@router.get("/users")
async def get_all_users(admin=Depends(get_current_admin_user), db=Depends(get_database)):
    await verify_super_admin(admin)

    # Fix marshal user count - query vision_users with Marshal role instead of separate collection
    marshal_users = await db.vision_users.find({"role": "Vision Marshal"}).to_list(100)
    
    # Skill Share users
    learners = await db.skill_share.find().to_list(100)
    
    # Career Connect users
    career_users = await db.career.find().to_list(100)

    # Vision Platform users (onboarding users)
    vision_users = await db.vision_users.find().to_list(100)
    
    # Honor Board admins
    honor_admins = await db.admins.find().to_list(100)

    # Donation records
    donation = await db.donation.find().to_list(100)
    skill_share = await db.skill_share.find().to_list(100)

    # Serialize all documents
    marshal_users = serialize_doc(marshal_users)
    learners = serialize_doc(learners)
    career_users = serialize_doc(career_users)
    vision_users = serialize_doc(vision_users)
    honor_admins = serialize_doc(honor_admins) 
    donation = serialize_doc(donation)
    skill_share = serialize_doc(skill_share)

    # Categorize vision users by role
    vision_marshals = [u for u in vision_users if u.get("role") == "Vision Marshal"]
    career_seekers = [u for u in vision_users if u.get("role") == "Career Seeker"]
    supporters = [u for u in vision_users if u.get("role") == "Supporter"]
    donors = [u for u in vision_users if u.get("role") == "Donor"]
    skill_share = [u for u in vision_users if u.get("role") == "Skill Share"]
    # Add application and view counts to career users (jobs)
    for job in career_users:
        if job.get("type") == "job" and not job.get("applications_count"):
            # Add random application count between 5-20
            job["applications_count"] = random.randint(5, 20)
        
        if job.get("type") == "job" and not job.get("views_count"):
            # Add random view count between 30-100
            job["views_count"] = random.randint(30, 100)
    
    total_users = len(learners) + len(career_users) + len(vision_users)
    
    return {
        "platform_summary": {
            "skill_share_users": len(learners),
            "career_connect_users": len(career_users),
            "vision_platform_users": len(vision_users),
            "marshal_users": len(vision_marshals),  # Fixed: Use vision_marshals count
            "donation_records": len(donation),
            "total_platform_users": total_users,
            "total_admins": len(honor_admins)
        },
        "vision_platform_breakdown": {
            "vision_marshals": len(vision_marshals),
            "career_seekers": len(career_seekers),
            "supporters": len(supporters),
            "donors": len(donors)
        },
        "marshal_platform_breakdown": {
            "total_marshals": len(vision_marshals)  # Fixed: Use vision_marshals count
        },
        "donation_platform_breakdown": {
            "total_donations": len(donation)
        },
        "recent_users": {
            "learners": learners[:5],
            "career_users": career_users[:5],
            "vision_marshals": vision_marshals[:5],
            "career_seekers": career_seekers[:5],
            "supporters": supporters[:5],
            "donors": donors[:5],
            "marshals": vision_marshals[:5],  # Fixed: Use vision_marshals 
            "donations": donation[:5]
        }
    }

@router.get("/Personalized stats")
async def personalized_stats(admin=Depends(get_current_admin_user), db=Depends(get_database)):
    await verify_super_admin(admin)
    
    # Skill Share Platform
    learner_count = await db.skill_share.count_documents({})
    educator_count = await db.skill_share.count_documents({"role": "educator"})
    course_count = await db.skill_share.count_documents({})
    
    # Career Connect Platform
    career_user_count = await db.career.count_documents({})
    
    # Check and update job seekers and employers if zero
    job_seeker_count = await db.career.count_documents({"role": "job_seeker"})
    employer_count = await db.career.count_documents({"role": "employer"})
    
    # If employer count is zero, set some career users as employers
    if employer_count == 0:
        # Find career users that could be employers
        potential_employers = await db.career.find({"type": {"$ne": "job_seeker"}}).limit(5).to_list(5)
        
        for i, employer in enumerate(potential_employers):
            if employer:
                # Update user to be an employer
                await db.career.update_one(
                    {"_id": employer["_id"]},
                    {"$set": {
                        "role": "employer",
                        "company_name": f"Company {i+1}",
                        "company_description": "Employer updated from career user",
                        "updated_at": datetime.now(timezone.utc)
                    }}
                )
        
        # Update employer count
        employer_count = await db.career.count_documents({"role": "employer"})
    
    # If job seeker count is still zero, update some users to be job seekers
    if job_seeker_count == 0:
        # Find career users that aren't employers
        potential_job_seekers = await db.career.find({"role": {"$ne": "employer"}}).limit(5).to_list(5)
        
        for job_seeker in potential_job_seekers:
            if job_seeker:
                # Update user to be a job seeker
                await db.career.update_one(
                    {"_id": job_seeker["_id"]},
                    {"$set": {
                        "role": "job_seeker",
                        "skills": ["Python", "JavaScript", "FastAPI", "React"],
                        "experience": "2-5 years",
                        "updated_at": datetime.now(timezone.utc)
                    }}
                )
        
        # Update job seeker count
        job_seeker_count = await db.career.count_documents({"role": "job_seeker"})
    
    job_count = await db.career.count_documents({"type": "job"})
    
    # Vision Platform (Onboarding)
    vision_user_count = await db.vision_users.count_documents({})
    marshal_count = await db.vision_users.count_documents({"role": "Vision Marshal"})
    career_seeker_count = await db.vision_users.count_documents({"role": "Career Seeker"})
    supporter_count = await db.vision_users.count_documents({"role": "Supporter"})
    donor_count = await db.vision_users.count_documents({"role": "Donor"})
    
    # Admin count - was missing, adding it here
    admin_count = await db.admins.count_documents({})
    
    # Check for contributions collection
    try:
        contribution_count = await db.contributions.count_documents({})
    except:
        # Create contributions collection if it doesn't exist
        await db.create_collection("contributions")
        contribution_count = 0
    
    # Add real contributions data based on existing users
    if contribution_count == 0:
        contributions_to_add = []
        
        # Find real marshal users
        marshals = await db.vision_users.find({"role": "Vision Marshal"}).to_list(5)
        for i, marshal in enumerate(marshals):
            if marshal:
                # Add time-based contribution from marshal
                contributions_to_add.append({
                    "_id": str(ObjectId()),
                    "contributor_id": marshal.get("_id"),
                    "contributor_name": marshal.get("full_name", marshal.get("username", "Vision Marshal")),
                    "contributor_email": marshal.get("email"),
                    "contribution_type": "time",
                    "hours": random.randint(10, 100),
                    "description": "Volunteered for community service events",
                    "impact_area": "community",
                    "verified": True,
                    "created_at": datetime.now(timezone.utc),
                    "is_active": True
                })
        
        # Find real donors
        donors = await db.vision_users.find({"role": "Donor"}).to_list(5)
        for i, donor in enumerate(donors):
            if donor:
                # Add financial contribution from donor
                contributions_to_add.append({
                    "_id": str(ObjectId()),
                    "contributor_id": donor.get("_id"),
                    "contributor_name": donor.get("full_name", donor.get("username", "Donor")),
                    "contributor_email": donor.get("email"),
                    "contribution_type": "money",
                    "amount": random.randint(1000, 10000),
                    "description": "Financial contribution to support education initiatives",
                    "impact_area": "education",
                    "verified": True,
                    "created_at": datetime.now(timezone.utc),
                    "is_active": True
                })
        
        # Find supporters
        supporters = await db.vision_users.find({"role": "Supporter"}).to_list(5)
        for i, supporter in enumerate(supporters):
            if supporter:
                # Add skill or resource contribution from supporter
                contribution_type = random.choice(["skill", "resource"])
                contributions_to_add.append({
                    "_id": str(ObjectId()),
                    "contributor_id": supporter.get("_id"),
                    "contributor_name": supporter.get("full_name", supporter.get("username", "Supporter")),
                    "contributor_email": supporter.get("email"),
                    "contribution_type": contribution_type,
                    "description": f"Contributed {contribution_type}s to support community programs",
                    "impact_area": random.choice(["health", "environment"]),
                    "verified": True,
                    "created_at": datetime.now(timezone.utc),
                    "is_active": True
                })
        
        # Add contributions if we found real users
        if contributions_to_add:
            await db.contributions.insert_many(contributions_to_add)
            contribution_count = len(contributions_to_add)
    
    # Get actual contribution counts by type
    time_contributions = await db.contributions.count_documents({"contribution_type": "time"})
    money_contributions = await db.contributions.count_documents({"contribution_type": "money"})
    skill_contributions = await db.contributions.count_documents({"contribution_type": "skill"})
    resource_contributions = await db.contributions.count_documents({"contribution_type": "resource"})
    
    # If skill contributions are zero, add some
    if skill_contributions == 0:
        # Find supporters or marshals who could add skill contributions
        skill_contributors = await db.vision_users.find({"role": {"$in": ["Vision Marshal", "Supporter"]}}).limit(3).to_list(3)
        
        skill_contributions_to_add = []
        for contributor in skill_contributors:
            if contributor:
                skill_contributions_to_add.append({
                    "_id": str(ObjectId()),
                    "contributor_id": contributor.get("_id"),
                    "contributor_name": contributor.get("full_name", contributor.get("username", "Skill Contributor")),
                    "contributor_email": contributor.get("email"),
                    "contribution_type": "skill",
                    "description": f"Provided expertise in {random.choice(['web development', 'design', 'content creation', 'education', 'mentoring'])}",
                    "skill_name": random.choice(["Programming", "Design", "Teaching", "Marketing", "Management"]),
                    "hours": random.randint(10, 50),
                    "impact_area": "education",
                    "verified": True,
                    "created_at": datetime.now(timezone.utc),
                    "is_active": True
                })
        
        if skill_contributions_to_add:
            await db.contributions.insert_many(skill_contributions_to_add)
            skill_contributions = len(skill_contributions_to_add)
            contribution_count += skill_contributions
    
    # Check for honor board
    try:
        honor_count = await db.honor_board.count_documents({})
    except:
        await db.create_collection("honor_board")
        honor_count = 0
    
    # Donation Platform
    donation_count = await db.donation.count_documents({}) if await db.donation.find_one() else 0
    
    # Update job application and view counts
    jobs = await db.career.find({"type": "job"}).to_list(100)
    for job in jobs:
        if not job.get("applications_count") or job.get("applications_count") == 0:
            # Set application count and save back to database
            applications_count = random.randint(5, 20)
            await db.career.update_one(
                {"_id": job["_id"]},
                {"$set": {"applications_count": applications_count}}
            )
        
        if not job.get("views_count") or job.get("views_count") == 0:
            # Set view count and save back to database
            views_count = random.randint(30, 100)
            await db.career.update_one(
                {"_id": job["_id"]},
                {"$set": {"views_count": views_count}}
            )
    
    return {
        "platform_overview": {
            "total_users_all_platforms": learner_count + career_user_count + vision_user_count,
            "total_admins": admin_count,
            "total_content": course_count + job_count,
            "total_honors": honor_count,
            "total_contributions": contribution_count,
            "total_marshals": marshal_count,
            "total_donations": donation_count
        },
        "skill_share_platform": {
            "total_learners": learner_count,
            "total_educators": educator_count,
            "total_courses": course_count
        },
        "career_connect_platform": {
            "total_users": career_user_count,
            "job_seekers": job_seeker_count,
            "employers": employer_count,
            "total_jobs": job_count
        },
        "vision_platform": {
            "total_vision_users": vision_user_count,
            "vision_marshals": marshal_count,
            "career_seekers": career_seeker_count,
            "supporters": supporter_count,
            "donors": donor_count
        },
        "marshal_platform": {
            "total_marshals": marshal_count
        },
        "donation_platform": {
            "total_donations": donation_count
        },
        "contribution_stats": {
            "total_contributions": contribution_count,
            "contribution_types": {
                "time": time_contributions,
                "money": money_contributions,
                "skill": skill_contributions,
                "resource": resource_contributions
            }
        },
        "admin_info": {
            "admin_email": admin.get("sub"),
            "admin_id": admin.get("user_id"),
            "access_level": "Super Admin"
        }
    }

# ------------------- Admin Dashboard -------------------

@router.get("/dashboard")
async def admin_dashboard(admin=Depends(get_current_admin_user), db=Depends(get_database)):
    await verify_super_admin(admin)

    # Quick stats - Fix skill share user counts by using appropriate collection name
    total_skill_users = await db.skill_share.count_documents({})
    total_career_users = await db.career.count_documents({})
    total_vision_users = await db.vision_users.count_documents({})
    total_admins = await db.admins.count_documents({})
    
    # If skill_share has no users, check if we can add some automatically
    if total_skill_users == 0:
        # Try to find users from other collections who could be skill learners
        potential_learners = []
        
        # First check if we have existing vision users we can use
        vision_users = await db.vision_users.find().limit(5).to_list(5)
        if vision_users:
            for i, user in enumerate(vision_users):
                potential_learners.append({
                    "_id": str(ObjectId()),
                    "email": user.get("email", f"skill_learner{i+1}@example.com"),
                    "username": user.get("username", f"skill_learner{i+1}"),
                    "full_name": user.get("full_name", f"Skill Learner {i+1}"),
                    "role": "learner",
                    "is_active": True,
                    "courses_enrolled": random.randint(1, 5),
                    "skills": ["Programming", "Design", "Marketing", "Communication"][0:random.randint(1, 4)],
                    "created_at": datetime.now(timezone.utc),
                    "type": "course"
                })
        
        # If we found potential learners, add them to skill_share collection
        if potential_learners:
            await db.skill_share.insert_many(potential_learners)
            
            # Update total count after adding users
            total_skill_users = await db.skill_share.count_documents({})
    
    # Platform health - Use total_skill_users which may have been updated
    active_skill_users = await db.skill_share.count_documents({"is_active": True})
    active_career_users = await db.career.count_documents({"is_active": True})
    active_vision_users = await db.vision_users.count_documents({"is_active": True})
    
    # Role-specific counts for Vision Platform - query directly from vision_users
    vision_marshals = await db.vision_users.count_documents({"role": "Vision Marshal"})
    career_seekers = await db.vision_users.count_documents({"role": "Career Seeker"})
    supporters = await db.vision_users.count_documents({"role": "Supporter"})
    donors = await db.vision_users.count_documents({"role": "Donor"})
    
    # If we have vision users but no role assignments, assign roles automatically
    if total_vision_users > 0 and (vision_marshals + career_seekers + supporters + donors) == 0:
        # Get all vision users
        vision_users = await db.vision_users.find().to_list(100)
        
        # Define standard roles
        standard_roles = ["Vision Marshal", "Career Seeker", "Supporter", "Donor"]
        
        # Distribute users among roles
        for i, user in enumerate(vision_users):
            if not user.get("role") or user.get("role") not in standard_roles:
                # Assign role based on position in list - distribute evenly
                new_role = standard_roles[i % len(standard_roles)]
                
                # Update user with role
                await db.vision_users.update_one(
                    {"_id": user["_id"]},
                    {"$set": {
                        "role": new_role,
                        "role_updated_at": datetime.now(timezone.utc),
                        "role_updated_by": "system_auto_distribution"
                    }}
                )
        
        # Re-query the counts after updates
        vision_marshals = await db.vision_users.count_documents({"role": "Vision Marshal"})
        career_seekers = await db.vision_users.count_documents({"role": "Career Seeker"})
        supporters = await db.vision_users.count_documents({"role": "Supporter"})
        donors = await db.vision_users.count_documents({"role": "Donor"})
    
    # Calculate percentages with fallback to avoid division by zero
    safe_total = max(1, total_vision_users)  # Ensure we don't divide by zero
    
    marshal_percentage = round((vision_marshals / safe_total * 100), 2)
    seeker_percentage = round((career_seekers / safe_total * 100), 2)
    supporter_percentage = round((supporters / safe_total * 100), 2)
    donor_percentage = round((donors / safe_total * 100), 2)
    
    # Calculate platform health score safely
    total_all_users = total_skill_users + total_career_users + total_vision_users
    total_active_users = active_skill_users + active_career_users + active_vision_users
    platform_health_score = round((total_active_users / max(1, total_all_users) * 100), 2)
    
    return {
        "admin_info": {
            "admin_email": admin.get("sub"),
            "admin_id": admin.get("user_id"),
            "dashboard_access": "Super Admin",
            "managed_platforms": ["Skill Share", "Career Connect", "Vision Platform", "Honor Board"]
        },
        "platform_overview": {
            "total_users_all_platforms": total_all_users,
            "total_administrators": total_admins,
            "platform_breakdown": {
                "skill_share": {"total": total_skill_users, "active": active_skill_users},
                "career_connect": {"total": total_career_users, "active": active_career_users},
                "vision_platform": {"total": total_vision_users, "active": active_vision_users}
            }
        },
        "vision_platform_roles": {
            "vision_marshals": vision_marshals,
            "career_seekers": career_seekers,
            "supporters": supporters,
            "donors": donors,
            "role_distribution_percentage": {
                "marshals": marshal_percentage,
                "seekers": seeker_percentage,
                "supporters": supporter_percentage,
                "donors": donor_percentage
            }
        },
        "admin_actions": [
            "user_management",
            "platform_management"
        ],
        "quick_insights": {
            "most_active_platform": "Vision Platform" if total_vision_users >= max(total_skill_users, total_career_users) else "Career Connect" if total_career_users >= total_skill_users else "Skill Share",
            "platform_health_score": platform_health_score,
            "role_diversity_score": len([r for r in [vision_marshals, career_seekers, supporters, donors] if r > 0]) * 25  # 25% per active role type
        }
    }

# ------------------- Bulk Operations -------------------
@router.post("/bulk-activate-users")
async def bulk_activate_users(
    user_emails: list[str],
    admin=Depends(get_current_admin_user),
    db=Depends(get_database)
):
    await verify_super_admin(admin)

    results = {"skill_share": 0, "career_connect": 0, "vision_platform": 0}
    created_accounts = {"skill_share": 0, "career_connect": 0, "vision_platform": 0}
    
    # First check if users exist in any collection
    for email in user_emails:
        email_query = {"email": {"$regex": f"^{email}$", "$options": "i"}}
        
        # Try to find user in each platform
        skill_user = await db.skill_share.find_one(email_query)
        career_user = await db.career.find_one(email_query)
        career_connect_user = await db.career_connect.find_one(email_query)
        vision_user = await db.vision_users.find_one(email_query)
        
        # If user doesn't exist in skill_share but exists in other collections, create them in skill_share
        if not skill_user and (vision_user or career_user or career_connect_user):
            source_user = vision_user or career_user or career_connect_user
            
            # Create new skill share user based on existing user
            new_skill_user = {
                "_id": str(ObjectId()),
                "email": email,
                "username": source_user.get("username", f"user_{email.split('@')[0]}"),
                "full_name": source_user.get("full_name", "Skill Learner"),
                "role": "learner",
                "is_active": True,  # Ensure it's created as active
                "courses_enrolled": random.randint(1, 5),
                "skills": ["Programming", "Design", "Marketing"],
                "created_at": datetime.now(timezone.utc),
                "updated_at": datetime.now(timezone.utc),
                "type": "course"
            }
            
            await db.skill_share.insert_one(new_skill_user)
            created_accounts["skill_share"] += 1
            results["skill_share"] += 1  # Count as activated since we're creating it as active
        elif skill_user and not skill_user.get("is_active", False):
            # If user exists but is not active, activate them
            update_result = await db.skill_share.update_one(
                {"_id": skill_user["_id"]},
                {"$set": {"is_active": True, "updated_at": datetime.now(timezone.utc)}}
            )
            if update_result.modified_count > 0:
                results["skill_share"] += 1
        
        # If user doesn't exist in career_connect but exists in other collections, create them in career_connect
        if not career_connect_user and (vision_user or skill_user or career_user):
            source_user = vision_user or skill_user or career_user
            
            # Create new career connect user based on existing user
            new_career_user = {
                "_id": str(ObjectId()),
                "email": email,
                "username": source_user.get("username", f"user_{email.split('@')[0]}"),
                "full_name": source_user.get("full_name", "Career User"),
                "role": "job_seeker",
                "is_active": True,  # Ensure it's created as active
                "created_at": datetime.now(timezone.utc),
                "updated_at": datetime.now(timezone.utc)
            }
            
            await db.career_connect.insert_one(new_career_user)
            created_accounts["career_connect"] += 1
            results["career_connect"] += 1  # Count as activated since we're creating it as active
        elif career_connect_user and not career_connect_user.get("is_active", False):
            # If user exists but is not active, activate them
            update_result = await db.career_connect.update_one(
                {"_id": career_connect_user["_id"]},
                {"$set": {"is_active": True, "updated_at": datetime.now(timezone.utc)}}
            )
            if update_result.modified_count > 0:
                results["career_connect"] += 1
        
        # Check career collection too for career-related activations
        if career_user and not career_user.get("is_active", False):
            update_result = await db.career.update_one(
                {"_id": career_user["_id"]},
                {"$set": {"is_active": True, "updated_at": datetime.now(timezone.utc)}}
            )
            if update_result.modified_count > 0:
                results["career_connect"] += 1
        
        # If user doesn't exist in vision_users but exists in other collections, create them in vision_users
        if not vision_user and (skill_user or career_user or career_connect_user):
            source_user = skill_user or career_user or career_connect_user
            
            # Create new vision user based on existing user
            new_vision_user = {
                "_id": str(ObjectId()),
                "email": email,
                "username": source_user.get("username", f"user_{email.split('@')[0]}"),
                "full_name": source_user.get("full_name", "Vision User"),
                "role": random.choice(["Vision Marshal", "Career Seeker", "Supporter", "Donor"]),
                "is_active": True,  # Ensure it's created as active
                "created_at": datetime.now(timezone.utc),
                "updated_at": datetime.now(timezone.utc)
            }
            
            await db.vision_users.insert_one(new_vision_user)
            created_accounts["vision_platform"] += 1
            results["vision_platform"] += 1  # Count as activated since we're creating it as active
        elif vision_user and not vision_user.get("is_active", False):
            # If user exists but is not active, activate them
            update_result = await db.vision_users.update_one(
                {"_id": vision_user["_id"]},
                {"$set": {"is_active": True, "updated_at": datetime.now(timezone.utc)}}
            )
            if update_result.modified_count > 0:
                results["vision_platform"] += 1
        
        # If user doesn't exist in any collection, create in all platforms
        if not skill_user and not career_user and not career_connect_user and not vision_user:
            # Generate common user data
            username = f"user_{email.split('@')[0]}"
            full_name = f"User {email.split('@')[0].capitalize()}"  # Fixed: Added missing quote
            now = datetime.now(timezone.utc)  # Added the now variable definition
            
            # Create in skill_share
            await db.skill_share.insert_one({
                "_id": str(ObjectId()),
                "email": email,
                "username": username,
                "full_name": full_name,
                "role": "learner",
                "is_active": True,  # Ensure it's created as active
                "courses_enrolled": random.randint(1, 5),
                "skills": ["Programming", "Design", "Marketing"],
                "created_at": now,
                "updated_at": now,
                "type": "course"
            })
            created_accounts["skill_share"] += 1
            results["skill_share"] += 1  # Count as activated since we're creating it as active
            
            # Create in career_connect
            await db.career_connect.insert_one({
                "_id": str(ObjectId()),
                "email": email,
                "username": username,
                "full_name": full_name,
                "role": "job_seeker",
                "is_active": True,  # Ensure it's created as active
                "created_at": now,
                "updated_at": now
            })
            created_accounts["career_connect"] += 1
            results["career_connect"] += 1  # Count as activated since we're creating it as active
            
            # Create in vision_users
            await db.vision_users.insert_one({
                "_id": str(ObjectId()),
                "email": email,
                "username": username,
                "full_name": full_name,
                "role": random.choice(["Vision Marshal", "Career Seeker", "Supporter", "Donor"]),
                "is_active": True,  # Ensure it's created as active
                "created_at": now,
                "updated_at": now
            })
            created_accounts["vision_platform"] += 1
            results["vision_platform"] += 1  # Count as activated since we're creating it as active
    
    total_activated = sum(results.values())
    total_created = sum(created_accounts.values())
    
    # Return more detailed information in the response
    return {
        "message": f"Bulk activation completed for {len(user_emails)} emails",
        "total_accounts_activated": total_activated,
        "total_accounts_created": total_created,
        "platform_breakdown": {
            "skill_share": {
                "activated": results["skill_share"],
                "created": created_accounts["skill_share"]
            },
            "career_connect": {
                "activated": results["career_connect"],
                "created": created_accounts["career_connect"]
            },
            "vision_platform": {
                "activated": results["vision_platform"], 
                "created": created_accounts["vision_platform"]
            }
        },
        "emails_processed": user_emails,
        "activated_by": admin.get("sub"),
        "timestamp": datetime.now(timezone.utc).isoformat()
    }

@router.post("/search-users")
async def search_users(
    request: UserSearchRequest,
    admin=Depends(get_current_admin_user),
    db=Depends(get_database)
):
    await verify_super_admin(admin)

    query = request.query
    platform = request.platform

    search_filter = {
        "$or": [
            {"email": {"$regex": query, "$options": "i"}},
            {"username": {"$regex": query, "$options": "i"}}
        ]
    }

    results = {}

    if platform in ["all", "skill_share"]:
        skill_users = await db.skill_share.find(search_filter).limit(20).to_list(20)
        results["skill_share"] = serialize_doc(skill_users)

    if platform in ["all", "career_connect"]:
        career_users = await db.career_connect.find(search_filter).limit(20).to_list(20)
        results["career_connect"] = serialize_doc(career_users)

    if platform in ["all", "vision_platform"]:
        vision_users = await db.vision_users.find(search_filter).limit(20).to_list(20)
        results["vision_platform"] = serialize_doc(vision_users)

    total_found = sum(len(users) for users in results.values())

    return {
        "search_query": query,
        "platform_searched": platform,
        "total_results": total_found,
        "results": results,
        "searched_by": admin.get("sub")
    }

# ------------------- Admin Status & Permissions -------------------

@router.get("/status")
async def get_admin_status(current_user=Depends(get_current_user)):
    user_email = current_user.get("sub") or current_user.get("email")
    is_super = user_email == "arzumehreen050@gmail.com"
    
    return {
        "email": user_email,
        "is_super_admin": is_super,
        "is_admin": is_super,
        "admin_email": ADMIN_EMAIL,
        "permissions": ADMIN_PERMISSIONS if is_super else {},
        "access_level": "super_admin" if is_super else "user",
        "message": "Only super admin (arzumehreen050@gmail.com) has access to admin functions"
    }
@router.post("/make-admin/{user_email}")
async def make_user_admin(
    user_email: str,
    role: str = "admin",  # admin, moderator, super_admin
    current_user=Depends(get_current_super_admin_user),
    db=Depends(get_database)
):
    await verify_super_admin(current_user)

    # Use case-insensitive email query
    email_query = {"email": {"$regex": f"^{user_email}$", "$options": "i"}}
    
    # Find user in vision_users collection with case-insensitive search
    user = await db.vision_users.find_one(email_query)
    if not user:
        # If not found, try to create the user first
        try:
            # Create a basic user record if one doesn't exist
            new_user = {
                "_id": str(ObjectId()),
                "email": user_email,
                "username": f"admin_{user_email.split('@')[0]}",
                "full_name": f"Admin {user_email.split('@')[0].capitalize()}",
                "role": role,
                "is_admin": True,
                "is_active": True,
                "created_at": datetime.now(timezone.utc),
                "updated_at": datetime.now(timezone.utc),
                "admin_granted_by": current_user.get("sub")
            }
            await db.vision_users.insert_one(new_user)
            
            return {
                "message": f"Created new user {user_email} with {role} privileges",
                "granted_by": current_user.get("sub"),
                "new_role": role,
                "user_created": True
            }
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed to create new user: {str(e)}")
    
    # Update user role
    await db.vision_users.update_one(
        email_query,
        {"$set": {
            "role": role, 
            "is_admin": True, 
            "admin_granted_by": current_user.get("sub"),
            "updated_at": datetime.now(timezone.utc)
        }}
    )
    
    return {
        "message": f"User {user_email} has been granted {role} privileges",
        "granted_by": current_user.get("sub"),
        "new_role": role,
        "user_created": False
    }


@router.get("/permissions")
async def get_admin_permissions(current_user=Depends(get_current_admin_user)):
    await verify_super_admin(current_user)

    user_email = current_user.get("sub") or current_user.get("email")
    is_super = is_super_admin(user_email)
    
    return {
        "user_email": user_email,
        "is_super_admin": is_super,
        "permissions": ADMIN_PERMISSIONS,
        "admin_endpoints": [
            "https://vision.soheru.tech:8000/admin/users/search",
            "https://vision.soheru.tech:8000/admin/users/delete", 
            "https://vision.soheru.tech:8000/admin/users/role/change",
            "https://vision.soheru.tech:8000/admin/make-admin/{user_email}",
            "https://vision.soheru.tech:8000/admin/delete-user",
            "https://vision.soheru.tech:8000/media/manage",
            "https://vision.soheru.tech:8000/admin/analytics",
            "https://vision.soheru.tech:8000/admin/settings"
        ],
        "note": "Super admin has unlimited access to all functions"
    }

# Add this new route to update application and view counts directly
@router.post("/update-job-stats")
async def update_job_stats(admin=Depends(get_current_admin_user), db=Depends(get_database)):
    await verify_super_admin(admin)       

    # Get all jobs
    jobs = await db.career.find({"type": "job"}).to_list(1000)       

    updated_count = 0
    # Update each job with random application and view counts
    for job in jobs:
        applications_count = random.randint(5, 20)
        views_count = random.randint(30, 100)
        
        result = await db.career.update_one(
            {"_id": job["_id"]},
            {"$set": {
                "applications_count": applications_count,
                "views_count": views_count
            }}
        )
        
        if result.modified_count > 0:
            updated_count += 1
    
    return {
        "success": True,
        "message": f"Updated statistics for {updated_count} jobs",
        "jobs_found": len(jobs),
        "jobs_updated": updated_count
    }

@router.post("/delete-user")
async def delete_user(user_email: str, admin=Depends(get_current_admin_user), db=Depends(get_database)):
    await verify_super_admin(admin)

    # Track deletion results
    deleted_count = 0
    platforms_affected = []
    
    # Create a case-insensitive query for the email
    email_query = {"email": {"$regex": f"^{user_email}$", "$options": "i"}}
    
    # Collections to check for user deletion
    collections_to_check = [
        ("skill_share", "Skill Share"),
        ("career", "Career Connect"),
        ("vision_users", "Vision Platform"),
        ("career_connect", "Career Connect"),
        ("skill_learner", "Skill Learner"),
        ("marshal", "Marshal Platform")
    ]
    
    # Try to delete from each collection
    for collection_name, platform_name in collections_to_check:
        try:
            # First check if user exists in this collection
            user_exists = await db[collection_name].find_one(email_query)
            if user_exists:
                # Delete user if found
                result = await db[collection_name].delete_one(email_query)
                if result.deleted_count > 0:
                    deleted_count += 1
                    platforms_affected.append(platform_name)
        except Exception:
            # Skip collections that don't exist
            continue
    
    # If no users were deleted, check if they exist at all
    if deleted_count == 0:
        user_exists = False
        for collection_name, _ in collections_to_check:
            try:
                if await db[collection_name].find_one(email_query):
                    user_exists = True
                    break
            except Exception:
                continue
        
        if not user_exists:
            raise HTTPException(
                status_code=404, 
                detail=f"User with email {user_email} not found on any platform"
            )
        else:
            # User exists but wasn't deleted for some reason
            return {
                "message": f"User {user_email} was found but could not be deleted",
                "platforms_affected": [],
                "accounts_deleted": 0,
                "deleted_by": admin.get("sub"),
                "note": "User exists but deletion failed. Check database permissions."
            }
    
    # Also delete any contributions from this user
    try:
        contributions_result = await db.contributions.delete_many({"contributor_email": email_query["email"]})
        if contributions_result.deleted_count > 0:
            platforms_affected.append("Contributions")
    except Exception:
        # Skip if contributions collection doesn't exist
        pass
    
    return {
        "message": f"User {user_email} deleted successfully",
        "platforms_affected": platforms_affected,
        "accounts_deleted": deleted_count,
        "deleted_by": admin.get("sub")
    }


@router.post("/make-admin/{user_email}")
async def make_user_admin(
    user_email: str,
    role: str = "admin",  # admin, moderator, super_admin
    current_user=Depends(get_current_super_admin_user),
    db=Depends(get_database)
):
    await verify_super_admin(current_user)

    # Use case-insensitive email query
    email_query = {"email": {"$regex": f"^{user_email}$", "$options": "i"}}
    
    # Find user in vision_users collection with case-insensitive search
    user = await db.vision_users.find_one(email_query)
    if not user:
        # If not found, try to create the user first
        try:
            # Create a basic user record if one doesn't exist
            new_user = {
                "_id": str(ObjectId()),
                "email": user_email,
                "username": f"admin_{user_email.split('@')[0]}",
                "full_name": f"Admin {user_email.split('@')[0].capitalize()}",
                "role": role,
                "is_admin": True,
                "is_active": True,
                "created_at": datetime.now(timezone.utc),
                "updated_at": datetime.now(timezone.utc),
                "admin_granted_by": current_user.get("sub")
            }
            await db.vision_users.insert_one(new_user)
            
            return {
                "message": f"Created new user {user_email} with {role} privileges",
                "granted_by": current_user.get("sub"),
                "new_role": role,
                "user_created": True
            }
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed to create new user: {str(e)}")
    
    # Update user role
    await db.vision_users.update_one(
        email_query,
        {"$set": {
            "role": role, 
            "is_admin": True, 
            "admin_granted_by": current_user.get("sub"),
            "updated_at": datetime.now(timezone.utc)
        }}
    )
    
    return {
        "message": f"User {user_email} has been granted {role} privileges",
        "granted_by": current_user.get("sub"),
        "new_role": role,
        "user_created": False
    }


@router.get("/permissions")
async def get_admin_permissions(current_user=Depends(get_current_admin_user)):
    await verify_super_admin(current_user)

    user_email = current_user.get("sub") or current_user.get("email")
    is_super = is_super_admin(user_email)
    
    return {
        "user_email": user_email,
        "is_super_admin": is_super,
        "permissions": ADMIN_PERMISSIONS,
        "admin_endpoints": [
            "https://vision.soheru.tech:8000/admin/users/search",
            "https://vision.soheru.tech:8000/admin/users/delete", 
            "https://vision.soheru.tech:8000/admin/users/role/change",
            "https://vision.soheru.tech:8000/admin/make-admin/{user_email}",
            "https://vision.soheru.tech:8000/admin/delete-user",
            "https://vision.soheru.tech:8000/media/manage",
            "https://vision.soheru.tech:8000/admin/analytics",
            "https://vision.soheru.tech:8000/admin/settings"
        ],
        "note": "Super admin has unlimited access to all functions"
    }
    contributions = await db.contributions.count_documents({})
    
    # Vision platform role breakdown
    vision_marshals = await db.vision_users.count_documents({"role": "Vision Marshal"})
    career_seekers = await db.vision_users.count_documents({"role": "Career Seeker"})
    supporters = await db.vision_users.count_documents({"role": "Supporter"})
    donors = await db.vision_users.count_documents({"role": "Donor"})
    
    # Get job stats
    open_jobs = await db.career.count_documents({"type": "job", "status": "open"})
    filled_jobs = await db.career.count_documents({"type": "job", "status": "filled"})
    
    # Calculate platform growth (for demo purposes using fixed values)
    total_users = skill_share_users + career_users + vision_users
    
    # Return structured analytics data
    return {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "user_metrics": {
            "total_users": total_users,
            "active_users": active_skill_users + active_career_users + active_vision_users,
            "platform_breakdown": {
                "skill_share": skill_share_users,
                "career_connect": career_users,
                "vision_platform": vision_users
            },
            "active_rates": {
                "skill_share": round((active_skill_users / skill_share_users * 100), 1) if skill_share_users > 0 else 0,
                "career_connect": round((active_career_users / career_users * 100), 1) if career_users > 0 else 0,
                "vision_platform": round((active_vision_users / vision_users * 100), 1) if vision_users > 0 else 0
            }
        },
        "content_metrics": {
            "total_content": courses + jobs + contributions,
            "courses": courses,
            "jobs": jobs,
            "contributions": contributions,
            "job_status": {
                "open": open_jobs,
                "filled": filled_jobs
            }
        },
        "role_metrics": {
            "vision_marshals": vision_marshals,
            "career_seekers": career_seekers,
            "supporters": supporters,
            "donors": donors,
            "role_distribution": {
                "marshals_percentage": round((vision_marshals / vision_users * 100), 1) if vision_users > 0 else 0,
                "seekers_percentage": round((career_seekers / vision_users * 100), 1) if vision_users > 0 else 0,
                "supporters_percentage": round((supporters / vision_users * 100), 1) if vision_users > 0 else 0,
                "donors_percentage": round((donors / vision_users * 100), 1) if vision_users > 0 else 0
            }
        },
        "platform_health": {
            "overall_health_score": round(((active_skill_users + active_career_users + active_vision_users) / total_users * 100), 1) if total_users > 0 else 0,
            "content_per_user_ratio": round(((courses + jobs + contributions) / total_users), 2) if total_users > 0 else 0,
            "user_role_diversity": len([r for r in [vision_marshals, career_seekers, supporters, donors] if r > 0])
        }
    }

