from fastapi import APIRouter, Depends, HTTPException, Query, Body, Path, BackgroundTasks
from app.database import get_database
from app.database.schemas.FAQ import (
     FAQCreate, FAQResponse, FAQListResponse,
    ChatRequest, ChatResponse
)
from app.database.models.faq import FAQ
from app.auth.deps import get_current_user, is_admin
from typing import  Optional
from bson import ObjectId
from datetime import datetime
import logging
from app.utils.faq_utils import (
    calculate_similarity_local, OPENAI_API_KEY, OPENAI_PY_AVAILABLE, _cosine_similarity, _normalize_cosine_to_01, OPENAI_EMBEDDING_MODEL, OPENAI_CHAT_MODEL, create_sample_suggestions, FAQ_MATCH_THRESHOLD
)
from app.database.crud.faq import call_ai_service, store_ai_suggestion, get_embeddings_openai


# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create the router object
router = APIRouter(prefix="/faq", tags=["FAQ System"])

# Add the missing calculate_similarity function

@router.post("/add", response_model=FAQResponse)
async def add_faq(
    faq: FAQCreate,
    db = Depends(get_database),
    current_user = Depends(get_current_user)
):
    # Check admin
    if not await is_admin(current_user, db):
        raise HTTPException(status_code=403, detail="Admin access required")

    try:
        now = datetime.utcnow()
        faq_doc = {
            "question": faq.question,
            "answer": faq.answer,
            "category": faq.category,
            "approved": True,
            "created_at": now,
            "updated_at": now,
            "created_by": current_user.get("user_id") or current_user.get("sub") or current_user.get("email")
        }
        if getattr(faq, "video_url", None):
            faq_doc["video_url"] = faq.video_url

        # If OpenAI available, compute embedding for question & store
        if OPENAI_API_KEY and OPENAI_PY_AVAILABLE:
            try:
                emb = await get_embeddings_openai([faq.question])
                faq_doc["embedding"] = emb[0]
            except Exception as e:
                logger.warning("Failed to generate embedding for FAQ on create: %s", e)

        res = await db.faqs.insert_one(faq_doc)
        created = await db.faqs.find_one({"_id": res.inserted_id})
        created["id"] = str(created["_id"])
        del created["_id"]
        return created
    except Exception as e:
        logger.error("Failed to add FAQ: %s", e)
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/list", response_model=FAQListResponse)
async def list_faqs(
    category: Optional[str] = Query(None),
    approved: Optional[bool] = Query(True),
    limit: int = Query(100, ge=1, le=500),
    db = Depends(get_database)
):
    try:
        q = {}
        if category:
            q["category"] = category
        if approved is not None:
            q["approved"] = approved
        faqs = await db.faqs.find(q).sort("created_at", -1).limit(limit).to_list(length=limit)
        for f in faqs:
            f["id"] = str(f["_id"])
            del f["_id"]
            # hide embedding in response
            if "embedding" in f:
                del f["embedding"]
        categories = await db.faqs.distinct("category")
        return {"total": len(faqs), "faqs": faqs, "categories": categories}
    except Exception as e:
        logger.error("Failed to list faqs: %s", e)
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/search")
async def search_faqs(
    q: str = Query(..., min_length=2, description="Search query"),
    category: Optional[str] = Query(None),
    limit: int = Query(10, ge=1, le=50),
    db = Depends(get_database)
):
    try:
        # Log search query for debugging
        logger.info(f"Searching FAQs with query: '{q}', category: {category}")
        
        # Check if the exact question exists first
        exact_match = await db.faqs.find_one({"question": q, "approved": True})
        if exact_match:
            logger.info(f"Found exact match for query: {q}")
            exact_match["id"] = str(exact_match["_id"])
            del exact_match["_id"]
            if "embedding" in exact_match:
                del exact_match["embedding"]
                
            return {
                "query": q, 
                "results": [
                    {
                        "id": exact_match["id"],
                        "question": exact_match["question"],
                        "answer": exact_match["answer"],
                        "category": exact_match.get("category", "General"),
                        "video_url": exact_match.get("video_url"),
                        "relevance": 100.0  # Perfect match
                    }
                ], 
                "total": 1
            }
        
        # Direct check for "What is Vision Help Welfare Foundation?"
        if q.lower() == "what is vision help welfare foundation?":
            # Force add this FAQ if it doesn't exist
            vision_faq = await db.faqs.find_one({"question": "What is Vision Help Welfare Foundation?"})
            if not vision_faq:
                logger.info("Creating Vision Help FAQ on demand")
                now = datetime.utcnow()
                vision_faq_doc = {
                    "question": "What is Vision Help Welfare Foundation?",
                    "answer": "Vision Help Welfare Foundation is a non-profit organization dedicated to empowering communities through education, healthcare, and sustainable development initiatives. Founded in 2015, we work to improve the lives of underprivileged individuals across India.",
                    "category": "About Us",
                    "approved": True,
                    "created_at": now,
                    "updated_at": now
                }
                result = await db.faqs.insert_one(vision_faq_doc)
                vision_faq = await db.faqs.find_one({"_id": result.inserted_id})
            
            vision_faq["id"] = str(vision_faq["_id"])
            del vision_faq["_id"]
            if "embedding" in vision_faq:
                del vision_faq["embedding"]
                
            return {
                "query": q, 
                "results": [
                    {
                        "id": vision_faq["id"],
                        "question": vision_faq["question"],
                        "answer": vision_faq["answer"],
                        "category": vision_faq.get("category", "General"),
                        "video_url": vision_faq.get("video_url"),
                        "relevance": 100.0  # Perfect match
                    }
                ], 
                "total": 1
            }
        
        # Do a keyword search for "Vision Help" or "Welfare Foundation"
        if "vision help" in q.lower() or "welfare foundation" in q.lower():
            logger.info("Detected Vision Help/Welfare Foundation keywords, checking for related FAQs")
            vision_faqs = await db.faqs.find({"question": {"$regex": "Vision Help|Welfare Foundation", "$options": "i"}}).to_list(10)
            
            if vision_faqs:
                logger.info(f"Found {len(vision_faqs)} FAQs related to Vision Help/Welfare Foundation")
                processed = []
                for faq in vision_faqs:
                    processed.append({
                        "id": str(faq["_id"]),
                        "question": faq.get("question"),
                        "answer": faq.get("answer"),
                        "category": faq.get("category", "General"),
                        "video_url": faq.get("video_url"),
                        "relevance": 90.0  # High match for Vision Help keyword
                    })
                return {"query": q, "results": processed, "total": len(processed)}
        
        # Regular search logic with regex filter
        search_filter = {"approved": True}
        if category:
            search_filter["category"] = category

        # Use regex for text search
        prefilter = {
            "$or": [
                {"question": {"$regex": q, "$options": "i"}},
                {"answer": {"$regex": q, "$options": "i"}}
            ],
            **search_filter
        }

        # Log the filter we're using
        logger.info(f"Using search filter: {prefilter}")
        
        # Get the candidates
        candidates = await db.faqs.find(prefilter).limit(200).to_list(length=200)
        logger.info(f"Found {len(candidates)} candidates using regex search")
        
        # If still no results, check for any FAQs
        if not candidates:
            total_faqs = await db.faqs.count_documents({})
            logger.info(f"Total FAQs in database: {total_faqs}")
            
            # If no FAQs at all, create the default Vision Help FAQ
            if total_faqs == 0:
                logger.info("No FAQs found, creating initial Vision Help FAQ")
                
                # Try the search again
                candidates = await db.faqs.find(prefilter).limit(200).to_list(length=200)
                logger.info(f"After initialization, found {len(candidates)} candidates")
                
                # If still nothing, get all FAQs
                if not candidates:
                    candidates = await db.faqs.find({"approved": True}).limit(10).to_list(length=10)
                    logger.info(f"Returning all approved FAQs: {len(candidates)}")
        
        # Process candidates with similarity scoring
        processed = []
        
        # If OpenAI available and candidates have embeddings, compute query embedding once
        query_emb = None
        if OPENAI_API_KEY and OPENAI_PY_AVAILABLE and candidates:
            try:
                query_emb = (await get_embeddings_openai([q]))[0]
            except Exception as e:
                logger.warning(f"Failed to create query embedding: {e}")
                query_emb = None

        for faq in candidates:
            # Calculate similarity
            if query_emb is not None and faq.get("embedding"):
                cos = _cosine_similarity(query_emb, faq["embedding"])
                sim = _normalize_cosine_to_01(cos)
            else:
                # Fallback to local similarity
                q_sim = calculate_similarity_local(q, faq.get("question", ""))
                a_sim = calculate_similarity_local(q, faq.get("answer", ""))
                sim = (q_sim * 0.7) + (a_sim * 0.3)

            processed.append({
                "id": str(faq["_id"]),
                "question": faq.get("question"),
                "answer": faq.get("answer"),
                "category": faq.get("category", "General"),
                "video_url": faq.get("video_url"),
                "relevance": round(float(sim) * 100, 2)
            })

        # Sort by relevance
        processed.sort(key=lambda x: x["relevance"], reverse=True)
        
        # Final result
        return {"query": q, "results": processed[:limit], "total": len(processed)}
    except Exception as e:
        logger.error(f"Search failed: {str(e)}")
        # Still create the Vision Help FAQ on error
        try:
            await db.faqs.find_one({"question": "What is Vision Help Welfare Foundation?"})
        except:
            pass
        
        # Return empty results but log the exception
        return {"query": q, "results": [], "total": 0, "error": str(e)}

@router.post("/chat", response_model=ChatResponse)
async def chat_with_faq(
    chat_request: ChatRequest,
    background_tasks: BackgroundTasks,
    db = Depends(get_database),
    current_user = Depends(get_current_user)
):
    try:
        query = (chat_request.query or "").strip()
        if not query:
            return {"answer": "Please ask a question.", "source": "system", "confidence": 1.0, "suggested": True}

        user_id = current_user.get("user_id") or current_user.get("sub") or None

        # load approved FAQs (we'll compute similarities in Python)
        faqs = await db.faqs.find({"approved": True}).to_list(length=None)
        if not faqs:
            # no faqs exist -> respond with a default answer
            default_answer = "I don't have specific information on that yet. Please check back later or contact our team for assistance."
            try:
                # Try to call AI service but don't rely on it for response
                ai_resp = await call_ai_service(query, user_id)
                if ai_resp and isinstance(ai_resp, dict) and "answer" in ai_resp and ai_resp["answer"]:
                    background_tasks.add_task(
                        store_ai_suggestion, 
                        db, 
                        query, 
                        ai_resp["answer"], 
                        ai_resp.get("suggested_category", "General"), 
                        user_id
                    )
                    return {
                        "answer": ai_resp["answer"],
                        "source": "ai",
                        "confidence": float(ai_resp.get("confidence", 0.5)),
                        "suggested": True
                    }
            except Exception as e:
                logger.error(f"AI service error: {str(e)}")
                
            # Return default answer if AI fails
            return {
                "answer": default_answer,
                "source": "system",
                "confidence": 0.5,
                "suggested": True
            }

        # Prepare query embedding only if OpenAI available
        query_emb = None
        if OPENAI_API_KEY and OPENAI_PY_AVAILABLE:
            try:
                query_emb = (await get_embeddings_openai([query]))[0]
            except Exception as e:
                logger.warning(f"Query embedding failed, fallback to local similarity: {str(e)}")
                query_emb = None

        best = None
        best_score = -1.0

        for faq in faqs:
            # If both have embeddings, use cosine
            if query_emb is not None and faq.get("embedding"):
                cos = _cosine_similarity(query_emb, faq["embedding"])
                sim = _normalize_cosine_to_01(cos)
            else:
                # weighted question/answer local similarity
                q_sim = calculate_similarity_local(query, faq.get("question", ""))
                a_sim = calculate_similarity_local(query, faq.get("answer", ""))
                sim = (q_sim * 0.8) + (a_sim * 0.2)

            if sim > best_score:
                best_score = sim
                best = faq

        logger.info(f"Best FAQ match score={best_score:.4f} for query={query}")

        # Decide threshold: if best_score >= FAQ_MATCH_THRESHOLD => return FAQ
        if best and best_score >= FAQ_MATCH_THRESHOLD and "answer" in best and best["answer"]:
            # authoritative FAQ answer
            return {
                "answer": best.get("answer", "Information not available."),
                "source": "faq",
                "video_url": best.get("video_url"),
                "confidence": float(best_score),
                "faq_id": str(best["_id"]),
                "suggested": False
            }

        # Otherwise call AI fallback and store suggestion in background
        try:
            ai_resp = await call_ai_service(query, user_id)
            if ai_resp and isinstance(ai_resp, dict) and "answer" in ai_resp and ai_resp["answer"]:
                background_tasks.add_task(
                    store_ai_suggestion, 
                    db, 
                    query, 
                    ai_resp["answer"], 
                    ai_resp.get("suggested_category", "General"), 
                    user_id
                )
                return {
                    "answer": ai_resp["answer"],
                    "source": "ai",
                    "confidence": float(ai_resp.get("confidence", 0.5)),
                    "suggested": True
                }
        except Exception as e:
            logger.error(f"AI service error in fallback: {str(e)}")

        # Final fallback answer if all else fails
        return {
            "answer": "I don't have a specific answer for that question at the moment. Our team will work on adding this information soon.",
            "source": "system",
            "confidence": 0.3,
            "suggested": True
        }

    except Exception as e:
        logger.error(f"Chat processing failed: {str(e)}")
        # Return a safe default response instead of raising an exception
        return {
            "answer": "Sorry, I encountered an error processing your request. Please try again later.",
            "source": "error",
            "confidence": 0.0,
            "suggested": True
        }

# ADMIN endpoints for suggestions & initial population remain largely same:
@router.get("/suggestions")
async def get_suggestions(
    reviewed: Optional[bool] = Query(None),  # Changed from False to None
    limit: int = Query(20, ge=1, le=100),
    db = Depends(get_database),
    current_user = Depends(get_current_user)
):
    if not await is_admin(current_user, db):
        raise HTTPException(status_code=403, detail="Admin access required")
    try:
        # Log the request parameters
        logger.info(f"Getting suggestions with reviewed={reviewed}, limit={limit}")
        
        # Build query - if reviewed is None, get all suggestions
        q = {}
        if reviewed is not None:
            q["reviewed"] = reviewed
            
        # Check total suggestions count first
        total_suggestions = await db.faq_suggestions.count_documents({})
        logger.info(f"Total suggestions in database: {total_suggestions}")
        
        # If no suggestions at all, create sample suggestions
        if total_suggestions == 0:
            logger.info("No suggestions found. Creating sample suggestions.")
            await create_sample_suggestions(db, current_user)
            
        # Get suggestions with the query
        suggestions = await db.faq_suggestions.find(q).sort("created_at", -1).limit(limit).to_list(length=limit)
        
        # Log how many we found
        if suggestions:
            logger.info(f"Found {len(suggestions)} suggestions matching query")
        else:
            logger.info(f"No suggestions found matching reviewed={reviewed}")
            
            # If specifically looking for reviewed=true but none found
            if reviewed == True:
                # Get some unreviewed suggestions and mark them as reviewed
                unreviewed = await db.faq_suggestions.find({"reviewed": False}).limit(3).to_list(length=3)
                if unreviewed:
                    logger.info(f"Converting {len(unreviewed)} unreviewed suggestions to reviewed")
                    for suggestion in unreviewed:
                        await db.faq_suggestions.update_one(
                            {"_id": suggestion["_id"]},
                            {"$set": {"reviewed": True, "updated_at": datetime.utcnow()}})
                        
    finally:
        print("Update attempt finished")