from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, Query, Form, Body
from typing import Optional, Literal, List, Dict, Any
from datetime import datetime, timedelta
from pydantic import BaseModel, Field, validator
from app.database import get_database
from app.auth.deps import get_current_user, get_current_admin_user
from motor.motor_asyncio import AsyncIOMotorDatabase
from app.utils.payment_gateway import calculate_price
from bson import ObjectId
import uuid
import razorpay
from app.database.crud.membership import (
    get_available_plans, 
    process_payment, 
    unlock_role_benefits, 
    PaymentMethod,
    process_role_payment  # Import the new function
)
from app.routes.success_tracker import serialize_mongodb_doc
from app.database.schemas.membership import PaymentMethod , MembershipRequest # Import the PaymentMethod schema
from app.utils.payment_gateway import client as razorpay_client  # Import the configured client

router = APIRouter(prefix="/membership", tags=["Membership & Subscription Management"])

# Use the configured Razorpay client from payment_gateway.py
# razorpay_client is now imported from payment_gateway.py

# Define the available roles and their fees
ROLE_FEES = {
    "Career Seeker": 0,
    "Skill Mentor": 51,
    "Career Supporter": 500,
    "Vision Marshal": {"basic": 500, "premium": 2000}
}

# =================== API ENDPOINTS ===================

@router.post("/pay")
async def create_membership(
    request: MembershipRequest,
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    try:
        # Check if this is a campaign donation
        if request.donation_type == "campaign" and request.campaign_id and request.amount:
            return await handle_campaign_donation(request, db)
        
        # Original membership logic
        price = calculate_price(request.role, None, request.membership_plan)

        membership_data = {
            "role": request.role,
            "membership_plan": request.membership_plan,
            "price": price,
            "status": "pending" if price > 0 else "active",
            "created_at": datetime.utcnow()
        }

        # Insert membership in DB
        result = await db["memberships"].insert_one(membership_data)
        membership_id = str(result.inserted_id)

        # If price = 0 → No payment needed
        if price == 0:
            # Generate a free membership order ID
            free_order_id = f"free_order_{membership_id[:8]}_{int(datetime.utcnow().timestamp())}"
            
            await db["memberships"].update_one(
                {"_id": result.inserted_id},
                {"$set": {
                    "status": "active",
                    "order_id": free_order_id,
                    "payment_type": "free"
                }}
            )
            return {
                "success": True,
                "message": "Membership activated (no payment required)",
                "membership_id": membership_id,
                "price": 0,
                "order_id": free_order_id,
                "payment_type": "free"
            }

        # Else create Razorpay order
        if razorpay_client is None:
            raise HTTPException(status_code=500, detail="Payment gateway not configured properly")
        
        try:
            order = razorpay_client.order.create({
                "amount": price * 100,  # in paise
                "currency": "INR",
                "receipt": f"membership_{membership_id}",
                "payment_capture": 1
            })
        except Exception as razorpay_error:
            raise HTTPException(
                status_code=500, 
                detail=f"Razorpay order creation failed: {str(razorpay_error)}"
            )

        # Save order_id in DB
        await db["memberships"].update_one(
            {"_id": result.inserted_id},
            {"$set": {
                "razorpay_order_id": order["id"],
                "order_id": order["id"],
                "payment_type": "paid"
            }}
        )

        return {
            "success": True,
            "message": "Membership created. Complete payment to activate.",
            "membership_id": membership_id,
            "price": price,
            "order_id": order["id"],
            "razorpay_key": "rzp_test_R7vr1NPWxZnHX7",  # Include working Razorpay key for frontend
            "payment_type": "paid"
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Payment initialization failed: {str(e)}")

async def handle_campaign_donation(request: MembershipRequest, db: AsyncIOMotorDatabase):
    try:
        # Validate amount
        if request.amount < 1:
            raise HTTPException(status_code=400, detail="Minimum donation amount is ₹1")
        
        # Check if campaign exists
        campaign = await db["campaigns"].find_one({"_id": ObjectId(request.campaign_id)})
        if not campaign:
            raise HTTPException(status_code=404, detail="Campaign not found")
        
        # Create donation record
        donation_data = {
            "campaign_id": request.campaign_id,
            "donor_name": request.donor_name,
            "donor_email": request.donor_email,
            "donor_phone": request.donor_phone,
            "amount": request.amount,
            "status": "pending",
            "donation_type": "campaign",
            "created_at": datetime.utcnow()
        }

        # Insert donation in DB
        result = await db["campaign_donations"].insert_one(donation_data)
        donation_id = str(result.inserted_id)

        # Create Razorpay order
        if razorpay_client is None:
            raise HTTPException(status_code=500, detail="Payment gateway not configured properly")
        
        try:
            order = razorpay_client.order.create({
                "amount": int(request.amount * 100),  # in paise
                "currency": "INR",
                "receipt": f"campaign_donation_{donation_id}",
                "payment_capture": 1
            })
        except Exception as razorpay_error:
            raise HTTPException(
                status_code=500, 
                detail=f"Razorpay order creation failed: {str(razorpay_error)}"
            )

        # Save order_id in donation record
        await db["campaign_donations"].update_one(
            {"_id": result.inserted_id},
            {"$set": {
                "razorpay_order_id": order["id"],
                "order_id": order["id"],
                "payment_type": "paid"
            }}
        )

        return {
            "success": True,
            "message": f"Donation initiated for Campaign #{request.campaign_id[-6:]}. Complete payment to confirm.",
            "donation_id": donation_id,
            "campaign_id": request.campaign_id,
            "amount": request.amount,
            "order_id": order["id"],
            "razorpay_key": "rzp_test_R7vr1NPWxZnHX7",
            "payment_type": "paid",
            "donor_name": request.donor_name,
            "donor_email": request.donor_email
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Campaign donation failed: {str(e)}")

@router.get("/roles")
async def get_available_roles(
    user = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_database)
): 
    try:
        # Get user's current role
        user_data = await db.vision_users.find_one({"_id": user.get("user_id")})
        current_role = user_data.get("role") if user_data else None
        
        # Define role details
        roles = [
            {
                "role_id": "career_seeker",
                "name": "Career Seeker",
                "fee": 0,
                "fee_formatted": "₹0",
                "benefits": [
                    "Access to job listings",
                    "Training opportunities",
                    "Scheme information",
                    "Connect with Marshals & Supporters"
                ],
                "is_current": current_role == "Career Seeker"
            },
            {
                "role_id": "skill_mentor",
                "name": "Skill Mentor",
                "fee": 51,
                "fee_formatted": "₹51",
                "benefits": [
                    "Mentorship platform access",
                    "Official certification",
                    "Honor Board recognition",
                    "Teaching resources"
                ],
                "is_current": current_role == "Skill Mentor"
            },
            {
                "role_id": "career_supporter",
                "name": "Career Supporter",
                "fee": 500,
                "fee_formatted": "₹500",
                "benefits": [
                    "Post job opportunities",
                    "Connect with qualified Seekers",
                    "Marshal network access",
                    "Impact tracking"
                ],
                "icon": "handshake",
                "is_current": current_role == "Career Supporter"
            },
            {
                "role_id": "vision_marshal_basic",
                "name": "Vision Marshal (Basic)",
                "fee": 500,
                "fee_formatted": "₹500",
                "benefits": [
                    "Official ID card",
                    "Basic Marshal kit",
                    "Local coordination rights",
                    "Reporting tools access"
                ],
                "is_current": current_role == "Vision Marshal" and user_data.get("marshal_tier") == "basic"
            },
            {
                "role_id": "vision_marshal_premium",
                "name": "Vision Marshal (Premium)",
                "fee": 2000,
                "fee_formatted": "₹2000",
                "benefits": [
                    "Premium Marshal ID & kit",
                    "Leadership opportunities",
                    "Full platform access",
                    "Recognition & incentives",
                    "Training & certification"
                ],
                "is_current": current_role == "Vision Marshal" and user_data.get("marshal_tier") == "premium"
            }
        ]
        
        return {
            "success": True,
            "roles": roles,
            "current_role": current_role,
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching roles: {str(e)}")

@router.post("/select-role")
async def select_user_role(
    role_id: str = Form(...),  # Use Form instead of direct parameter
    payment_method: Optional[str] = Form(None),  # Use Form for payment_method too
    background_tasks: BackgroundTasks = None,
    db: AsyncIOMotorDatabase = Depends(get_database),
    current_user = Depends(get_current_user)
):
    try:
        # Map role_id to actual role name and fee
        role_mapping = {
            "career_seeker": {"name": "Career Seeker", "fee": 0},
            "skill_mentor": {"name": "Skill Mentor", "fee": 51},
            "career_supporter": {"name": "Career Supporter", "fee": 500},
            "vision_marshal_basic": {"name": "Vision Marshal", "fee": 500, "tier": "basic"},
            "vision_marshal_premium": {"name": "Vision Marshal", "fee": 2000, "tier": "premium"}
        }
        
        if role_id not in role_mapping:
            raise HTTPException(status_code=400, detail="Invalid role selected")
            
        # Get role details
        role_details = role_mapping[role_id]
        role_name = role_details["name"]
        fee = role_details["fee"]
        tier = role_details.get("tier")
        
        # Get user details
        user_id = current_user.get("user_id")
        user = await db.vision_users.find_one({"_id": user_id})
        
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Check if payment is needed
        if fee > 0:
            if not payment_method:
                # Return payment requirements without processing
                return {
                    "success": False,
                    "requires_payment": True,
                    "role": role_name,
                    "fee": fee,
                    "fee_formatted": f"₹{fee}",
                    "payment_methods": ["wallet", "direct_payment", "bank_transfer", "credit_card"],
                    "message": "Payment required to activate this role"
                }
            
            # Process payment using string payment method instead of PaymentMethod schema
            payment_result = await process_role_payment(
                user_id=user_id,
                amount=fee,
                payment_method=payment_method,  # Use the string directly
                payment_details=None,  # No details from form data
                transaction_id=None,  # No transaction ID from form data
                role_name=role_name,
                db=db
            )
            
            if not payment_result["success"]:
                raise HTTPException(
                    status_code=400,
                    detail=f"Payment failed: {payment_result.get('message', 'Unknown error')}"
                )
        
        # Update user profile with new role
        update_data = {"role": role_name, "role_updated_at": datetime.now()} 
        
        # Add tier for Vision Marshal
        if tier:
            update_data["marshal_tier"] = tier
            
        # Add membership expiry (12 months from now) for paid roles
        if fee > 0:
            update_data["role_expiry"] = datetime.now() + timedelta(days=365)
            update_data["role_active"] = True
        
        await db.vision_users.update_one(
            {"_id": user_id},
            {"$set": update_data}
        )
        
        # Create membership record
        membership_id = str(uuid.uuid4())
        membership = {
            "membership_id": membership_id,
            "user_id": user_id,
            "role": role_name,
            "fee": fee,
            "tier": tier,
            "start_date": datetime.now(),
            "end_date": datetime.now() + timedelta(days=365),
            "is_active": True,
            "created_at": datetime.now(),
        }
        
        # Add payment info if applicable
        if fee > 0 and payment_method:
            membership["payment_info"] = {
                "amount": fee,
                "method": payment_method,  # Use string payment method
                "transaction_id": payment_result.get("transaction_id", str(uuid.uuid4())),
                "status": "completed",
                "date": datetime.now()
            }
            
        await db.user_memberships.insert_one(membership)
        
        # Unlock benefits in background if needed
        if background_tasks:
            background_tasks.add_task(unlock_role_benefits, user_id, role_name, db)
            
        # Build appropriate response
        response = {
            "success": True,
            "message": f"You are now a {role_name}!",
            "role": role_name,
            "membership_id": membership_id
        }
        
        # Add payment details if applicable
        if fee > 0:
            response["payment"] = {
                "amount": fee,
                "formatted": f"₹{fee}",
                "method": payment_method,  # Use string payment method
                "status": "completed",
                "receipt_id": f"RCPT-{membership_id[:8]}"
            }
            
        # Add tier info for Vision Marshal
        if tier:
            response["tier"] = tier
            
        # Add expiry info for paid roles
        if fee > 0:
            response["valid_until"] = (datetime.now() + timedelta(days=365)).isoformat()
            
        return response
        
    except Exception as e:
        # Handle any unhandled exceptions
        raise HTTPException(status_code=500, detail=f"Error selecting role: {str(e)}")

@router.get("/my-role")
async def get_user_role_info(
    db: AsyncIOMotorDatabase = Depends(get_database),
    current_user = Depends(get_current_user)
):
  
    
    user_id = current_user.get("user_id")
    
    # Get user details
    user = await db.vision_users.find_one({"_id": user_id})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
        
    user = serialize_mongodb_doc(user)
    role = user.get("role")
    
    # Get active membership
    membership = await db.user_memberships.find_one({
        "user_id": user_id,
        "is_active": True
    })
    
    # Get role benefits
    benefits = []
    
    if role == "Career Seeker":
        benefits = [
            "Access to job listings",
            "Training opportunities",
            "Scheme information",
            "Connect with Marshals & Supporters"
        ]
    elif role == "Skill Mentor":
        benefits = [
            "Mentorship platform access",
            "Official certification",
            "Honor Board recognition",
            "Teaching resources"
        ]
    elif role == "Career Supporter":
        benefits = [
            "Post job opportunities",
            "Connect with qualified Seekers",
            "Marshal network access",
            "Impact tracking"
        ]
    elif role == "Vision Marshal":
        tier = user.get("marshal_tier", "basic")
        if tier == "premium":
            benefits = [
                "Premium Marshal ID & kit",
                "Leadership opportunities",
                "Full platform access",
                "Recognition & incentives",
                "Training & certification"
            ]
        else:
            benefits = [
                "Official ID card",
                "Basic Marshal kit",
                "Local coordination rights",
                "Reporting tools access"
            ]
            
    # Calculate remaining days if membership exists
    days_remaining = 0
    if membership:
        membership = serialize_mongodb_doc(membership)
        if "end_date" in membership:
            days_remaining = (membership["end_date"] - datetime.now()).days
            if days_remaining < 0:
                days_remaining = 0
    
    return {
        "success": True,
        "user_id": user_id,
        "name": user.get("full_name"),
        "role": role,
        "role_active": user.get("role_active", True),
        "role_expiry": user.get("role_expiry"),
        "days_remaining": days_remaining,
        "marshal_tier": user.get("marshal_tier") if role == "Vision Marshal" else None,
        "fee_paid": membership.get("fee") if membership else 0,
        "benefits": benefits,
        "membership_status": "active" if membership and days_remaining > 0 else "inactive",
        "renewal_needed": days_remaining < 7,
        "last_updated": user.get("role_updated_at")
    }

@router.get("/role-upgrades")
async def get_available_role_upgrades(
    db: AsyncIOMotorDatabase = Depends(get_database),
    current_user = Depends(get_current_user)
):
    user_id = current_user.get("user_id")
    
    # Get user details
    user = await db.vision_users.find_one({"_id": user_id})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
        
    current_role = user.get("role")
    
    # Define possible upgrades based on current role
    upgrades = []
    
    if current_role == "Career Seeker":
        upgrades = [
            {
                "role_id": "skill_mentor",
                "name": "Skill Mentor",
                "fee": 51,
                "fee_formatted": "₹51",
                "description": "Become a mentor. Teach others. Get certificate, recognition & Honor Board listing."
            },
            {
                "role_id": "career_supporter",
                "name": "Career Supporter",
                "fee": 500,
                "fee_formatted": "₹500",
                "description": "Support someone with work. Post job/tasks. Connect with Marshal/Seeker."
            },
            {
                "role_id": "vision_marshal_basic",
                "name": "Vision Marshal (Basic)",
                "fee": 500,
                "fee_formatted": "₹500",
                "description": "Report issues, promote awareness, connect local work. Earn & serve."
            }
        ]
    elif current_role == "Skill Mentor":
        upgrades = [
            {
                "role_id": "career_supporter",
                "name": "Career Supporter",
                "fee": 500,
                "fee_formatted": "₹500",
                "description": "Support someone with work. Post job/tasks. Connect with Marshal/Seeker."
            },
            {
                "role_id": "vision_marshal_basic",
                "name": "Vision Marshal (Basic)",
                "fee": 500,
                "fee_formatted": "₹500",
                "description": "Report issues, promote awareness, connect local work. Earn & serve."
            }
        ]
    elif current_role == "Vision Marshal" and user.get("marshal_tier") == "basic":
        upgrades = [
            {
                "role_id": "vision_marshal_premium",
                "name": "Vision Marshal (Premium)",
                "fee": 1500,  # Difference between premium and basic
                "fee_formatted": "₹1500",
                "description": "Upgrade to premium tier with enhanced capabilities and recognition."
            }
        ]
    
    return {
        "success": True,
        "current_role": current_role,
        "available_upgrades": upgrades
    }

@router.get("/plans")
async def get_membership_plans(
    user = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    try:
        # Fetch all available membership plans from the database without creating defaults
        plans_cursor = db.membership_plans.find({"is_active": True})
        plans = [serialize_mongodb_doc(plan) async for plan in plans_cursor]
        
        # If no plans found, add the exact specified plans to the database
        if not plans:
            exact_plans = [
                {
                    "name": "Seeker Support",
                    "description": "Support partial course fee for one Seeker",
                    "price": 100,
                    "duration_months": 1,
                    "benefits": [
                        "Support partial course fee for one Seeker",
                        "Monthly impact updates",
                        "Recognition on our supporter page"
                    ],
                    "is_active": True,
                    "created_at": datetime.now(),
                    "tier": "basic",
                    "role": "Supporter",
                    "impact": "Support partial course fee for one Seeker",
                    "price_formatted": "₹100/month"
                },
                {
                    "name": "Marshal & Mentor Support",
                    "description": "Provide tools or support to one Marshal or Mentor",
                    "price": 500,
                    "duration_months": 1,
                    "benefits": [
                        "Provide tools or support to one Marshal or Mentor",
                        "Monthly newsletter",
                        "Recognition badge on profile",
                        "Access to impact reports"
                    ],
                    "is_active": True,
                    "created_at": datetime.now(),
                    "tier": "silver",
                    "role": "Supporter",
                    "impact": "Provide tools or support to one Marshal or Mentor",
                    "price_formatted": "₹500/month"
                },
                {
                    "name": "Child Education Sponsor",
                    "description": "Sponsor complete 30-day education for one child",
                    "price": 1000,
                    "duration_months": 1,
                    "benefits": [
                        "Sponsor complete 30-day education for one child",
                        "Personalized impact report",
                        "Child's progress updates",
                        "Virtual thank you from the child",
                        "Silver supporter badge"
                    ],
                    "is_active": True,
                    "created_at": datetime.now(),
                    "tier": "gold",
                    "role": "Donor",
                    "impact": "Sponsor complete 30-day education for one child",
                    "price_formatted": "₹1000/month"
                },
                {
                    "name": "Device & Medical Support",
                    "description": "Device support for 5 children or one medical case",
                    "price": 2500,
                    "duration_months": 1,
                    "benefits": [
                        "Device support for 5 children or one medical case",
                        "Detailed impact reports",
                        "Recognition on donor wall",
                        "Quarterly video calls with team",
                        "Gold supporter badge"
                    ],
                    "is_active": True,
                    "created_at": datetime.now(),
                    "tier": "platinum",
                    "role": "Donor",
                    "impact": "Device support for 5 children or one medical case",
                    "price_formatted": "₹2500/month"
                },
                {
                    "name": "Community Impact",
                    "description": "Sponsor education/health for 10 needy individuals",
                    "price": 5000,
                    "duration_months": 1,
                    "benefits": [
                        "Sponsor education/health for 10 needy individuals",
                        "VIP access to all events",
                        "Personalized impact stories",
                        "Featured donor recognition",
                        "Quarterly meeting with leadership",
                        "Platinum supporter badge"
                    ],
                    "is_active": True,
                    "created_at": datetime.now(),
                    "tier": "diamond",
                    "role": "Donor",
                    "impact": "Sponsor education/health for 10 needy individuals",
                    "price_formatted": "₹5000/month"
                }
            ]
            
            # Insert exact plans into the database
            for plan in exact_plans:
                plan["plan_id"] = str(ObjectId())  # Add unique plan ID
                await db.membership_plans.insert_one(plan)
            
            # Fetch the newly inserted plans
            plans_cursor = db.membership_plans.find({"is_active": True})
            plans = [serialize_mongodb_doc(plan) async for plan in plans_cursor]
        
        # Get user's current membership if any
        user_membership = await db.user_memberships.find_one({"user_id": user.get("user_id")})
        current_plan = None
        
        if user_membership:
            user_membership = serialize_mongodb_doc(user_membership)
            
            # Get the plan details if user has a membership
            if "plan_id" in user_membership:
                plan_id = user_membership["plan_id"]
                
                # Handle both ObjectId and string formats
                if ObjectId.is_valid(plan_id):
                    plan = await db.membership_plans.find_one({"_id": ObjectId(plan_id)})
                else:
                    plan = await db.membership_plans.find_one({"_id": plan_id})
                
                if plan:
                    current_plan = serialize_mongodb_doc(plan)
        
        # Prepare response with detailed plan information including formatted prices
        formatted_plans = []
        for plan in plans:
            # Use the price_formatted field directly if available
            formatted_price = plan.get('price_formatted', f"₹{plan.get('price', 0):,}")
            
            # Add formatted fields
            formatted_plan = {
                **plan,
                "formatted_price": formatted_price,
                "duration_text": f"{plan.get('duration_months', 0)} month{'s' if plan.get('duration_months', 0) > 1 else ''}",
                "monthly_price": formatted_price,  # This is already per month
                "benefits_count": len(plan.get('benefits', [])),
                "badge_url": f"/assets/badges/{plan.get('tier', 'basic')}_badge.png",
                "signup_url": f"/api/membership/join/{plan.get('id')}"
            }
            formatted_plans.append(formatted_plan)
        
        # Return the plans and user's current membership
        return {
            "available_plans": formatted_plans,
            "user_current_membership": user_membership if 'user_membership' in locals() else None,
            "current_plan": current_plan if 'current_plan' in locals() else None,
            "total_plans": len(formatted_plans),
            "impact_options": [
                {"price": "₹100/month", "impact": "Support partial course fee for one Seeker"},
                {"price": "₹500/month", "impact": "Provide tools or support to one Marshal or Mentor"},
                {"price": "₹1000/month", "impact": "Sponsor complete 30-day education for one child"},
                {"price": "₹2500/month", "impact": "Device support for 5 children or one medical case"},
                {"price": "₹5000/month", "impact": "Sponsor education/health for 10 needy individuals"}
            ],
            "last_updated": datetime.now()
        }
    except Exception as e:
        # Ensure the error response doesn't contain ObjectId instances
        error_message = str(e)
        raise HTTPException(status_code=500, detail=f"Error fetching membership plans: {error_message}")

# Add a simple endpoint to manually add a plan for testing purposes
@router.post("/admin/add-plan")
async def add_membership_plan(
    name: str,
    description: str,
    price: int,
    duration_months: int,
    tier: str,
    role: str,
    benefits: List[str],
    db: AsyncIOMotorDatabase = Depends(get_database),
    admin = Depends(get_current_admin_user)  # Require admin permissions
):
   
    try:
        new_plan = {
            "plan_id": str(ObjectId()),
            "name": name,
            "description": description,
            "price": price,
            "duration_months": duration_months,
            "benefits": benefits,
            "is_active": True,
            "created_at": datetime.now(),
            "created_by": admin.get("email"),
            "tier": tier,
            "role": role,
            "impact": f"Supporting {tier.capitalize()} level initiatives"
        }
        
        result = await db.membership_plans.insert_one(new_plan)
        
        return {
            "success": True,
            "message": f"Plan '{name}' added successfully",
            "plan_id": new_plan["plan_id"],
            "tier": tier
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error adding plan: {str(e)}")

@router.post("/subscribe")
async def subscribe_to_plan(
    plan_id: str,
    payment_method: PaymentMethod,
    background_tasks: BackgroundTasks,
    db: AsyncIOMotorDatabase = Depends(get_database),
    current_user = Depends(get_current_user)
):
    # Get user details
    user_id = current_user.get("user_id")
    user = await db.vision_users.find_one({"_id": user_id})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Check if user already has an active subscription
    active_sub = await db.memberships.find_one({
        "user_id": user_id,
        "is_active": True,
        "end_date": {"$gt": datetime.utcnow()}
    })
    
    if active_sub:
        raise HTTPException(
            status_code=400, 
            detail="You already have an active subscription. Please cancel it first or wait until it expires."
        )
    
    # Get plan details
    plan = await db.membership_plans.find_one({"plan_id": plan_id})
    if not plan:
        raise HTTPException(status_code=404, detail="Membership plan not found")
    
    # Process payment
    amount = plan["price"]
    payment_result = await process_payment(payment_method, amount, user_id, db)
    
    # Create subscription
    end_date = datetime.utcnow() + timedelta(days=plan["duration_days"])
    subscription = {
        "subscription_id": str(uuid.uuid4()),
        "user_id": user_id,
        "plan_id": plan_id,
        "role": plan["role"],
        "start_date": datetime.utcnow(),
        "end_date": end_date,
        "is_active": True,
        "payment_info": {
            "transaction_id": payment_result["transaction_id"],
            "method": payment_result["method"],
            "amount": amount
        },
        "price_paid": amount,
        "created_at": datetime.utcnow(),
        "auto_renew": False,
        "impact": plan.get("impact", "Supporting Vision Help initiatives")
    }
    
    # Save subscription to database
    await db.memberships.insert_one(subscription)
    
    # Unlock role benefits in background
    background_tasks.add_task(unlock_role_benefits, user_id, plan["role"], db)
    
    # Record the social impact
    await db.impact_records.insert_one({
        "record_id": str(uuid.uuid4()),
        "user_id": user_id,
        "subscription_id": subscription["subscription_id"],
        "plan_name": plan["name"],
        "amount": amount,
        "impact_description": plan.get("impact", "General support"),
        "created_at": datetime.utcnow()
    })
    
    return {
        "success": True,
        "message": f"Successfully subscribed to {plan['name']}",
        "subscription": {
            "subscription_id": subscription["subscription_id"],
            "role": plan["role"],
            "start_date": subscription["start_date"],
            "end_date": subscription["end_date"],
            "is_active": True,
            "benefits": plan["benefits"]
        },
        "payment": {
            "amount": f"₹{amount}",
            "method": payment_result["method"],
            "transaction_id": payment_result["transaction_id"],
        },
        "impact": plan.get("impact", "Supporting Vision Help initiatives"),
    }

@router.get("/my-subscription")
async def get_my_subscription(
    db: AsyncIOMotorDatabase = Depends(get_database),
    current_user = Depends(get_current_user)
):
    user_id = current_user.get("user_id")
    
    # Find active subscription
    subscription = await db.memberships.find_one({
        "user_id": user_id,
        "is_active": True
    })
    
    if not subscription:
        return {
            "success": True,
            "has_subscription": False,
            "available_plans": await get_available_plans(db),
            "message": "Support our cause by subscribing to one of our impact plans.",
            "impact_options": [
                {"price": "₹100/month", "impact": "Support partial course fee for one Seeker"},
                {"price": "₹500/month", "impact": "Provide tools or support to one Marshal or Mentor"},
                {"price": "₹1000/month", "impact": "Sponsor complete 30-day education for one child"},
                {"price": "₹2500/month", "impact": "Device support for 5 children or one medical case"},
                {"price": "₹5000/month", "impact": "Sponsor education/health for 10 needy individuals"}
            ]
        }
    
    # Get plan details
    plan = await db.membership_plans.find_one({"plan_id": subscription["plan_id"]})
    
    # Calculate days remaining
    now = datetime.utcnow()
    end_date = subscription["end_date"]
    days_remaining = (end_date - now).days if end_date > now else 0
    
    # Get impact records
    impact_records = await db.impact_records.find({
        "user_id": user_id,
        "subscription_id": subscription.get("subscription_id")
    }).to_list(10)
    
    return {
        "success": True,
        "has_subscription": True,
        "subscription": {
            "subscription_id": subscription.get("subscription_id"),
            "role": subscription.get("role"),
            "plan_name": plan.get("name") if plan else "Unknown Plan",
            "start_date": subscription.get("start_date"),
            "end_date": subscription.get("end_date"),
            "days_remaining": days_remaining,
            "is_active": subscription.get("is_active", False),
            "auto_renew": subscription.get("auto_renew", False),
            "price_paid": f"₹{subscription.get('price_paid')}"
        },
        "benefits": plan.get("benefits") if plan else [],
        "impact": {
            "description": plan.get("impact", "Supporting Vision Help") if plan else "General support",
            "records": impact_records,
            "total_contribution": f"₹{subscription.get('price_paid', 0)}"
        },
        "renewal_options": {
            "can_renew": days_remaining <= 7,
            "upgrade_options": [p for p in await get_available_plans(db) if p["role"] == subscription["role"] and p["price"] > plan.get("price", 0)] if plan else []
        }
    }

@router.post("/cancel")
async def cancel_subscription(
    subscription_id: str,
    db: AsyncIOMotorDatabase = Depends(get_database),
    current_user = Depends(get_current_user)
):
    user_id = current_user.get("user_id")
    
    # Find the subscription
    subscription = await db.memberships.find_one({
        "subscription_id": subscription_id,
        "user_id": user_id,
        "is_active": True
    })
    
    if not subscription:
        raise HTTPException(status_code=404, detail="Active subscription not found")
    
    # Cancel subscription
    await db.memberships.update_one(
        {"subscription_id": subscription_id},
        {
            "$set": {
                "is_active": False,
                "cancelled_at": datetime.utcnow(),
                "auto_renew": False
            }
        }
    )
    
    # Get plan details for impact message
    plan = await db.membership_plans.find_one({"plan_id": subscription.get("plan_id")})
    impact = plan.get("impact", "supporting our vision") if plan else "supporting our vision"
    
    # User keeps benefits until end date, but auto-renewal is disabled
    return {
        "success": True,
        "message": "Subscription cancelled successfully",
        "subscription_id": subscription_id,
        "end_date": subscription["end_date"],
        "note": "You will retain access to benefits until your subscription end date",
        "impact_message": f"Thank you for {impact}. Your support has made a difference!"
    }

@router.post("/toggle-auto-renew")
async def toggle_auto_renewal(
    subscription_id: str,
    enable: bool,
    db: AsyncIOMotorDatabase = Depends(get_database),
    current_user = Depends(get_current_user)
):
    user_id = current_user.get("user_id")
    
    # Update auto-renew setting
    result = await db.memberships.update_one(
        {
            "subscription_id": subscription_id,
            "user_id": user_id,
            "is_active": True
        },
        {"$set": {"auto_renew": enable}}
    )
    
    if result.modified_count == 0:
        raise HTTPException(status_code=404, detail="Active subscription not found")
    
    return {
        "success": True,
        "message": f"Auto-renewal {'enabled' if enable else 'disabled'} successfully",
        "subscription_id": subscription_id,
        "auto_renew": enable
    }

@router.get("/expiry-tracker")
async def subscription_expiry_tracker(
    days_threshold: int = Query(7, description="Notify about subscriptions expiring within this many days"),
    db: AsyncIOMotorDatabase = Depends(get_database),
    current_user = Depends(get_current_admin_user)
):
    threshold_date = datetime.utcnow() + timedelta(days=days_threshold)
    
    # Find subscriptions nearing expiration
    expiring_soon = await db.memberships.find({
        "is_active": True,
        "end_date": {
            "$gt": datetime.utcnow(),
            "$lt": threshold_date
        }
    }).to_list(100)
    
    # Get user details for each subscription
    result = []
    for sub in expiring_soon:
        user = await db.vision_users.find_one({"_id": sub["user_id"]})
        if user:
            result.append({
                "subscription_id": sub["subscription_id"],
                "user_id": sub["user_id"],
                "user_name": user.get("full_name", "Unknown User"),
                "user_email": user.get("email", "No email"),
                "role": sub["role"],
                "end_date": sub["end_date"],
                "days_remaining": (sub["end_date"] - datetime.utcnow()).days,
                "auto_renew": sub.get("auto_renew", False)
            })
    
    return {
        "success": True,
        "expiring_count": len(result),
        "expiring_subscriptions": result,
        "days_threshold": days_threshold
    }

@router.get("/impact-summary")
async def get_impact_summary(
    db: AsyncIOMotorDatabase = Depends(get_database),
    current_user = Depends(get_current_user)
):
    user_id = current_user.get("user_id")
    
    # Get all user's subscriptions (active and past)
    subscriptions = await db.memberships.find({
        "user_id": user_id
    }).to_list(100)
    
    # Calculate total contribution
    total_contribution = sum(sub.get("price_paid", 0) for sub in subscriptions)
    
    # Determine overall impact based on contribution amount
    impact_metrics = {
        "seekers_supported": 0,
        "marshals_supported": 0,
        "children_educated": 0,
        "devices_provided": 0,
        "medical_cases_supported": 0,
        "individuals_helped": 0
    }
    
    for sub in subscriptions:
        amount = sub.get("price_paid", 0)
        
        if amount >= 100:
            impact_metrics["seekers_supported"] += 1
        
        if amount >= 500:
            impact_metrics["marshals_supported"] += 1
        
        if amount >= 1000:
            impact_metrics["children_educated"] += 1
        
        if amount >= 2500:
            # Either 5 devices or 1 medical case
            impact_metrics["devices_provided"] += 5
            impact_metrics["medical_cases_supported"] += 1
        
        if amount >= 5000:
            impact_metrics["individuals_helped"] += 10
    
    # Get current plan details if user has an active subscription
    active_sub = next((sub for sub in subscriptions if sub.get("is_active", False) and sub.get("end_date", datetime.min) > datetime.utcnow()), None)
    current_plan = None
    if active_sub:
        current_plan = await db.membership_plans.find_one({"plan_id": active_sub["plan_id"]})
    
    return {
        "success": True,
        "user_id": user_id,
        "total_contribution": f"₹{total_contribution}",
        "subscription_count": len(subscriptions),
        "active_subscription": bool(active_sub),
        "current_plan": current_plan["name"] if current_plan else None,
        "impact_metrics": impact_metrics,
        "impact_summary": [
            {"price": "₹100/month", "impact": "Support partial course fee for one Seeker"},
            {"price": "₹500/month", "impact": "Provide tools or support to one Marshal or Mentor"},
            {"price": "₹1000/month", "impact": "Sponsor complete 30-day education for one child"},
            {"price": "₹2500/month", "impact": "Device support for 5 children or one medical case"},
            {"price": "₹5000/month", "impact": "Sponsor education/health for 10 needy individuals"}
        ],
        "next_milestone": get_next_milestone(total_contribution)
    }

def get_next_milestone(total_contribution):
    milestones = [
        {"threshold": 100, "impact": "Support partial course fee for one Seeker"},
        {"threshold": 500, "impact": "Provide tools or support to one Marshal or Mentor"},
        {"threshold": 1000, "impact": "Sponsor complete 30-day education for one child"},
        {"threshold": 2500, "impact": "Device support for 5 children or one medical case"},
        {"threshold": 5000, "impact": "Sponsor education/health for 10 needy individuals"},
        {"threshold": 10000, "impact": "Transform an entire community with education and health support"}
    ]
    
    for milestone in milestones:
        if total_contribution < milestone["threshold"]:
            remaining = milestone["threshold"] - total_contribution
            return {
                "next_level": f"₹{milestone['threshold']}",
                "remaining": f"₹{remaining}",
                "impact": milestone["impact"],
                "progress_percent": int((total_contribution / milestone["threshold"]) * 100)
            }
    
    # If beyond all thresholds, suggest doubling impact
    return {
        "next_level": f"₹{total_contribution * 2}",
        "remaining": f"₹{total_contribution}",
        "impact": "Double your amazing impact",
        "progress_percent": 100
    }
def get_next_milestone(total_contribution):
    milestones = [
        {"threshold": 100, "impact": "Support partial course fee for one Seeker"},
        {"threshold": 500, "impact": "Provide tools or support to one Marshal or Mentor"},
        {"threshold": 1000, "impact": "Sponsor complete 30-day education for one child"},
        {"threshold": 2500, "impact": "Device support for 5 children or one medical case"},
        {"threshold": 5000, "impact": "Sponsor education/health for 10 needy individuals"},
        {"threshold": 10000, "impact": "Transform an entire community with education and health support"}
    ]
    
    for milestone in milestones:
        if total_contribution < milestone["threshold"]:
            remaining = milestone["threshold"] - total_contribution
            return {
                "next_level": f"₹{milestone['threshold']}",
                "remaining": f"₹{remaining}",
                "impact": milestone["impact"],
                "progress_percent": int((total_contribution / milestone["threshold"]) * 100)
            }
    
    # If beyond all thresholds, suggest doubling impact
    return {
        "next_level": f"₹{total_contribution * 2}",
        "remaining": f"₹{total_contribution}",
        "impact": "Double your amazing impact",
        "progress_percent": 100
    }
    
