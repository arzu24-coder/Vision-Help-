from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException, Request, Header
from fastapi.responses import FileResponse
from typing import List
from app.database.__init__ import get_database
from fastapi.responses import RedirectResponse
from app.database.crud import donation_crud
from app.utils.payment_gateway import send_email_receipt, render_receipt_html
from datetime import datetime
import uuid
import os
from app.database.schemas.donation import CampaignCreate, CampaignResponse, DonationInit, DonationInitResponse, DirectDonateRequest, DonateRequestEnroll

from app.database.models.donation import DonationModel
from app.utils.payment_gateway import (
    create_razorpay_order, create_stripe_payment_intent,
    verify_razorpay_signature, verify_stripe_event
)
from uuid import uuid4
import hmac
import hashlib
import razorpay
from pydantic import BaseModel
from bson import ObjectId

router = APIRouter(prefix="/donations", tags=["Donations"])

# Razorpay credentials
RAZORPAY_KEY_ID = "rzp_test_R7vr1NPWxZnHX7"
RAZORPAY_KEY_SECRET = "R8O0b4amJRxjWsK9HyZvMowZ"
WEBHOOK_SECRET = "myRazorSecret4567"

# Razorpay client
client = razorpay.Client(auth=(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET))

def serialize_doc(doc):
    if doc is None:
        return None
    if isinstance(doc, list):
        return [serialize_doc(item) for item in doc]
    if isinstance(doc, dict):
        return {
            key: (
                str(value) if key == "_id" else
                value.isoformat() if hasattr(value, "isoformat") else
                serialize_doc(value) if isinstance(value, (dict, list)) else
                value
            )
            for key, value in doc.items()
        }
    return doc

@router.post("/donate")
async def create_donation(request: DirectDonateRequest):
    try:
        db = get_database()
        
        donation_data = {
            "donor_name": request.donor_name,
            "donor_email": request.donor_email,
            "donor_phone": request.donor_phone,
            "amount": float(request.amount),
            "status": "pending",
            "created_at": datetime.utcnow()
        }

        # Save donation entry in DB
        result = await db["donations"].insert_one(donation_data)
        donation_id = str(result.inserted_id)

        # Create Razorpay order
        order = client.order.create({
            "amount": int(float(request.amount) * 100),  # Razorpay requires paise
            "currency": "INR",
            "receipt": f"donation_{donation_id}",
            "payment_capture": 1
        })

        # Update DB with Razorpay order_id
        await db["donations"].update_one(
            {"_id": result.inserted_id},
            {"$set": {"razorpay_order_id": order["id"]}}
        )

        return {
            "success": True,
            "message": "Donation created. Complete payment to confirm.",
            "donation_id": donation_id,
            "amount": float(request.amount),
            "order_id": order["id"],
            "razorpay_key": RAZORPAY_KEY_ID   # send to frontend for Razorpay checkout
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/donate")
async def create_donation(request: DonateRequestEnroll):
    try:
        db = get_database()
        
        donation_data = {
            "full_name":request.full_name,
            "email": request.email,
            "phone": request.phone,
            "amount": float(request.amount),
            "status": "pending",
            "created_at": datetime.utcnow()
        }

        # Save donation entry in DB
        result = await db["enroll"].insert_one(donation_data)
        donation_id = str(result.inserted_id)

        # Create Razorpay order
        order = client.order.create({
            "amount": int(float(request.amount) * 100),  # Razorpay requires paise
            "currency": "INR",
            "receipt": f"donation_{donation_id}",
            "payment_capture": 1
        })

        # Update DB with Razorpay order_id
        await db["enroll"].update_one(
            {"_id": result.inserted_id},
            {"$set": {"razorpay_order_id": order["id"]}}
        )

        return {
            "success": True,
            "message": "enroll successfully, Complete payment to confirm.",
            "enroll_id": donation_id,
            "amount": float(request.amount),
            "order_id": order["id"],
            "razorpay_key": RAZORPAY_KEY_ID   # send to frontend for Razorpay checkout
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/", response_model=CampaignResponse)
async def create_campaign(
    title: str = Form(...),
    description: str = Form(...),
    goal: float = Form(...),
    category: str = Form(...),
    location: str = Form(...),
    duration: int = Form(...),
    proof_image: UploadFile = File(None),
    proof_video: UploadFile = File(None),
    db=Depends(get_database)
):
    try:
        # Handle image file upload
        proof_image_path = None
        if proof_image and proof_image.filename:
            # Save uploaded image file
            upload_dir = "/www/wwwroot/amit/vision/VisionHelpProject/uploads/campaigns"
            os.makedirs(upload_dir, exist_ok=True)
            
            file_extension = proof_image.filename.split('.')[-1] if '.' in proof_image.filename else 'jpg'
            filename = f"{uuid.uuid4()}.{file_extension}"
            file_path = os.path.join(upload_dir, filename)
            
            with open(file_path, "wb") as buffer:
                content = await proof_image.read()
                buffer.write(content)
            
            proof_image_path = f"https://vision.soheru.tech:8000/donations/files/{filename}"
        
        # Handle video file upload
        proof_video_path = None
        if proof_video and proof_video.filename:
            # Save uploaded video file
            upload_dir = "/www/wwwroot/amit/vision/VisionHelpProject/uploads/campaigns"
            os.makedirs(upload_dir, exist_ok=True)
            
            file_extension = proof_video.filename.split('.')[-1] if '.' in proof_video.filename else 'mp4'
            filename = f"{uuid.uuid4()}.{file_extension}"
            file_path = os.path.join(upload_dir, filename)
            
            with open(file_path, "wb") as buffer:
                content = await proof_video.read()
                buffer.write(content)
            
            proof_video_path = f"https://vision.soheru.tech:8000/donations/files/{filename}"
        
        # Calculate end date based on duration
        from datetime import timedelta
        current_time = datetime.utcnow()
        end_date = current_time + timedelta(days=duration)
        
        doc = {
            "title": title,
            "description": description,
            "goal_amount": goal,
            "category": category,
            "location": location,
            "duration": duration,
            "collected_amount": 0.0,
            "verified": False,
            "created_at": current_time,
            "updated_at": current_time,
            "end_date": end_date,
            "proof_image": proof_image_path,
            "proof_video": proof_video_path
        }
        
        res = await db.campaigns.insert_one(doc)
        doc["id"] = str(res.inserted_id)
        
        # Remove the MongoDB _id field before passing to CampaignResponse
        if "_id" in doc:
            del doc["_id"]
        
        return CampaignResponse(**doc)
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to create campaign: {str(e)}")

@router.get("/files/{filename}")
async def serve_uploaded_file(filename: str):
    file_path = os.path.join("/www/wwwroot/amit/vision/VisionHelpProject/uploads/campaigns", filename)
    if os.path.exists(file_path):
        return FileResponse(file_path)
    else:
        raise HTTPException(status_code=404, detail="File not found")

@router.get("/", response_model=list[CampaignResponse])
async def list_campaigns():
    db = get_database()  # <-- add parentheses to call the function
    # Show all campaigns (both verified and unverified) so Vision Marshal campaigns appear immediately
    rows = await db.campaigns.find({}).sort("created_at", -1).to_list(200)
    out = []
    for r in rows:
        # Remove MongoDB _id field and create a clean document for CampaignResponse
        campaign_doc = {
            "id": str(r["_id"]),
            "title": r.get("title", "Untitled Campaign"),
            "description": r.get("description", "No description provided"),
            "goal_amount": r.get("goal_amount", 0.0),
            "category": r.get("category", "general"),
            "location": r.get("location", "Not specified"),
            "duration": r.get("duration", 30),
            "collected_amount": r.get("collected_amount", 0.0),
            "verified": r.get("verified", False),
            "created_at": r.get("created_at", datetime.utcnow()),
            "updated_at": r.get("updated_at", datetime.utcnow()),
            "end_date": r.get("end_date", datetime.utcnow()),
            "proof_image": r.get("proof_image"),
            "proof_video": r.get("proof_video")
        }
        out.append(CampaignResponse(**campaign_doc))
    return out

@router.put("/{campaign_id}/verify")
async def verify_campaign(campaign_id: str):
    db=get_database()
    ok = await db.campaigns.update_one(
        {"_id": ObjectId(campaign_id)},
        {"$set": {"verified": True, "updated_at": datetime.utcnow()}}
    )
    if ok.modified_count == 0:
        raise HTTPException(404, "Campaign not found")
    return {"message": "Campaign verified"}
def _receipt_no():
    return f"VH-{uuid.uuid4().hex[:10].upper()}"

from app.database.schemas.donation import DonationModel, DonationInit, DonationInitResponse, DonationVerifyRequest
# Razorpay client only
razorpay_client = razorpay.Client(auth=(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET))
def _receipt_no():
    return f"VH-{uuid.uuid4().hex[:10].upper()}"


# ---------------- INIT DONATION ---------------- #
@router.post("/init", response_model=DonationInitResponse)
async def init_donation(payload: DonationInit):
    db = get_database()

    # Validate campaign
    campaign = await db.campaigns.find_one({"_id": ObjectId(payload.campaign_id)})
    if not campaign or not campaign.get("verified"):
        raise HTTPException(404, "Campaign not found or not verified")

    # Create donation doc
    donation = DonationModel(
        donor_name=payload.donor_name,
        donor_email=payload.donor_email,
        donor_phone=payload.donor_phone,
        amount=payload.amount,
        currency=payload.currency,
        campaign_id=payload.campaign_id,
        provider=payload.provider,
        status="PENDING",
    ).dict()

    res = await db.donations.insert_one(donation)
    donation_id = str(res.inserted_id)

    # Acknowledgement email
    try:
        await send_email_receipt(
            payload.donor_email,
            "Thank you for your donation – Vision Help",
            f"Dear {payload.donor_name},<br><br>"
            f"Thank you for initiating your donation of {payload.currency.upper()} {payload.amount} "
            f"to Vision Help. Your donation will be processed soon.<br><br>Regards,<br>Vision Help Team"
        )
    except Exception:
        pass

    # ---------------- Razorpay only ---------------- #
    if payload.provider == "razorpay":
        order = razorpay_client.order.create({
            "amount": int(payload.amount * 100),  # Razorpay expects paise
            "currency": payload.currency,
            "receipt": _receipt_no(),
        })

        await db.donations.update_one(
            {"_id": res.inserted_id},
            {"$set": {"provider_order_id": order["id"], "updated_at": datetime.utcnow()}}
        )

        return DonationInitResponse(
            donation_id=donation_id,
            provider="razorpay",
            razorpay_order_id=order["id"],
            razorpay_key_id=RAZORPAY_KEY_ID,
            client_secret="",  # <-- Set to empty string for Razorpay
            amount=payload.amount,
            currency=payload.currency
        )

    # If not razorpay, raise error
    raise HTTPException(400, "Unsupported payment provider")

# ---------------- VERIFY DONATION ---------------- #
@router.post("/verify")
async def verify_donation(payload: DonationVerifyRequest):
    db = get_database()
    donation = await db.donations.find_one({"_id": ObjectId(payload.donation_id)})
    if not donation:
        raise HTTPException(404, "Donation not found")

    # ---------------- Razorpay only ---------------- #
    if donation["provider"] == "razorpay":
        try:
            razorpay_client.utility.verify_payment_signature({
                "razorpay_order_id": payload.order_id,
                "razorpay_payment_id": payload.payment_id,
                "razorpay_signature": payload.signature,
            })

            await db.donations.update_one(
                {"_id": ObjectId(payload.donation_id)},
                {"$set": {"status": "SUCCESS", "payment_id": payload.payment_id, "updated_at": datetime.utcnow()}}
            )

            return {"status": "success", "donation_id": payload.donation_id, "payment_id": payload.payment_id}

        except Exception as e:
            await db.donations.update_one(
                {"_id": ObjectId(payload.donation_id)},
                {"$set": {"status": "FAILED", "updated_at": datetime.utcnow()}}
            )
            raise HTTPException(400, f"Payment verification failed: {str(e)}")

            await db.donations.update_one(
                {"_id": ObjectId(payload.donation_id)},
                {"$set": {"status": "SUCCESS", "payment_id": payload.payment_id, "updated_at": datetime.utcnow()}}
            )

            return {"status": "success", "donation_id": payload.donation_id, "payment_id": payload.payment_id}

        except Exception as e:
            await db.donations.update_one(
                {"_id": ObjectId(payload.donation_id)},
                {"$set": {"status": "FAILED", "updated_at": datetime.utcnow()}}
            )
            raise HTTPException(400, f"Payment verification failed: {str(e)}")
# === ANALYTICS ENDPOINTS ===

@router.get("/analytics")
async def get_donations_analytics(db=Depends(get_database)):
    """
    Get comprehensive analytics data for donations and campaigns
    Returns data needed for dashboard analytics including:
    - Total views, donations, revenue
    - Daily trends for last 7 days
    - Success metrics
    """
    try:
        # Get all campaigns
        campaigns_cursor = db.campaigns.find({})
        campaigns = await campaigns_cursor.to_list(length=None)
        
        # Get all donations
        donations_cursor = db.donations.find({"status": {"$in": ["SUCCESS", "completed"]}})
        donations = await donations_cursor.to_list(length=None)
        
        # Calculate total metrics
        total_views = sum(campaign.get('views', 0) for campaign in campaigns)
        total_donations = len(donations)
        total_revenue = sum(donation.get('amount', 0) for donation in donations)
        
        # Calculate success rate
        completed_campaigns = sum(1 for campaign in campaigns if campaign.get('collected_amount', 0) >= campaign.get('goal_amount', 1))
        success_rate = round((completed_campaigns / len(campaigns)) * 100) if campaigns else 0
        
        # Generate last 7 days data
        from datetime import datetime, timedelta
        last_7_days = []
        
        for i in range(7):
            date = datetime.now() - timedelta(days=6-i)
            date_str = date.strftime('%Y-%m-%d')
            
            # Count donations for this date
            day_donations = sum(1 for donation in donations 
                              if donation.get('created_at') and 
                              donation['created_at'].strftime('%Y-%m-%d') == date_str)
            
            # Calculate revenue for this date
            day_revenue = sum(donation.get('amount', 0) for donation in donations 
                            if donation.get('created_at') and 
                            donation['created_at'].strftime('%Y-%m-%d') == date_str)
            
            # Calculate views for this date (from campaigns created/updated)
            day_views = sum(campaign.get('views', 0) for campaign in campaigns 
                           if campaign.get('created_at') and 
                           campaign['created_at'].strftime('%Y-%m-%d') == date_str)
            
            last_7_days.append({
                "date": date_str,
                "donations": day_donations,
                "revenue": day_revenue,
                "views": day_views or 50  # Default views if no data
            })
        
        return {
            "totalViews": total_views or 2450,  # Default if no views data
            "totalDonations": total_donations,
            "totalRevenue": total_revenue,
            "successRate": success_rate,
            "last7Days": last_7_days,
            "campaignsCount": len(campaigns),
            "averageDonation": round(total_revenue / total_donations) if total_donations > 0 else 0,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        raise HTTPException(500, f"Error fetching analytics: {str(e)}")


@router.get("/donations")
async def get_all_donations(db=Depends(get_database)):
    try:
        # Get all successful donations
        donations_cursor = db.donations.find({"status": {"$in": ["SUCCESS", "completed"]}})
        donations = await donations_cursor.to_list(length=None)
        
        # Transform donations for frontend
        transformed_donations = []
        for donation in donations:
            # Get campaign details
            campaign = await db.campaigns.find_one({"_id": donation.get("campaign_id")})
            
            transformed_donations.append({
                "_id": str(donation["_id"]),
                "donor_name": donation.get("donor_name", "Anonymous Donor"),
                "amount": donation.get("amount", 0),
                "campaign_title": campaign.get("title", "Unknown Campaign") if campaign else "Unknown Campaign",
                "campaign_id": str(donation.get("campaign_id", "")),
                "status": donation.get("status", "completed"),
                "payment_id": donation.get("payment_id", ""),
                "created_at": donation.get("created_at", datetime.now()),
                "views": donation.get("views", 1)  # Track donation views
            })
        
        return transformed_donations
        
    except Exception as e:
        raise HTTPException(500, f"Error fetching donations: {str(e)}")

# === ANALYTICS ENDPOINTS ===

@router.get("/analytics")
async def get_donations_analytics(db=Depends(get_database)):
    try:
        # Get all campaigns
        campaigns_cursor = db.campaigns.find({})
        campaigns = await campaigns_cursor.to_list(length=None)
        
        # Get all donations
        donations_cursor = db.donations.find({"status": {"$in": ["SUCCESS", "completed"]}})
        donations = await donations_cursor.to_list(length=None)
        
        # Calculate total metrics
        total_views = sum(campaign.get('views', 0) for campaign in campaigns)
        total_donations = len(donations)
        total_revenue = sum(donation.get('amount', 0) for donation in donations)
        
        # Calculate success rate
        completed_campaigns = sum(1 for campaign in campaigns if campaign.get('collected_amount', 0) >= campaign.get('goal_amount', 1))
        success_rate = round((completed_campaigns / len(campaigns)) * 100) if campaigns else 0
        
        # Generate last 7 days data
        from datetime import datetime, timedelta
        last_7_days = []
        
        for i in range(7):
            date = datetime.now() - timedelta(days=6-i)
            date_str = date.strftime('%Y-%m-%d')
            
            # Count donations for this date
            day_donations = sum(1 for donation in donations 
                              if donation.get('created_at') and 
                              donation['created_at'].strftime('%Y-%m-%d') == date_str)
            
            # Calculate revenue for this date
            day_revenue = sum(donation.get('amount', 0) for donation in donations 
                            if donation.get('created_at') and 
                            donation['created_at'].strftime('%Y-%m-%d') == date_str)
            
            # Calculate views for this date (from campaigns created/updated)
            day_views = sum(campaign.get('views', 0) for campaign in campaigns 
                           if campaign.get('created_at') and 
                           campaign['created_at'].strftime('%Y-%m-%d') == date_str)
            
            last_7_days.append({
                "date": date_str,
                "donations": day_donations,
                "revenue": day_revenue,
                "views": day_views or 50  # Default views if no data
            })
        
        return {
            "totalViews": total_views or 2450,  # Default if no views data
            "totalDonations": total_donations,
            "totalRevenue": total_revenue,
            "successRate": success_rate,
            "last7Days": last_7_days,
            "campaignsCount": len(campaigns),
            "averageDonation": round(total_revenue / total_donations) if total_donations > 0 else 0,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        raise HTTPException(500, f"Error fetching analytics: {str(e)}")

