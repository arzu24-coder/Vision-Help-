from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Body
from datetime import datetime, timedelta
from bson import ObjectId
import base64
from PIL import Image, ImageDraw, ImageFont
import io
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from app.database import get_database
from app.auth.deps import get_current_user
from pydantic import BaseModel, EmailStr
from typing import Optional
import os 

router = APIRouter(prefix="/skillshare", tags=["Skill Share & Learner Platform"])

# Email configuration
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
EMAIL_USERNAME = "arzumehreen050@gmail.com"
EMAIL_PASSWORD = "cpus ctsa fdtm dmqs"

# Models for general certificate
class CertificateRequest(BaseModel):
    recipient_name: str
    recipient_email: EmailStr
    certificate_type: str = "general"
    custom_message: Optional[str] = None
    achievement: Optional[str] = None
    role: Optional[str] = None
    organization: str = "Vision Help Welfare Foundation"
    send_email: bool = True

@router.post("/certificate")
async def get_certificate(
    background_tasks: BackgroundTasks,
    db=Depends(get_database),
    current_user=Depends(get_current_user)
):
    try:
        user_id = current_user.get("user_id")
        user_email = current_user.get("sub") or current_user.get("email")
        user_role = current_user.get("role")

        if user_role != "Skill Learner":
            raise HTTPException(status_code=400, detail="This endpoint is for Skill Learners only")

        user = await db["skill_share"].find_one({"_id": ObjectId(user_id)})
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        user_name = user.get("name", "Distinguished Educator")

        # ======================================
        # CERTIFICATE BASE IMAGE
        # ======================================
        current_dir = os.path.dirname(os.path.abspath(__file__))
        project_root = os.path.dirname(os.path.dirname(current_dir))
        templates_dir = os.path.join(project_root, "templates")
        os.makedirs(templates_dir, exist_ok=True)

        template_locations = [
            os.path.join(templates_dir, "certificate1.jpg"),
            os.path.join(current_dir, "certificate1.jpg"),
            os.path.join(project_root, "certificate1.jpg"),
            "certificate1.jpg"
        ]

        template_path = next((p for p in template_locations if os.path.exists(p)), None)

        if not template_path:
            img = Image.new("RGB", (1200, 800), color=(255, 255, 255))
            draw = ImageDraw.Draw(img)
            draw.rectangle([50, 50, 1150, 750], outline=(0, 0, 0), width=5)
            draw.rectangle([70, 70, 1130, 730], outline=(0, 0, 0), width=2)
            width, height = img.size
        else:
            img = Image.open(template_path).convert("RGB")
            width, height = img.size

        draw = ImageDraw.Draw(img)

        # ======================================
        # USER NAME TEXT (Professional Placement & Size)
        # ======================================
        try:
            font_path = "app/fonts/Roboto-Regular.ttf"
            name_text = user_name

            # Reduce width and height for user_name text
            max_width = int(width * 0.22)  # Reduced width
            max_height = int(height * 0.045)  # Reduced height

            font_size = 120
            while font_size > 20:  # Allow smaller font size
                test_font = ImageFont.truetype(font_path, font_size)
                bbox = test_font.getbbox(name_text)
                text_width = bbox[2] - bbox[0]
                text_height = bbox[3] - bbox[1]
                if text_width <= max_width and text_height <= max_height:
                    break
                font_size -= 2
            name_font = ImageFont.truetype(font_path, font_size)
            detail_font = ImageFont.truetype(font_path, 22)

            name_section_y = 920
            draw.text(
                (width // 2, name_section_y),
                name_text,
                fill="#62340f",
                font=name_font,
                anchor="mm"
            )
        except Exception as e:
            print("Font error:", e)
            name_font = ImageFont.load_default()
            detail_font = ImageFont.load_default()
            name_text = user_name
            name_section_y = 890
            draw.text(
                (width // 2, name_section_y),
                name_text,
                fill="#62340f",
                font=name_font,
                anchor="mm"
            )
        # ======================================
        # CERTIFICATE FOOTER INFO (Smaller & Lower)
        # ======================================
        cert_id = f"CERT-{datetime.now().strftime('%Y%m%d')}-{str(ObjectId())[-6:]}"
        issue_date = f"Issued on: {datetime.utcnow().strftime('%Y-%m-%d')}"

        border_font = detail_font
        # Move cert_id and issue_date closer to bottom corners, smaller font
        cert_id_y = height - 35
        issue_date_y = height - 35
        draw.text((90, cert_id_y), cert_id, fill="#62340f", font=border_font, anchor="ls")
        draw.text((width - 90, issue_date_y), issue_date, fill="#62340f", font=border_font, anchor="rs")

        # ======================================
        # SAVE + EMAIL
        # ======================================
        img_byte_arr = io.BytesIO()
        img.save(img_byte_arr, format="JPEG")
        img_byte_arr.seek(0)
        img_base64 = base64.b64encode(img_byte_arr.read()).decode("utf-8")

        if user_email and user_role == "educator":
            msg = MIMEMultipart()
            msg["From"] = EMAIL_USERNAME
            msg["To"] = user_email
            msg["Subject"] = "Your Certificate of Excellence"
            body = f"""
            <html>
            <body>
                <p>Dear {user_name},</p>
                <p>Congratulations on your achievement! Please find attached your Certificate of Excellence.</p>
                <p>Best regards,<br>Vision Help Welfare Foundation</p>
            </body>
            </html>
            """
            msg.attach(MIMEText(body, "html"))

            img_data = base64.b64decode(img_base64)
            image_name = f"certificate_{user_id}.jpg"
            part = MIMEBase("image", "jpeg", filename=image_name)
            part.set_payload(img_data)
            encoders.encode_base64(part)
            msg.attach(part)

            with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
                server.starttls()
                server.login(EMAIL_USERNAME, EMAIL_PASSWORD)
                server.send_message(msg)

        return {"message": "Certificate generated successfully", "certificate_id": cert_id}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/certificate")
async def download_certificate(
    db=Depends(get_database),
    current_user=Depends(get_current_user)
):
    try:
        user_id = current_user.get("user_id")
        user_email = current_user.get("sub") or current_user.get("email")
        user_role = current_user.get("role")

        if user_role != "Skill Learner":
            raise HTTPException(status_code=400, detail="This endpoint is for Skill Learners only")

        user = await db["skill_share"].find_one({"_id": ObjectId(user_id)})
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        user_name = user.get("name", "Distinguished Educator")

        # ======================================
        # CERTIFICATE BASE IMAGE
        # ======================================
        current_dir = os.path.dirname(os.path.abspath(__file__))
        project_root = os.path.dirname(os.path.dirname(current_dir))
        templates_dir = os.path.join(project_root, "templates")
        os.makedirs(templates_dir, exist_ok=True)

        template_locations = [
            os.path.join(templates_dir, "certificate1.jpg"),
            os.path.join(current_dir, "certificate1.jpg"),
            os.path.join(project_root, "certificate1.jpg"),
            "certificate1.jpg"
        ]

        template_path = next((p for p in template_locations if os.path.exists(p)), None)

        if not template_path:
            img = Image.new("RGB", (1200, 800), color=(255, 255, 255))
            draw = ImageDraw.Draw(img)
            draw.rectangle([50, 50, 1150, 750], outline=(0, 0, 0), width=5)
            draw.rectangle([70, 70, 1130, 730], outline=(0, 0, 0), width=2)
            width, height = img.size
        else:
            img = Image.open(template_path).convert("RGB")
            width, height = img.size

        draw = ImageDraw.Draw(img)

        # ======================================
        # USER NAME TEXT (Professional Placement & Size)
        # ======================================
        try:
            font_path = "app/fonts/Roboto-Regular.ttf"
            name_text = user_name

            # Reduce width and height for user_name text
            max_width = int(width * 0.22)  # Reduced width
            max_height = int(height * 0.045)  # Reduced height

            font_size = 120
            while font_size > 20:  # Allow smaller font size
                test_font = ImageFont.truetype(font_path, font_size)
                bbox = test_font.getbbox(name_text)
                text_width = bbox[2] - bbox[0]
                text_height = bbox[3] - bbox[1]
                if text_width <= max_width and text_height <= max_height:
                    break
                font_size -= 2
            name_font = ImageFont.truetype(font_path, font_size)
            detail_font = ImageFont.truetype(font_path, 22)

            name_section_y = 920
            draw.text(
                (width // 2, name_section_y),
                name_text,
                fill="#62340f",
                font=name_font,
                anchor="mm"
            )
        except Exception as e:
            print("Font error:", e)
            name_font = ImageFont.load_default()
            detail_font = ImageFont.load_default()
            name_text = user_name
            name_section_y = 890
            draw.text(
                (width // 2, name_section_y),
                name_text,
                fill="#62340f",
                font=name_font,
                anchor="mm"
            )
        # ======================================
        # CERTIFICATE FOOTER INFO (Smaller & Lower)
        # ======================================
        cert_id = f"CERT-{datetime.now().strftime('%Y%m%d')}-{str(ObjectId())[-6:]}"
        issue_date = f"Issued on: {datetime.utcnow().strftime('%Y-%m-%d')}"

        border_font = detail_font
        # Move cert_id and issue_date closer to bottom corners, smaller font
        cert_id_y = height - 35
        issue_date_y = height - 35
        draw.text((90, cert_id_y), cert_id, fill="#62340f", font=border_font, anchor="ls")
        draw.text((width - 90, issue_date_y), issue_date, fill="#62340f", font=border_font, anchor="rs")

        # ======================================
        # SAVE + EMAIL
        # ======================================
        img_byte_arr = io.BytesIO()
        img.save(img_byte_arr, format="JPEG")
        img_byte_arr.seek(0)
        img_base64 = base64.b64encode(img_byte_arr.read()).decode("utf-8")

        if user_email and user_role == "educator":
            msg = MIMEMultipart()
            msg["From"] = EMAIL_USERNAME
            msg["To"] = user_email
            msg["Subject"] = "Your Certificate of Excellence"
            body = f"""
            <html>
            <body>
                <p>Dear {user_name},</p>
                <p>Congratulations on your achievement! Please find attached your Certificate of Excellence.</p>
                <p>Best regards,<br>Vision Help Welfare Foundation</p>
            </body>
            </html>
            """
            msg.attach(MIMEText(body, "html"))

            img_data = base64.b64decode(img_base64)
            image_name = f"certificate_{user_id}.jpg"
            part = MIMEBase("image", "jpeg", filename=image_name)
            part.set_payload(img_data)
            encoders.encode_base64(part)
            msg.attach(part)

            with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
                server.starttls()
                server.login(EMAIL_USERNAME, EMAIL_PASSWORD)
                server.send_message(msg)

        return {"message": "Certificate generated successfully", "certificate_id": cert_id}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
        raise HTTPException(status_code=500, detail=str(e))

  