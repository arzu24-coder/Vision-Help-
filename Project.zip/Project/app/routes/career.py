import bcrypt
from uuid import uuid4
from datetime import datetime, time
from typing import List, Optional
from fastapi import APIRouter, HTTPException, Depends, UploadFile, File, Request, Form, Header
from bson import ObjectId
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from app.database.models.career_connect import (
    JobApplicationRequest,
    JobPostResponse
)
from app.database.__init__ import get_database, career_collection
from app.auth.jwt_handler import create_access_token
from app.auth.deps import get_current_admin_user, get_current_user, require_role, ADMIN_EMAIL
from app.database.crud.career_crud import project_helper
from motor.motor_asyncio import AsyncIOMotorDatabase
import os 
import shutil  # Ensure shutil is also imported for file operations
from pydantic import EmailStr  # Import EmailStr from pydantic
from fastapi.security import OAuth2PasswordBearer
from app.database.schemas.career_connect import JobBase, JobPostRequest  # Ensure JobPostRequest is imported

router = APIRouter(prefix="/career",  tags=["Career Connect"])

# Helper function to serialize MongoDB documents
def serialize_document(document):
    if isinstance(document, dict):
        return {key: serialize_document(value) for key, value in document.items()}
    elif isinstance(document, list):
        return [serialize_document(item) for item in document]
    elif isinstance(document, ObjectId):
        return str(document)
    elif isinstance(document, bytes):
        try:
            return document.decode("utf-8", errors="replace")  # <-- Fix: avoid decode errors
        except Exception:
            return "<binary data>"
    return document

@router.post("/upload-resume")
async def upload_resume(
    name: str = Form(...),
    email: EmailStr = Form(...),
    phone_number: str = Form(...),
    skill: str = Form(...),
    location: str = Form(...),
    experience: str = Form(None),
    brief_bio: str = Form(None),
    education: str = Form(None),
    file: UploadFile = File(...),
    db=Depends(get_database)  # Add database dependency
):
    try:
        # Debugging: Log incoming data
        {
            "name": name,
            "email": email,
            "phone_number": phone_number,
            "skill": skill,
            "location": location,
            "experience": experience,
            "brief_bio": brief_bio,
            "education": education,
            "filename": file.filename,
            "content_type": file.content_type
        }

        # Validate file extension
        if not file.filename.endswith((".pdf", ".doc", ".docx")):
            raise HTTPException(status_code=400, detail="Only PDF or DOC files allowed.")

        # Validate file size (e.g., max 5MB)
        MAX_FILE_SIZE = 5 * 1024 * 1024  # 5 MB
        file_content = await file.read()
        if len(file_content) > MAX_FILE_SIZE:
            raise HTTPException(status_code=413, detail="File size exceeds the 5MB limit.")

        # Generate unique filename
        file_ext = file.filename.split(".")[-1]
        unique_filename = f"{uuid4().hex}.{file_ext}"

        # Define the upload directory
        upload_dir = "/www/wwwroot/amit/vision/VisionHelpProject/uploads"
        os.makedirs(upload_dir, exist_ok=True)

        # Save the file to the server
        file_path = os.path.join(upload_dir, unique_filename)
        with open(file_path, "wb") as buffer:
            buffer.write(file_content)

        # Save all data to the database
        resume_doc = {
            "name": name,
            "email": email,
            "phone_number": phone_number,
            "skill": skill,
            "location": location,
            "experience": experience,
            "brief_bio": brief_bio,
            "education": education,
            "filename": unique_filename,
            "content_type": file.content_type,
            "size": len(file_content),
            "uploaded_at": datetime.now()
        }
        result = await db["resumes"].insert_one(resume_doc)

        # Serialize the document for the response
        serialized_document = serialize_document(resume_doc)

        return {
            "success": True,
            "message": "Resume and all details saved successfully.",
            "resume": serialized_document
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occurred: {str(e)}")
@router.post("/jobs")
async def post_job(
    job: JobBase,  # Replace with your JobPostRequest schema if available
    authorization: Optional[str] = Header(None),  # Make Authorization header optional
    db=Depends(get_database)
):
    try:
        user = None
        if authorization:
            # Debugging log for Authorization header
            print(f"Authorization header received: {authorization}")

            # Validate the token if Authorization header is provided
            if not authorization.startswith("Bearer "):
                raise HTTPException(status_code=401, detail="Invalid Authorization header format. Expected 'Bearer <token>'.")

            token = authorization.replace("Bearer ", "").strip()
            try:
                user = await get_current_user(authorization, db)
                print(f"User authenticated: {user}")  # Debugging log for authenticated user
            except Exception as e:
                print(f"Error during token validation: {str(e)}")  # Debugging log for token validation errors
                raise HTTPException(status_code=401, detail="Invalid or expired token.")

        # Prepare job data
        job_data = {
            "title": job.title,
            "description": job.description,
            "companyName": job.companyName,
            "location": job.location,
            "salary": job.salary,
            "qualification": job.qualification,
            "jobType": job.jobType,
            "experience": job.experience,
            "skills": job.skills if job.skills is not None else [],
            "benefits": job.benefits,
            "posted_by": user["email"] if user else "Anonymous",
            "posted_by_id": ObjectId(user["user_id"]) if user else "Anonymous",
            "created_at": datetime.utcnow(),
            "status": "active",
            "applications_count": 0,
            "views_count": 0,
            "applicants": []
        }

        # Insert job into the database
        result = await db["career"].insert_one(job_data)
        created_job = await db["career"].find_one({"_id": result.inserted_id})

        # Serialize the document before returning
        serialized_job = serialize_document(created_job)

        return {
            "success": True,
            "message": "Job posted successfully.",
            "job": serialized_job
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"Error during job posting: {str(e)}")  # Debugging log for unexpected errors
        raise HTTPException(status_code=500, detail=f"Job posting failed: {str(e)}")
           
        
@router.get("/get_jobs")
async def get_all_jobs(db=Depends(get_database)):
    try:
        # Fetch all jobs from "career" collection
        jobs_cursor = db["career"].find({})
        jobs = await jobs_cursor.to_list(length=None)

        if not jobs:
            return {
                "success": True,
                "jobs": [],
                "message": "No jobs found."
            }

        # Serialize all jobs
        serialized_jobs = [serialize_document(job) for job in jobs]

        return {
            "success": True,
            "jobs": serialized_jobs
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch jobs: {str(e)}")


@router.post("/jobs/{job_id}/apply")
async def apply_to_job(
    job_id: str,
    db=Depends(get_database),
    applicant_name: str = Form(None),
    applicant_email: str = Form(None),
    applicant_phone: str = Form(None),
    name: str = Form(None),
    email: str = Form(None),
    phone_number: str = Form(None),
    skills: str = Form(None),
    skill: str = Form(None),
    location: str = Form(None),
    experience_years: str = Form(None),
    experience: str = Form(None),
    bio: str = Form(""),
    resume_file: UploadFile = File(None),
    file: UploadFile = File(None)
):
    try:
        # Validate job existence
        if not ObjectId.is_valid(job_id):
            raise HTTPException(status_code=400, detail="Invalid Job ID format")
        job = await db["career"].find_one({"_id": ObjectId(job_id)})
        if not job:
            raise HTTPException(status_code=404, detail="Job not found")

        # Extract applicant data from multiple possible field names
        final_name = applicant_name or name
        final_email = applicant_email or email
        final_phone = applicant_phone or phone_number
        final_skills = skills or skill
        final_experience = experience_years or experience or "0"
        final_resume = resume_file or file

        # Validate required fields
        if not final_name:
            raise HTTPException(status_code=400, detail="Applicant name is required")
        if not final_email:
            raise HTTPException(status_code=400, detail="Applicant email is required")
        if not final_phone:
            raise HTTPException(status_code=400, detail="Applicant phone is required")
        if not final_skills:
            raise HTTPException(status_code=400, detail="Skills are required")
        if not final_resume:
            raise HTTPException(status_code=400, detail="Resume file is required")

        # Generate unique filename for resume
        file_ext = final_resume.filename.split(".")[-1] if "." in final_resume.filename else "pdf"
        unique_filename = f"{uuid4().hex}.{file_ext}"
        
        # Define upload directory and save file
        upload_dir = "/www/wwwroot/amit/vision/VisionHelpProject/uploads/applications"
        os.makedirs(upload_dir, exist_ok=True)
        
        # Save the resume file
        file_content = await final_resume.read()
        file_path = os.path.join(upload_dir, unique_filename)
        with open(file_path, "wb") as buffer:
            buffer.write(file_content)

        resume_url = f"/uploads/applications/{unique_filename}"

        # Prepare application data
        app_data = {
            "job_id": ObjectId(job_id),
            "applicant_name": final_name,
            "applicant_email": final_email,
            "applicant_phone": final_phone,
            "skills": final_skills,
            "location": location or "Not specified",
            "experience_years": final_experience,
            "bio": bio or "",
            "resume_url": resume_url,
            "resume_filename": unique_filename,
            "status": "pending",
            "created_at": datetime.utcnow(),
        }

        # Insert application into DB
        result = await db["applications"].insert_one(app_data)

        # Update job application count
        await db["career"].update_one(
            {"_id": ObjectId(job_id)},
            {"$inc": {"applications_count": 1}}
        )

        return {
            "success": True,
            "message": "Application submitted successfully",
            "application_id": str(result.inserted_id),
            "job_title": job.get("title"),
            "company_name": job.get("companyName", job.get("company_name")),
            "applied_date": app_data["created_at"].isoformat(),
            "status": "pending",
            "application_status": "completed"
        }
    except HTTPException:
        raise
    except Exception as e:
        print(f"Application error: {str(e)}")  # Debug log
        raise HTTPException(status_code=500, detail=f"Application failed: {str(e)}")

@router.put("/jobs/{job_id}")
async def edit_job(
    job_id: str,
    job: JobBase,
    authorization: str = Header(...),
    db=Depends(get_database)
):
    try:
        # Validate job ID
        if not ObjectId.is_valid(job_id):
            raise HTTPException(status_code=400, detail="Invalid Job ID format")
        
        # Authenticate user
        if not authorization.startswith("Bearer "):
            raise HTTPException(status_code=401, detail="Invalid Authorization header format")
        
        user = await get_current_user(authorization, db)
        
        # Find the job
        existing_job = await db["career"].find_one({"_id": ObjectId(job_id)})
        if not existing_job:
            raise HTTPException(status_code=404, detail="Job not found")
        
        # Check if user is the job poster
        if existing_job.get("posted_by") != user["email"]:
            raise HTTPException(status_code=403, detail="You can only edit your own job posts")
        
        # Prepare updated job data
        updated_job_data = {
            "title": job.title,
            "description": job.description,
            "companyName": job.companyName,
            "location": job.location,
            "salary": job.salary,
            "qualification": job.qualification,
            "jobType": job.jobType,
            "experience": job.experience,
            "skills": job.skills if job.skills is not None else [],
            "benefits": job.benefits,
            "updated_at": datetime.utcnow()
        }
        
        # Update job in database
        result = await db["career"].update_one(
            {"_id": ObjectId(job_id)},
            {"$set": updated_job_data}
        )
        
        if result.modified_count == 0:
            raise HTTPException(status_code=500, detail="Failed to update job")
        
        # Get updated job
        updated_job = await db["career"].find_one({"_id": ObjectId(job_id)})
        serialized_job = serialize_document(updated_job)
        
        return {
            "success": True,
            "message": "Job updated successfully",
            "job": serialized_job
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error updating job: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Job update failed: {str(e)}")

@router.delete("/jobs/{job_id}")
async def delete_job(
    job_id: str,
    authorization: str = Header(...),
    db=Depends(get_database)
):
    try:
        # Validate job ID
        if not ObjectId.is_valid(job_id):
            raise HTTPException(status_code=400, detail="Invalid Job ID format")
        
        # Authenticate user
        user = await get_current_user(authorization, db)
        
        # Find the job
        existing_job = await db["career"].find_one({"_id": ObjectId(job_id)})
        if not existing_job:
            raise HTTPException(status_code=404, detail="Job not found")
        
        # Check if user is the job poster
        if existing_job.get("posted_by") != user["email"]:
            raise HTTPException(status_code=403, detail="You can only delete your own job posts")
        
        # Delete job from database
        result = await db["career"].delete_one({"_id": ObjectId(job_id)})
        
        if result.deleted_count == 0:
            raise HTTPException(status_code=500, detail="Failed to delete job")
        
        return {
            "success": True,
            "message": "Job deleted successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error deleting job: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Job deletion failed: {str(e)}")