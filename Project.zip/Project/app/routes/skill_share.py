from fastapi import APIRouter,  File, HTTPException, Depends, Form, UploadFile
from typing import List, Optional
from datetime import datetime
from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorDatabase
from app.database.__init__ import get_database
from app.database.schemas.skill_share import ContentCreate, CreateQuiz, LearnerLogin,  LearnerRegister,   EnrollRequest, LiveSession, LiveSessionCreate, SkillGuruRegister, SkillGuruLogin
from app.database.crud.skill_share_crud import (
    enroll_learner, 
    create_content, get_contents_by_educator, create_quiz, get_enrollments, save_quiz
)
from fastapi.responses import StreamingResponse
from fastapi import APIRouter, Depends, HTTPException
from app.database import get_database
from app.auth.jwt_handler import create_access_token
from app.auth.deps import get_current_user, require_role
from passlib.context import CryptContext
import base64
import os
import json  # <-- Add this import
import uuid

# Password hashing context
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def serialize_mongo_doc(doc):
    try:
        if doc is None:
            return None
        elif isinstance(doc, dict):
            result = {}
            for key, value in doc.items():
                try:
                    # Convert _id to id for better API response format
                    if key == "_id":
                        result["id"] = serialize_mongo_doc(value)
                    else:
                        result[key] = serialize_mongo_doc(value)
                except Exception as e:
                    print(f"Error serializing key '{key}': {e}")
                    result[key] = str(value)  # Fallback to string
            return result
        elif isinstance(doc, list):
            result = []
            for i, item in enumerate(doc):
                try:
                    result.append(serialize_mongo_doc(item))
                except Exception as e:
                    print(f"Error serializing list item {i}: {e}")
                    result.append(str(item))  # Fallback to string
            return result
        elif isinstance(doc, ObjectId):
            return str(doc)
        elif isinstance(doc, datetime):
            return doc.isoformat()
        elif isinstance(doc, bytes):
            return base64.b64encode(doc).decode("utf-8")
        return doc
    except Exception as e:
        print(f"Error serializing document: {e}, type: {type(doc)}")
        return str(doc)  # Fallback to string representation

def serialize_response(data):
    if isinstance(data, ObjectId):
        return str(data)
    elif isinstance(data, datetime):
        return data.isoformat()
    elif isinstance(data, dict):
        return {k: serialize_response(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [serialize_response(item) for item in data]
    return data

def serialize_for_json(obj):
    if isinstance(obj, ObjectId):
        return str(obj)
    elif isinstance(obj, datetime):
        return obj.isoformat()
    elif isinstance(obj, dict):
        return {k: serialize_for_json(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [serialize_for_json(item) for item in list(obj)]
    return obj

router = APIRouter(prefix="/skillshare", tags=["Skill Share & Learner Platform"])


@router.get("/profile/skill-guru")
async def get_me(
    db: AsyncIOMotorDatabase = Depends(get_database),
    current_user: dict = Depends(get_current_user)   # 👈 Token se user aayega
):
    try:
        if current_user.get("role") != "Skill Guru":
            raise HTTPException(status_code=403, detail="Access denied: Not a Skill Guru")

        user_id = current_user.get("user_id")
        user = await db.vision_users.find_one({"_id": user_id})
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Calculate actual content uploads and sessions from skill_share collection
        # Try different possible educator_id formats that might be used in skill_share
        user_id_str = current_user.get("user_id")  # Use user_id from current_user
        vision_id = user.get('vision_id', '')
        regular_id = user.get('ID', '')
        email = user.get('email', '')
        username = user.get('username', '')
        
        possible_ids = [
            user_id_str,                    # String version of ObjectId
            vision_id,                      # Vision ID like VIS463890  
            regular_id,                     # ID like 463890
            f"EDU{regular_id}",            # Like EDUVIS463890
            f"EDU{vision_id}",             # Like EDUVIS463890  
            email,                          # Email address
            username,                       # Username
        ]
        
        # Remove empty strings
        possible_ids = [id for id in possible_ids if id]
        
        # Debug: Print what we're looking for
        print(f"🔍 DEBUG: Looking for skill_share data for user:")
        print(f"  User ID: {current_user.get('user_id')}")
        print(f"  User ID String: {user_id_str}")
        print(f"  Vision ID: {vision_id}")
        print(f"  Regular ID: {regular_id}")
        print(f"  Email: {email}")
        print(f"  Username: {username}")
        print(f"  All possible IDs to match: {possible_ids}")
        
        # First, let's see what educator_ids exist in skill_share
        try:
            all_educators = await db.skill_share.distinct("educator_id")
            print(f"  All educator_ids in skill_share: {all_educators[:10]}...")  # Show first 10
        except Exception as e:
            print(f"  Could not get educator_ids: {e}")
            all_educators = []
        
        # Count contents uploaded by this educator (try multiple ID formats)
        contents_count = await db.skill_share.count_documents({
            "user_id": {"$in": possible_ids},
            "type": "content"
        })
        
        # Count sessions hosted by this educator
        sessions_count = await db.skill_share.count_documents({
            "user_id": {"$in": possible_ids},
            "type": "session"
        })
        
        # Also try without type filter to see total
        total_count = await db.skill_share.count_documents({
            "educator_id": {"$in": possible_ids}
        })
        
        print(f"  📊 Counts found: contents={contents_count}, sessions={sessions_count}, total={total_count}")
        
        # If no matches found, let's also try matching with current_user format
        if total_count == 0:
            current_user_id = current_user.get("user_id")
            print(f"  🔄 Also trying current_user.user_id: {current_user_id}")
            if current_user_id:
                additional_count = await db.skill_share.count_documents({
                    "user_id": current_user_id
                })
                if additional_count > 0:
                    contents_count = await db.skill_share.count_documents({
                        "user_id": current_user_id,
                        "type": "content"
                    })
                    sessions_count = await db.skill_share.count_documents({
                        "user_id": current_user_id,
                        "type": "session"
                    })
                    possible_ids.append(current_user_id)
                    print(f"  ✅ Found data with current_user.user_id: contents={contents_count}, sessions={sessions_count}")
        
        # Get unique specializations/categories from uploaded content
        pipeline = [
            {"$match": {
                "educator_id": {"$in": possible_ids},
                "category": {"$ne": None, "$exists": True, "$ne": ""}
            }},
            {"$group": {"_id": "$category"}},
            {"$sort": {"_id": 1}}
        ]
        
        specializations = []
        try:
            async for spec in db.skill_share.aggregate(pipeline):
                if spec["_id"]:
                    specializations.append(spec["_id"])
        except Exception as e:
            print(f"  Error getting specializations: {e}")
                
        print(f"  🏷️ Specializations found: {specializations}")
        
        # Set educator_id for response - use the format that seems most appropriate
        user_id = f"EDU{regular_id}" if regular_id else user_id_str

        profile = {
            "user_id": current_user.get("user_id"),
            "full_name": user.get("full_name"),
            "email": user.get("email"),
            "phone_number": user.get("phone_number"),
            "location": user.get("location"),
            "username": user.get("username"),
            "role": user.get("role"),
            "profile_img_url": f"https://vision.soheru.tech:8000/{user.get('profile_img_path')}",
            "dashboard_url": user.get("dashboard_url"),
            "qr_code": user.get("qr_code_data"),
            "specializations": specializations,
            "contents_uploaded": contents_count,
            "sessions_hosted": sessions_count,
            "created_at": user.get("created_at"),
        }

        return {
            "success": True,
            "message": "Skill Guru profile fetched successfully",
            "profile": profile
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Profile fetch failed: {str(e)}")

@router.get("/profile/skill-learner")
async def get_me(
    db: AsyncIOMotorDatabase = Depends(get_database),
    current_user: dict = Depends(get_current_user)   # 👈 Token se user aayega
):
    try:
        if current_user.get("role") != "Skill Learner":
            raise HTTPException(status_code=403, detail="Access denied: Not a Skill Learner")

        user_id = current_user.get("user_id")
        user = await db.vision_users.find_one({"_id": user_id})
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        profile = {
            "learner_id": f"LEARN{user['ID']}",
            "full_name": user.get("full_name"),
            "email": user.get("email"),
            "phone_number": user.get("phone_number"),
            "location": user.get("location"),
            "username": user.get("username"),
            "role": user.get("role"),
            "profile_img_url": f"https://vision.soheru.tech:8000/{user.get('profile_img_path')}",
            "dashboard_url": user.get("dashboard_url"),
            "qr_code": user.get("qr_code_data"),
            "courses_enrolled": user.get("courses_enrolled", []),
            "progress": user.get("progress", {}),
            "completed_sessions": user.get("completed_sessions", 0),
            "created_at": user.get("created_at"),
        }

        return {
            "success": True,
            "message": "Skill Learner profile fetched successfully",
            "profile": profile
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Profile fetch failed: {str(e)}")


# ------------------- Courses API -------------------
@router.get("/courses")
async def get_all_courses(
    category: Optional[str] = None,
    search: Optional[str] = None,
    limit: Optional[int] = None,
    db=Depends(get_database)
):
    try:
        # Build query filters
        query = {"type": {"$in": ["content", "session"]}}
        
        if category:
            query["category"] = category
            
        if search:
            query["$or"] = [
                {"title": {"$regex": search, "$options": "i"}},
                {"description": {"$regex": search, "$options": "i"}},
                {"category": {"$regex": search, "$options": "i"}}
            ]

        # Get courses with educator details
        pipeline = [
            {"$match": query},
            # Lookup educator details from vision_users collection
            # educator_id is stored as string version of ObjectId
            {
                "$lookup": {
                    "from": "vision_users",
                    "let": {"educator_string_id": "$educator_id"},
                    "pipeline": [
                        {
                            "$match": {
                                "$expr": {
                                    "$or": [
                                        {"$eq": [{"$toString": "$_id"}, "$$educator_string_id"]},
                                        {"$eq": ["$user_id", "$$educator_string_id"]},
                                        {"$eq": ["$vision_id", "$$educator_string_id"]},
                                        {"$eq": ["$ID", "$$educator_string_id"]}
                                    ]
                                }
                            }
                        }
                    ],
                    "as": "educator_data"
                }
            },
            {
                "$addFields": {
                    "educator": {"$arrayElemAt": ["$educator_data", 0]}
                }
            },
            {
                "$addFields": {
                    "instructor": {"$ifNull": ["$educator.name", "Unknown Instructor"]},
                    "students": {"$ifNull": ["$enrollment_count", 0]},
                    "rating": {"$ifNull": ["$rating", 4.5]},
                    "price": {"$ifNull": ["$price", 2500]},
                    "originalPrice": {"$ifNull": ["$originalPrice", 10000]}
                }
            },
            {"$sort": {"created_at": -1}}  # Latest courses first
        ]
        
        if limit:
            pipeline.append({"$limit": limit})

        courses_cursor = db["skill_share"].aggregate(pipeline)
        courses = []
        
        async for course in courses_cursor:
            # Debug: print educator info
            educator_id = course.get("educator_id")
            educator_info = course.get("educator", {})
            
            # Add debugging to see what's in the educator lookup
            print(f"Looking up educator with ID: {educator_id}")
            print(f"Educator data from lookup: {educator_info}")
            
            # Extract instructor name from educator info
            instructor_name = "Unknown Instructor"
            if educator_info:
                # Log what fields are available in educator_info
                print(f"Educator info fields: {list(educator_info.keys())}")
                
                instructor_name = (
                    educator_info.get("full_name") or 
                    educator_info.get("name") or 
                    educator_info.get("username") or 
                    f"{educator_info.get('first_name', '')} {educator_info.get('last_name', '')}".strip() or
                    "Unknown Instructor"
                )
                print(f"✓ Found educator: {instructor_name} for course: {course.get('title', 'No title')}")
            else:
                print(f"✗ No educator found for course: {course.get('title', 'No title')}, educator_id: {educator_id}")
                # Try to debug why educator wasn't found
                if educator_id:
                    print(f"  Educator ID type: {type(educator_id)}, value: '{educator_id}'")
            
            course_data = {
                "id": str(course["_id"]),
                "title": course.get("title", "Untitled Course"),
                "category": course.get("category", "General"),
                "description": course.get("description", ""),
                "duration": course.get("duration", "4 weeks"),
                "instructor": instructor_name,
                "students": course.get("students", 0),
                "rating": course.get("rating", 4.5),
                "price": course.get("price", 2500),
                "originalPrice": course.get("originalPrice", 10000),
                "created_at": course.get("created_at"),
                "educator_id": str(course.get("educator_id", ""))
            }
            courses.append(course_data)

        # Get unique categories
        categories_pipeline = [
            {"$match": {"type": {"$in": ["content", "session"]}}},
            {"$group": {"_id": "$category"}},
            {"$sort": {"_id": 1}}
        ]
        
        categories_cursor = db["skill_share"].aggregate(categories_pipeline)
        categories = []
        async for cat in categories_cursor:
            if cat["_id"]:  # Only include non-null categories
                categories.append(cat["_id"])

        return {
            "success": True,
            "courses": courses,
            "total_count": len(courses),
            "categories": categories,
            "filters": {
                "category": category,
                "search": search,
                "limit": limit
            }
        }

    except Exception as e:
        print(f"Error in get_all_courses: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch educator data: {str(e)}")

@router.get("/courses/featured")
async def get_featured_courses(db=Depends(get_database)):
    try:
        return await get_all_courses(limit=6, db=db)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch featured courses: {str(e)}")

@router.get("/courses/by-educator/{user_id}")
async def get_courses_by_educator(user_id: str, db=Depends(get_database)):
    try:
        print(f"🔍 Looking for skill_share data with user_id: {user_id}")
        
        # Get all data from skill_share table where user_id matches
        all_data = await db["skill_share"].find({"user_id": user_id}).to_list(1000)
        
        print(f"📊 Found {len(all_data)} records for user_id: {user_id}")
        
        # Separate courses/sessions from other data
        courses = []
        other_data = []
        
        for item in all_data:
            print(f"  - Type: {item.get('type', 'unknown')}, Title: {item.get('title', 'No title')}")
            
            if item.get("type") in ["content", "session"]:
                course_data = {
                    "id": str(item["_id"]),
                    "title": item.get("title", "Untitled Course"),
                    "category": item.get("category", "General"),
                    "description": item.get("description", ""),
                    "duration": item.get("duration", "4 weeks"),
                    "instructor": item.get("instructor", "Unknown Instructor"),
                    "students": item.get("enrollment_count", 0),
                    "rating": item.get("rating", 4.5),
                    "price": item.get("price", 2500),
                    "originalPrice": item.get("originalPrice", 10000),
                    "created_at": item.get("created_at"),
                    "user_id": item.get("user_id"),
                    "educator_id": item.get("educator_id", ""),
                    "type": item.get("type", "content"),
                    "video_url": item.get("video_url", "")
                }
                courses.append(course_data)
            else:
                # Store other data like quizzes, enrollments, etc.
                other_data.append(serialize_mongo_doc(item))
        
        # Get educator info from vision_users collection
        educator = None
        educator_name = "Unknown Educator"
        educator_email = ""
        
        # Try different strategies to find educator
        if len(user_id) == 24:
            try:
                educator_object_id = ObjectId(user_id)
                educator = await db["vision_users"].find_one({"_id": educator_object_id})
                print(f"ObjectId lookup result: {educator is not None}")
            except Exception as e:
                print(f"ObjectId conversion failed: {e}")
        
        if not educator:
            educator = await db["vision_users"].find_one({
                "$expr": {"$eq": [{"$toString": "$_id"}, user_id]}
            })
            print(f"String comparison with _id result: {educator is not None}")
        
        if not educator:
            educator = await db["vision_users"].find_one({"user_id": user_id})
            print(f"user_id lookup result: {educator is not None}")
        
        if educator:
            educator_name = (
                educator.get("full_name") or 
                educator.get("name") or 
                educator.get("username") or 
                f"{educator.get('first_name', '')} {educator.get('last_name', '')}".strip() or
                "Unknown Educator"
            )
            educator_email = educator.get("email", "")
            print(f"Found educator: {educator_name}")
        
        return {
            "success": True,
            "educator": {
                "id": user_id,
                "name": educator_name,
                "email": educator_email
            },
            "courses": courses,
            "total_count": len(courses),
            "all_skill_share_data": {
                "courses_and_sessions": len(courses),
                "other_data": len(other_data),
                "total_records": len(all_data),
                "other_data_types": list(set([item.get('type', 'unknown') for item in other_data]))
            },
            "raw_data": [serialize_mongo_doc(item) for item in all_data] if len(all_data) < 50 else f"Too many records ({len(all_data)}) - use specific endpoints"
        }
        
    except Exception as e:
        print(f"Error in get_courses_by_educator: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch educator courses: {str(e)}")



@router.get("/courses/categories")
async def get_course_categories(db=Depends(get_database)):
    try:
        pipeline = [
            {"$match": {"type": {"$in": ["content", "session"]}}},
            {"$group": {"_id": "$category", "count": {"$sum": 1}}},
            {"$sort": {"count": -1}}
        ]
        
        categories_cursor = db["skill_share"].aggregate(pipeline)
        categories = []
        
        async for cat in categories_cursor:
            if cat["_id"]:  # Only include non-null categories
                categories.append({
                    "name": cat["_id"],
                    "count": cat["count"]
                })

        return {
            "success": True,
            "categories": categories,
            "total_categories": len(categories)
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch categories: {str(e)}")


# ------------------- Educator Panel -------------------
@router.post("/educator/post-session/")
async def post_session(
    title: str = Form(...),
    file: UploadFile = File(...),
    db=Depends(get_database),
    user=Depends(get_current_user)
):
    try:
        # Check if user has educator role (either "educator" or "Skill Guru")
        user_role = user.get("role", "")
        if user_role not in ["educator", "Skill Guru"]:
            raise HTTPException(
                status_code=403, 
                detail=f"Educator access required. Current role: '{user_role}'"
            )
        # Save uploaded file to disk (or cloud)
        upload_dir = "/www/wwwroot/amit/vision/VisionHelpProject/uploads"
        os.makedirs(upload_dir, exist_ok=True)
        file_location = f"{upload_dir}/{file.filename}"
        with open(file_location, "wb") as buffer:
            buffer.write(await file.read())

        # Generate consistent educator_id format (same as profile)
        user_id = user.get("user_id", "")  # Use the user_id from get_current_user
        
        session_data = {
            "title": title,
            "video_url": file_location,  # Store file path as video_url
            "type": "session",
            "user_id": user_id,  # Use consistent EDU format
            "created_at": datetime.utcnow()
        }

        # Store in DB
        result = await db["skill_share"].insert_one(session_data)

        # Fetch the inserted document and serialize it
        inserted_doc = await db["skill_share"].find_one({"_id": result.inserted_id})
        response_data = serialize_mongo_doc(inserted_doc)

        return {
            "id": str(result.inserted_id),
            "message": "Session posted successfully",
            "user_id": user_id,  # Return the consistent EDU format
            "stored_in": "skill_share",
            "data": response_data
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to post session: {str(e)}")

@router.get("/educator/my-content/")
async def get_my_content(db=Depends(get_database), user=Depends(get_current_user)):
    try:
        # Check if user has educator role (either "educator" or "Skill Guru")
        user_role = user.get("role", "")
        if user_role not in ["educator", "Skill Guru"]:
            raise HTTPException(
                status_code=403, 
                detail=f"Educator access required. Current role: '{user_role}'"
            )
        # Generate consistent educator_id format (same as profile)
        regular_id = user.get("ID", "")  # Get the regular ID field
        educator_id = f"EDU{regular_id}" if regular_id else user.get("user_id")
        
        contents = await db["skill_share"].find({
            "educator_id": educator_id,  # Use consistent EDU format
            "type": {"$in": ["content", "session"]}  # Include both content and session types
        }).to_list(100)
        
        if not contents:
            return {
                "contents": [],
                "message": "No content found. Start by creating some content or sessions."
            }
        
        # Serialize the contents
        serialized_contents = []
        for content in contents:
            try:
                serialized_content = serialize_mongo_doc(content)
                serialized_contents.append(serialized_content)
            except Exception as e:
                continue
        
        return {
            "contents": serialized_contents,
            "total_count": len(serialized_contents),
            "educator_id": educator_id
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch content: {str(e)}")

@router.get("/educator/dashboard/{educator_id}")
async def get_educator_dashboard(educator_id: str, db=Depends(get_database)):
    try:
        # Validate educator exists
        educator_object_id = ObjectId(educator_id) if len(educator_id) == 24 else None
        educator = None
        
        # Try to find educator by ObjectId first
        if educator_object_id:
            educator = await db["vision_users"].find_one({"_id": educator_object_id})
        
        # If not found by ObjectId, try by string comparison
        if not educator:
            educator = await db["vision_users"].find_one({
                "$expr": {"$eq": [{"$toString": "$_id"}, educator_id]}
            })
        
        if not educator:
            raise HTTPException(status_code=404, detail="Educator not found")
        
        # Get all educator's content and sessions
        educator_content = await db["skill_share"].find({
            "educator_id": educator_id,
            "type": {"$in": ["content", "session"]}
        }).to_list(1000)
        
        # Get educator's courses (content with course info)
        courses = []
        sessions = []
        
        for item in educator_content:
            item_data = serialize_mongo_doc(item)
            if item.get("type") == "content":
                courses.append(item_data)
            elif item.get("type") == "session":
                sessions.append(item_data)
        
        # Get enrollment statistics
        enrollment_pipeline = [
            {
                "$match": {
                    "type": "enrollment",
                    "content_id": {"$in": [str(item["_id"]) for item in educator_content]}
                }
            },
            {
                "$group": {
                    "_id": "$content_id",
                    "enrollment_count": {"$sum": 1},
                    "enrollments": {"$push": "$$ROOT"}
                }
            }
        ]
        
        enrollments = await db["skill_share"].aggregate(enrollment_pipeline).to_list(1000)
        
        # Calculate statistics
        total_courses = len(courses)
        total_sessions = len(sessions)
        total_enrollments = sum([e["enrollment_count"] for e in enrollments])
        
        # Get recent enrollments
        recent_enrollments = await db["skill_share"].find({
            "type": "enrollment",
            "content_id": {"$in": [str(item["_id"]) for item in educator_content]}
        }).sort("created_at", -1).limit(10).to_list(10)
        
        return {
            "success": True,
            "educator": {
                "id": educator_id,
                "name": educator.get("name", "Unknown"),
                "email": educator.get("email", ""),
                "profile": serialize_mongo_doc(educator)
            },
            "statistics": {
                "total_courses": total_courses,
                "total_sessions": total_sessions,
                "total_enrollments": total_enrollments,
                "total_content": total_courses + total_sessions
            },
            "courses": courses,
            "sessions": sessions,
            "enrollments": [serialize_mongo_doc(e) for e in enrollments],
            "recent_enrollments": [serialize_mongo_doc(e) for e in recent_enrollments]
        }
        
    except Exception as e:
        print(f"Error in get_educator_dashboard: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch educator dashboard: {str(e)}")

@router.get("/educator/profile/{educator_id}")
async def get_educator_profile(educator_id: str, db=Depends(get_database)):
    try:
        # Find educator
        educator_object_id = ObjectId(educator_id) if len(educator_id) == 24 else None
        educator = None
        
        if educator_object_id:
            educator = await db["vision_users"].find_one({"_id": educator_object_id})
        
        if not educator:
            educator = await db["vision_users"].find_one({
                "$expr": {"$eq": [{"$toString": "$_id"}, educator_id]}
            })
        
        if not educator:
            raise HTTPException(status_code=404, detail="Educator not found")
        
        # Get educator's public courses
        courses = await db["skill_share"].find({
            "educator_id": educator_id,
            "type": "content"
        }).to_list(100)
        
        return {
            "success": True,
            "educator": {
                "id": educator_id,
                "name": educator.get("name", "Unknown Educator"),
                "email": educator.get("email", ""),
                "profile_image": educator.get("profile_image", ""),
                "bio": educator.get("bio", ""),
                "expertise": educator.get("expertise", []),
                "experience": educator.get("experience", "")
            },
            "courses": [serialize_mongo_doc(course) for course in courses],
            "total_courses": len(courses)
        }
        
    except Exception as e:
        print(f"Error in get_educator_profile: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch educator profile: {str(e)}")

# 📂 Path where data will be stored
DATA_FILE = "/www/wwwroot/amit/vision/VisionHelpProject/uploads/live_sessions.json"
# Ensure the file exists
if not os.path.exists(DATA_FILE):
    with open(DATA_FILE, "w") as f:
        json.dump([], f)

# 🔹 Helper functions for file operations
def load_sessions():
    try:
        with open(DATA_FILE, "r") as f:
            content = f.read().strip()
            if not content:
                return []
            return json.loads(content)
    except Exception:
        return []

def save_sessions(sessions):
    with open(DATA_FILE, "w") as f:
        json.dump(sessions, f, indent=4, default=str)

@router.post("/live-sessions", response_model=LiveSession)
def create_live_session(session: LiveSessionCreate):
    sessions = load_sessions()
    new_session = LiveSession(
        id=str(uuid.uuid4()),  # unique ID
        title=session.title,
        platform_link=session.platform_link,
        created_at=datetime.utcnow()
    )
    sessions.append(new_session.dict())
    save_sessions(sessions)
    return new_session


# ✅ Get all live sessions (GET)
@router.get("/live-sessions", response_model=List[LiveSession])
def get_live_sessions():
    sessions = load_sessions()
    return sessions

@router.post("/quiz/create")
async def create_quiz_endpoint(
    data: dict,
    db=Depends(get_database),
    user=Depends(get_current_user)
):
    try:
        # Accept title and questions from frontend
        title = data.get("title")
        questions = data.get("questions", [])
        # Optionally accept content_id if provided
        content_id = data.get("content_id")

        quiz_data = {
            "type": "quiz",
            "title": title,
            "questions": questions,
            "created_by": user["user_id"],  # Store as string, not ObjectId
            "created_at": datetime.utcnow()
        }
        if content_id:
            quiz_data["content_id"] = content_id

        result = await db["skill_share"].insert_one(quiz_data)

        return {
            "message": "Quiz created successfully",
            "quiz_id": str(result.inserted_id),
            "stored_in": "skill_share"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Quiz could not be saved: {str(e)}")

@router.get("/quiz/all")
async def get_all_quizzes(
    db=Depends(get_database),
    user=Depends(get_current_user)  # protect with auth, optional
):
    try:
        quizzes_cursor = db["skill_share"].find({"type": "quiz"})
        quizzes = []
        async for quiz in quizzes_cursor:
            quizzes.append({
                "quiz_id": str(quiz["_id"]),
                "title": quiz.get("title"),
                "questions": quiz.get("questions", []),
                "content_id": str(quiz.get("content_id")) if quiz.get("content_id") else None,
                "created_by": str(quiz.get("created_by")),
                "created_at": quiz.get("created_at")
            })

        return {
            "message": "All quizzes fetched successfully",
            "count": len(quizzes),
            "quizzes": quizzes
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Could not fetch quizzes: {str(e)}")
        
@router.get("/enrollments/{content_id}")
async def get_content_enrollments(content_id: str, db=Depends(get_database), user=Depends(require_role("educator"))):
    try:
        # First check if content exists
        content = await db["skill_share"].find_one({"_id": ObjectId(content_id)})
        if not content:
            raise HTTPException(status_code=404, detail=f"Content with ID {content_id} not found")

        # Get enrollments using aggregation pipeline
        pipeline = [
            {
                "$match": {
                    "type": "enrollment",
                    "content_id": ObjectId(content_id),
                    "status": "active"  # Only get active enrollments
                }
            },
            {
                "$lookup": {
                    "from": "skill_share",
                    "localField": "learner_id",
                    "foreignField": "_id",
                    "as": "learner"
                }
            },
            {
                "$unwind": {
                    "path": "$learner",
                    "preserveNullAndEmptyArrays": False
                }
            },
            {
                "$project": {
                    "enrollment_id": "$_id",
                    "learner_id": "$learner_id",
                    "learner_name": "$learner.name",
                    "learner_email": "$learner.email",
                    "enrollment_date": "$created_at",
                    "status": 1
                }
            }
        ]

        enrollments = await db["skill_share"].aggregate(pipeline).to_list(100)
        # Get content details
        content_details = {
            "title": content.get("title", "Untitled"),
            "type": content.get("type", "session"),
            "created_at": content.get("created_at"),
            "description": content.get("description"),
            "educator_id": str(content.get("educator_id"))
        }

        # Check if there are enrollments
        if not enrollments:
            return {
                "content_id": content_id,
                "content_details": content_details,
                "total_enrollments": 0,
                "enrollments": [],
                "educator_id": str(content.get("educator_id")),
                "message": "No enrollments found for this content yet"
            }

        # Return full response with enrollments
        return {
            "content_id": content_id,
            "content_details": content_details,
            "total_enrollments": len(enrollments),
            "enrollments": [
                {
                    "id": str(e["enrollment_id"]),
                    "learner_id": str(e["learner_id"]),
                    "learner_name": e.get("learner_name", "Unknown"),
                    "learner_email": e.get("learner_email", "No email"),
                    "enrollment_date": e.get("enrollment_date"),
                    "status": e.get("status", "active")
                }
                for e in enrollments
            ],
            "educator_id": str(content.get("educator_id"))
        }

    except Exception as e:
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=f"Failed to get enrollments: {str(e)}")

@router.get("/enrollments")
async def get_all_enrollments(db=Depends(get_database), user=Depends(require_role("educator"))):
    try:
        # Get all enrollments with aggregation pipeline for proper joining
        pipeline = [
            {
                "$match": {
                    "type": "enrollment"
                }
            },
            {
                "$lookup": {
                    "from": "skill_share",
                    "localField": "learner_id",
                    "foreignField": "_id",
                    "as": "learner"
                }
            },
            {
                "$unwind": {
                    "path": "$learner",
                    "preserveNullAndEmptyArrays": True
                }
            },
            {
                "$lookup": {
                    "from": "skill_share",
                    "localField": "content_id",
                    "foreignField": "_id",
                    "as": "content"
                }
            },
            {
                "$unwind": {
                    "path": "$content",
                    "preserveNullAndEmptyArrays": True
                }
            },
            {
                "$project": {
                    "enrollment_id": "$_id",
                    "learner_id": "$learner_id",
                    "content_id": "$content_id",
                    "created_at": 1,
                    "status": 1,
                    "learner_name": "$learner.name",
                    "learner_email": "$learner.email",
                    "content_title": "$content.title",
                    "content_type": "$content.type"
                }
            }
        ]

        enrollments = await db["skill_share"].aggregate(pipeline).to_list(100)
        
        # Serialize the response
        serialized_enrollments = []
        for enrollment in enrollments:
            serialized_enrollment = {
                "id": str(enrollment["enrollment_id"]),
                "learner_id": str(enrollment["learner_id"]),
                "content_id": str(enrollment["content_id"]),
                "created_at": enrollment.get("created_at"),
                "status": enrollment.get("status"),
                "learner_name": enrollment.get("learner_name", "Unknown"),
                "learner_email": enrollment.get("learner_email", "Unknown"),
                "content_title": enrollment.get("content_title", "Unknown"),
                "content_type": enrollment.get("content_type", "Unknown")
            }
            serialized_enrollments.append(serialized_enrollment)
        
        return {
            "total_enrollments": len(serialized_enrollments),
            "enrollments": serialized_enrollments
        }

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to get enrollments: {str(e)}"
        )

@router.get("/stats")
async def get_platform_stats(db=Depends(get_database)):
    try:
        # Count educators
        educators_count = await db["skill_share"].count_documents({"role": "educator"})
        
        # Count learners
        learners_count = await db["skill_share"].count_documents({"role": "learner"})
        
        # Count content
        content_count = await db["skill_share"].count_documents({"type": "content"})
        
        # Count enrollments
        enrollments_count = await db["skill_share"].count_documents({"type": "enrollment"})
        
        # Get list of educators
        educators_cursor = db["skill_share"].find({"role": "educator"}, {"name": 1, "email": 1, "created_at": 1})
        educators = []
        async for educator in educators_cursor:
            educators.append({
                "id": str(educator["_id"]),
                "name": educator.get("name", "Unknown"),
                "email": educator.get("email", "Unknown"),
                "created_at": educator.get("created_at", "Unknown")
            })
        
        # Get list of learners
        learners_cursor = db["skill_share"].find({"role": "learner"}, {"name": 1, "email": 1, "created_at": 1})
        learners = []
        async for learner in learners_cursor:
            learners.append({
                "id": str(learner["_id"]),
                "name": learner.get("name", "Unknown"),
                "email": learner.get("email", "Unknown"),
                "created_at": learner.get("created_at", "Unknown")
            })
        
        return {
            "platform_stats": {
                "total_educators": educators_count,
                "total_learners": learners_count,
                "total_content": content_count,
                "total_enrollments": enrollments_count
            },
            "educators": educators,
            "learners": learners
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get stats: {str(e)}")


# Update the get_all_enrollments endpoint to include content details
@router.get("/enrollments")
async def get_all_enrollments(db=Depends(get_database), user=Depends(require_role("educator"))):
    try:
        pipeline = [
            {
                "$match": {
                    "type": "enrollment"
                }
            },
            {
                "$lookup": {
                    "from": "skill_share",
                    "localField": "learner_id",
                    "foreignField": "_id",
                    "as": "learner"
                }
            },
            {
                "$lookup": {
                    "from": "skill_share",
                    "localField": "content_id",
                    "foreignField": "_id",
                    "as": "content"
                }
            },
            {
                "$unwind": {"path": "$learner", "preserveNullAndEmptyArrays": True}
            },
            {
                "$unwind": {"path": "$content", "preserveNullAndEmptyArrays": True}
            },
            {
                "$project": {
                    "_id": 1,
                    "learner_id": 1,
                    "content_id": 1,
                    "created_at": 1,
                    "status": 1,
                    "learner_name": "$learner.name",
                    "learner_email": "$learner.email",
                    "content_title": "$content.title",
                    "content_type": "$content.type",
                    "content_description": "$content.description",
                    "educator_id": "$content.educator_id"
                }
            }
        ]

        enrollments = await db["skill_share"].aggregate(pipeline).to_list(100)
        
        serialized_enrollments = [
            {
                "id": str(e["_id"]),
                "learner_id": str(e["learner_id"]),
                "content_id": str(e["content_id"]),
                "created_at": e.get("created_at"),
                "status": e.get("status", "active"),
                "learner_name": e.get("learner_name", "Unknown"),
                "learner_email": e.get("learner_email", "Unknown"),
                "content_title": e.get("content_title", "Unknown"),
                "content_type": e.get("content_type", "Unknown"),
                "content_description": e.get("content_description", ""),
                "educator_id": str(e["educator_id"]) if e.get("educator_id") else None
            } 
            for e in enrollments
        ]
        
        return {
            "total_enrollments": len(serialized_enrollments),
            "enrollments": serialized_enrollments
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get enrollments: {str(e)}")

@router.get("/educator/{content_id}")
async def get_content_by_id(
    content_id: str,
    db=Depends(get_database),
    user=Depends(require_role("Skill Guru"))
):
    try:
        # Validate ObjectId
        if not ObjectId.is_valid(content_id):
            raise HTTPException(status_code=400, detail="Invalid content ID format")

        educator_id = user["user_id"]

        # Find content by _id and educator_id (safety: educator can only access his own content)
        content = await db["skill_share"].find_one({
            "_id": ObjectId(content_id),
            "educator_id": educator_id
        })

        if not content:
            raise HTTPException(status_code=404, detail="Content not found or not owned by you")

        # Serialize
        serialized_content = serialize_mongo_doc(content)

        return {
            "content": serialized_content,
            "educator_id": educator_id
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch content: {str(e)}")

@router.get("/educator/{educator_id}/all")
async def get_all_by_educator(
    educator_id: str,
    db=Depends(get_database),
    user=Depends(require_role("Skill Guru"))  # only educators allowed
):
    try:
        # Ensure educator_id is a valid ObjectId
        if not ObjectId.is_valid(educator_id):
            raise HTTPException(status_code=400, detail="Invalid educator ID format")

        # Only allow educators to fetch their own data (optional security)
        if str(user["user_id"]) != educator_id:
            raise HTTPException(status_code=403, detail="Not authorized to view this educator's data")

        # Fetch all documents (content, sessions, quizzes, etc.) for the educator
        cursor = db["skill_share"].find({"educator_id": educator_id})
        documents = await cursor.to_list(1000)  # adjust limit as needed

        if not documents:
            return {
                "educator_id": educator_id,
                "data": [],
                "total_count": 0,
                "message": "No records found for this educator"
            }

        # Serialize
        serialized_docs = [serialize_mongo_doc(doc) for doc in documents]

        return {
            "educator_id": educator_id,
            "total_count": len(serialized_docs),
            "data": serialized_docs
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch educator data: {str(e)}")

