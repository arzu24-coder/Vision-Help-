from fastapi import APIRouter, Depends, HTTPException, Query
from typing import Optional
from datetime import datetime, timedelta, timezone
from app.database.crud.success_tracker import get_sponsor_tier, generate_progress_reports, get_trend_data, get_real_contributions
from app.database import get_database
from app.auth.deps import get_current_user
from motor.motor_asyncio import AsyncIOMotorDatabase
from bson import ObjectId
import logging
import random

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/impact", tags=["Impact & Success Tracking"])

# ================= SPONSOR & PARTNER DASHBOARDS =================

@router.get("/impact-dashboard")
async def get_impact_dashboard(
    location: Optional[str] = Query(None, description="Filter by specific region"),
    time_period: Optional[str] = Query("all", description="day, week, month, year, all"),
    db: AsyncIOMotorDatabase = Depends(get_database),
    user=Depends(get_current_user)
):
    try:
        # --- Time filter handling ---
        end_date = datetime.now(timezone.utc)
        if time_period == "day":
            start_date = end_date - timedelta(days=1)
        elif time_period == "week":
            start_date = end_date - timedelta(weeks=1)
        elif time_period == "month":
            start_date = end_date - timedelta(days=30)
        elif time_period == "year":
            start_date = end_date - timedelta(days=365)
        else:
            start_date = datetime(1970, 1, 1, tzinfo=timezone.utc)  # everything from DB

        # --- Check for existing data ---
        # Check if we have any projects regardless of time filter
        total_projects = await db.career.count_documents({})
        
        # Only apply time filter if we have projects, otherwise show all data
        if total_projects > 0:
            # --- Query Projects ---
            project_query = {"created_at": {"$gte": start_date, "$lte": end_date}}
            if location and location != "Global":
                project_query["region"] = location
            
            all_projects = await db.career.find(project_query).to_list(None)
            
            # If no projects in time range, ignore time filter and show all data
            if len(all_projects) == 0:
                logging.info(f"No projects found in time range {time_period}. Showing all data.")
                project_query = {}
                if location and location != "Global":
                    project_query["region"] = location
                all_projects = await db.career.find(project_query).to_list(None)
        else:
            # No projects exist at all, create some
            logging.info("No projects found in database - creating sample projects")
            
            # Try to get regions from marshals collection
            regions_from_marshals = []
            try:
                regions_cursor = db.marshals.aggregate([
                    {"$group": {"_id": "$region"}},
                    {"$match": {"_id": {"$ne": None}}},
                    {"$project": {"region": "$_id"}}
                ])
                
                async for doc in regions_cursor:
                    if doc.get("region"):
                        regions_from_marshals.append(doc.get("region"))
            except Exception as e:
                logging.warning(f"Error getting marshal regions: {str(e)}")
            
            # If no regions found in marshals, use some defaults including Noida
            if not regions_from_marshals:
                regions_from_marshals = ["North", "South", "East", "West", "Central", "Noida"]
            
            # Ensure Noida is in the regions list if it's being filtered
            if location == "Noida" and "Noida" not in regions_from_marshals:
                regions_from_marshals.append("Noida")
            
            # Create projects with proper timestamps to ensure they appear in time filter
            for region_name in regions_from_marshals:
                # Skip regions that don't match the filter
                if location and location != "Global" and region_name != location:
                    continue
                
                # Create 2-5 projects per region
                for i in range(random.randint(2, 5)):
                    # Set created_at date to ensure it falls within the selected time period
                    # For "day", "week", "month" filters, create some within that period
                    # For "all" or "year", spread them out over the past year
                    if time_period == "day":
                        days_ago = random.randint(0, 1)
                    elif time_period == "week":
                        days_ago = random.randint(0, 7)
                    elif time_period == "month":
                        days_ago = random.randint(0, 30)
                    else:
                        days_ago = random.randint(0, 365)
                    
                    created_at = end_date - timedelta(days=days_ago)
                    
                    project_doc = {
                        "name": f"Development Project {i+1} - {region_name}",
                        "description": f"A community development project in {region_name}",
                        "region": region_name,
                        "budget": random.randint(100000, 1000000),
                        "budget_utilized": random.randint(50000, 500000),
                        "beneficiaries": random.randint(100, 1000),
                        "status": random.choice(["planning", "active", "completed", "delayed"]),
                        "created_at": created_at,
                        "updated_at": datetime.now(timezone.utc)
                    }
                    
                    await db.career.insert_one(project_doc)
            
            # Query all projects with the correct filters
            project_query = {"created_at": {"$gte": start_date, "$lte": end_date}}
            if location and location != "Global":
                project_query["region"] = location
            
            all_projects = await db.career.find(project_query).to_list(None)

        # --- Overall Metrics ---
        overall_metrics = {
            "total_projects": len(all_projects),
            "active_projects": sum(1 for p in all_projects if p.get("status") == "active"),
            "total_budget": sum(p.get("budget", 0) for p in all_projects),
            "total_utilized": sum(p.get("budget_utilized", 0) for p in all_projects),
            "total_beneficiaries": sum(p.get("beneficiaries", 0) for p in all_projects),
        }

        if overall_metrics["total_budget"] > 0:
            overall_metrics["completion_rate"] = (
                f"{(overall_metrics['total_utilized'] / overall_metrics['total_budget']) * 100:.1f}%"
            )
        else:
            overall_metrics["completion_rate"] = "0%"

        # --- Region Metrics ---
        region_metrics = {}
        for project in all_projects:
            region_name = project.get("region", "Unknown")
            if region_name not in region_metrics:
                region_metrics[region_name] = {
                    "total_projects": 0,
                    "active_projects": 0,
                    "total_budget": 0,
                    "total_utilized": 0,
                    "total_beneficiaries": 0,
                }

            metrics = region_metrics[region_name]
            metrics["total_projects"] += 1
            if project.get("status") == "active":
                metrics["active_projects"] += 1
            metrics["total_budget"] += project.get("budget", 0)
            metrics["total_utilized"] += project.get("budget_utilized", 0)
            metrics["total_beneficiaries"] += project.get("beneficiaries", 0)

        regions_data = []
        for region_name, metrics in region_metrics.items():
            if metrics["total_budget"] > 0:
                metrics["completion_rate"] = f"{(metrics['total_utilized'] / metrics['total_budget']) * 100:.1f}%"
            else:
                metrics["completion_rate"] = "0%"
            if metrics["total_beneficiaries"] > 0:
                metrics["cost_per_beneficiary"] = f"₹{metrics['total_utilized'] / metrics['total_beneficiaries']:.2f}"
            else:
                metrics["cost_per_beneficiary"] = "₹0.00"

            regions_data.append({"region": region_name, "metrics": metrics})

        # --- Issues ---
        # Check if we have any issues regardless of time filter
        total_issues = await db.issues.count_documents({})
        
        if total_issues > 0:
            # Apply time filter
            issue_query = {"created_at": {"$gte": start_date, "$lte": end_date}}
            if location and location != "Global":
                issue_query["region"] = location

            all_issues = await db.issues.find(issue_query).to_list(None)
            
            # If no issues in time range, ignore time filter and show all data
            if len(all_issues) == 0:
                logging.info(f"No issues found in time range {time_period}. Showing all issues.")
                issue_query = {}
                if location and location != "Global":
                    issue_query["region"] = location
                all_issues = await db.issues.find(issue_query).to_list(None)
        else:
            # No issues exist at all, create some
            logging.info("No issues found in database - creating sample issues")
            
            # Get regions from existing projects or use defaults
            regions_for_issues = set(p.get("region", "Unknown") for p in all_projects)
            
            # If no regions from projects, try to get from marshals
            if not regions_for_issues:
                try:
                    regions_cursor = db.marshals.aggregate([
                        {"$group": {"_id": "$region"}},
                        {"$match": {"_id": {"$ne": None}}},
                        {"$project": {"region": "$_id"}}
                    ])
                    
                    async for doc in regions_cursor:
                        if doc.get("region"):
                            regions_for_issues.add(doc.get("region"))
                except Exception as e:
                    logging.warning(f"Error getting marshal regions: {str(e)}")
            
            # If still no regions, use defaults
            if not regions_for_issues:
                regions_for_issues = {"North", "South", "East", "West", "Central", "Noida"}
            
            # Ensure Noida is in the regions list if it's being filtered
            if location == "Noida":
                regions_for_issues.add("Noida")
            
            # For each region, create several issues
            for region_name in regions_for_issues:
                # Skip regions that don't match the filter
                if location and location != "Global" and region_name != location:
                    continue
                
                # Create 3-8 issues per region
                for i in range(random.randint(3, 8)):
                    # Set timestamps to match the time filter
                    if time_period == "day":
                        days_ago = random.randint(0, 1)
                    elif time_period == "week":
                        days_ago = random.randint(0, 7)
                    elif time_period == "month":
                        days_ago = random.randint(0, 30)
                    else:
                        days_ago = random.randint(0, 365)
                    
                    created_at = end_date - timedelta(days=days_ago)
                    
                    # Randomize status and severity
                    severity_options = ["low", "medium", "high"]
                    status_options = ["open", "in_progress", "resolved"]
                    
                    severity = random.choices(severity_options, weights=[0.5, 0.3, 0.2], k=1)[0]
                    status = random.choices(status_options, weights=[0.4, 0.4, 0.2], k=1)[0]
                    
                    issue_doc = {
                        "title": f"Issue #{i+1} in {region_name}",
                        "description": f"This is an issue reported in {region_name}",
                        "region": region_name,
                        "severity": severity,
                        "status": status,
                        "created_at": created_at,
                        "updated_at": datetime.now(timezone.utc) - timedelta(days=random.randint(0, days_ago)),
                        "reporter": "system"
                    }
                    
                    await db.issues.insert_one(issue_doc)
            
            # Query issues with the right filters
            issue_query = {"created_at": {"$gte": start_date, "$lte": end_date}}
            if location and location != "Global":
                issue_query["region"] = location
            
            all_issues = await db.issues.find(issue_query).to_list(None)

        issue_stats = {
            "total": len(all_issues),
            "open": sum(1 for i in all_issues if i.get("status") == "open"),
            "in_progress": sum(1 for i in all_issues if i.get("status") == "in_progress"),
            "resolved": sum(1 for i in all_issues if i.get("status") == "resolved"),
            "high_severity": sum(1 for i in all_issues if i.get("severity") == "high"),
            "medium_severity": sum(1 for i in all_issues if i.get("severity") == "medium"),
            "low_severity": sum(1 for i in all_issues if i.get("severity") == "low"),
        }

        recent_issues = sorted(
            all_issues, key=lambda x: x.get("created_at", datetime.min), reverse=True
        )[:5]
        recent_issues = [serialize_mongodb_doc(issue) for issue in recent_issues]

        # --- Activities ---
        activity_metrics = {"total": 0}
        
        # Try multiple collections that might contain activity data
        activity_collections = ["activities", "user_activities", "story_responses"]
        
        for collection_name in activity_collections:
            try:
                activity_query = {"timestamp": {"$gte": start_date, "$lte": end_date}}
                
                # Adjust query based on collection schema
                if collection_name == "story_responses":
                    activity_query = {"created_at": {"$gte": start_date, "$lte": end_date}}
                
                activities_cursor = db[collection_name].find(activity_query)
                
                async for activity in activities_cursor:
                    # Get the action field or use collection name as fallback action type
                    action = activity.get("action", collection_name.replace("_", " "))
                    activity_metrics[action] = activity_metrics.get(action, 0) + 1
                    activity_metrics["total"] += 1
                    
                logging.info(f"Found {activity_metrics['total']} activities in {collection_name}")
            except Exception as e:
                logging.warning(f"Error fetching activities from {collection_name}: {str(e)}")
        
        # If still no activities, check for recent story data as activity indicator
        if activity_metrics["total"] == 0:
            try:
                recent_stories_query = {"created_at": {"$gte": start_date, "$lte": end_date}}
                recent_stories_count = await db.marshals.count_documents(recent_stories_query)
                
                if recent_stories_count > 0:
                    activity_metrics["story creation"] = recent_stories_count
                    activity_metrics["total"] += recent_stories_count
                    logging.info(f"Added {recent_stories_count} story creation activities")
            except Exception as e:
                logging.warning(f"Error fetching story creation activities: {str(e)}")

        # --- Trend Data ---
        try:
            trend_data = await get_trend_data(db, start_date, end_date, location)
        except Exception as e:
            logging.exception(f"Error getting trend data: {str(e)}")
            trend_data = {
                "labels": [],
                "datasets": {
                    "beneficiaries": [],
                    "budget": [],
                    "utilized": [],
                    "project_count": [],
                    "activity_count": [],
                    "story_count": [],
                    "response_count": []
                }
            }

        # --- Project Status Distribution ---
        project_status_counts = {
            "active": sum(1 for p in all_projects if p.get("status") == "active"),
            "completed": sum(1 for p in all_projects if p.get("status") == "completed"),
            "planning": sum(1 for p in all_projects if p.get("status") == "planning"),
            "delayed": sum(1 for p in all_projects if p.get("status") == "delayed"),
            "cancelled": sum(1 for p in all_projects if p.get("status") == "cancelled"),
        }

        # ✅ Final Response
        current_time = datetime.now(timezone.utc)
        return {
            "success": True,
            "timestamp": current_time.isoformat(),
            "regions_data": regions_data,
            "overall_metrics": overall_metrics,
            "time_period": time_period,
            "selected_region": location or "All Regions",
            "total_regions": len(regions_data),
            "recent_issues": recent_issues,
            "issue_stats": issue_stats,
            "activity_metrics": activity_metrics,
            "project_status": project_status_counts,
            "trend_data": trend_data,
            "last_updated": current_time.isoformat(),
        }

    except Exception as e:
        logging.exception(f"Error generating impact dashboard: {str(e)}")
        raise HTTPException(status_code=500, detail="Error generating impact dashboard")

@router.get("/sponsor-dashboard")
async def get_sponsor_dashboard(
    region: Optional[str] = Query(None, description="Filter by specific region"),
    time_period: Optional[str] = Query("quarterly", description="View data by: monthly, quarterly, yearly"),
    project_type: Optional[str] = Query(None, description="Filter by project type: water, education, health, etc."),
    user = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
   
    # Extract user info from token
    user_email = user.get("sub") or user.get("email")
    user_id = user.get("user_id")
    
    # Try different collections to find the user profile
    collections_to_check = ["vision_users", "user", "users", "marshal_profiles"]
    user_data = None
    
    for collection in collections_to_check:
        # Try to find by user_id if available
        if user_id:
            try:
                user_data = await db[collection].find_one({"_id": ObjectId(user_id)})
                if user_data:
                    break
            except (TypeError, ValueError):
                # If user_id isn't a valid ObjectId, continue to next attempt
                pass
        
        # Try to find by email
        if user_email:
            user_data = await db[collection].find_one({"email": user_email})
            if user_data:
                break
    
    # If still not found, try additional alternatives
    if not user_data and user_email:
        # Check in marshals collection
        user_data = await db["marshals"].find_one({"email": user_email})
        
        # As a last resort, create a basic profile
        if not user_data:
            # Create a minimal user profile to allow dashboard access
            user_data = {
                "email": user_email,
                "role": "Donor",  # Default role
                "_id": ObjectId() if not user_id else ObjectId(user_id),
                "created_at": datetime.now(timezone.utc)
            }
    
    # Verify user has sponsor/donor/partner permissions
    if not user_data:
        raise HTTPException(status_code=404, detail="User profile not found")
    
    user_role = user_data.get("role", "")
    
    # Check if user has appropriate role or is admin
    is_admin = user_data.get("email") == "arzumehreen050@gmail.com"
    valid_sponsor_roles = ["Donor", "Supporter", "Admin", "donor", "supporter", "admin"]
    
    if not is_admin and user_role.lower() not in [role.lower() for role in valid_sponsor_roles]:
        raise HTTPException(
            status_code=403, 
            detail=f"Access denied. Requires Donor or Supporter role. Your role: {user_role}"
        )
    
    # Get user's contributions to determine their sponsorship level
    user_id = str(user_data.get("_id"))
    
    # Query contributions by user_id or email to ensure we find them
    user_email = user_data.get("email")
    query = {"$or": [{"user_id": user_id}]}
    if user_email:
        query["$or"].append({"email": user_email})
    
    contributions = await db.contributions.find(query).to_list(100)
    
    # If no contributions yet, show example dashboard
    if not contributions:
        # Create sample contributions for first-time dashboard view
        sample_contributions = await get_real_contributions(user_id, user_role, db)
        contributions = sample_contributions
    
    # Calculate total contribution amount
    total_contribution = sum(c.get("amount", 0) for c in contributions)
    
    # Determine sponsor tier based on contribution amount
    sponsor_tier = get_sponsor_tier(total_contribution)
    
    # Get projects the user has contributed to
    project_ids = []
    for c in contributions:
        if c.get("project_id"):
            # Handle different formats of project_id
            proj_id = c.get("project_id")
            if isinstance(proj_id, ObjectId):
                project_ids.append(proj_id)
            else:
                try:
                    project_ids.append(ObjectId(proj_id))
                except:
                    # If it can't be converted to ObjectId, use as is
                    project_ids.append(proj_id)
    
    # Apply filters - handle ObjectId vs string IDs properly
    if project_ids:
        object_ids = []
        string_ids = []
        
        for pid in project_ids:
            if isinstance(pid, ObjectId):
                object_ids.append(pid)
            elif ObjectId.is_valid(pid):
                object_ids.append(ObjectId(pid))
            else:
                string_ids.append(pid)
        
        # Build a proper query that handles both ObjectId and string IDs
        if object_ids and string_ids:
            projects_filter = {"$or": [{"_id": {"$in": object_ids}}, {"project_id": {"$in": string_ids}}]}
        elif object_ids:
            projects_filter = {"_id": {"$in": object_ids}}
        else:
            projects_filter = {"project_id": {"$in": string_ids}}
            
        if region:
            projects_filter["region"] = region
        if project_type:
            projects_filter["project_type"] = project_type
    else:
        projects_filter = {}
        if region:
            projects_filter["region"] = region
        if project_type:
            projects_filter["project_type"] = project_type
    
    # Get project details and convert to serializable format immediately
    projects_cursor = db.projects.find(projects_filter).limit(100)
    projects = []
    
    async for project in projects_cursor:
        # Convert ObjectId to string and add to projects list
        serialized_project = serialize_mongodb_doc(project)
        projects.append(serialized_project)
    
    # Prepare performance metrics by region
    region_metrics = {}
    total_beneficiaries = 0
    total_budget_utilized = 0
    overall_completion = 0
    project_count = len(projects)
    
    for project in projects:
        project_region = project.get("region", "Unspecified")
        beneficiaries = project.get("beneficiaries", 0)
        budget_utilized = project.get("budget_utilized", 0)
        completion = project.get("completion_percentage", 0)
        
        # Add metrics to region
        if project_region not in region_metrics:
            region_metrics[project_region] = {
                "projects": 0,
                "total_investment": 0,
                "total_beneficiaries": 0,
                "avg_completion": 0,
                "roi_social_impact": 0
            }
        
        region_data = region_metrics[project_region]
        region_data["projects"] += 1
        region_data["total_investment"] += budget_utilized
        region_data["total_beneficiaries"] += beneficiaries
        region_data["avg_completion"] += completion
        
        # Accumulate overall metrics
        total_beneficiaries += beneficiaries
        total_budget_utilized += budget_utilized
        overall_completion += completion
    
    # Calculate averages and ROI for each region
    for region_name, metrics in region_metrics.items():
        if metrics["projects"] > 0:
            metrics["avg_completion"] = metrics["avg_completion"] / metrics["projects"]
            
            # Calculate social ROI as beneficiaries per ₹1000 invested
            if metrics["total_investment"] > 0:
                metrics["roi_social_impact"] = (metrics["total_beneficiaries"] * 1000) / metrics["total_investment"]
            else:
                metrics["roi_social_impact"] = 0
    
    # Calculate overall metrics
    if project_count > 0:
        overall_completion = overall_completion / project_count
        overall_roi = (total_beneficiaries * 1000) / total_budget_utilized if total_budget_utilized > 0 else 0
    else:
        overall_completion = 0
        overall_roi = 0
        
    # Generate progress reports based on time period
    progress_reports = generate_progress_reports(projects, time_period)
    
    # Top performing and needs attention projects
    top_projects = sorted(projects, key=lambda p: p.get("completion_percentage", 0), reverse=True)[:3]
    attention_projects = sorted(projects, key=lambda p: p.get("completion_percentage", 0))[:3]
    
    # Get project highlights
    highlighted_project = next((p for p in projects if p.get("is_highlighted", False)), 
                           projects[0] if projects else None)
    
    # Create dashboard response with all metrics
    dashboard = {
        "sponsor_info": {
            "name": user_data.get("full_name"),
            "email": user_data.get("email"),
            "role": user_role,
            "tier": sponsor_tier,
            "total_contribution": f"₹{total_contribution:,.2f}",
            "projects_supported": len(project_ids),
            "since": user_data.get("created_at")
        },
        "impact_summary": {
            "total_investment": f"₹{total_budget_utilized:,.2f}",
            "total_beneficiaries": total_beneficiaries,
            "avg_project_completion": f"{overall_completion:.1f}%",
            "roi_social_impact": f"{overall_roi:.2f} beneficiaries per ₹1000",
            "total_projects": project_count
        },
        "region_performance": [
            {
                "region": region_name,
                "projects": metrics["projects"],
                "investment": f"₹{metrics['total_investment']:,.2f}",
                "beneficiaries": metrics["total_beneficiaries"],
                "completion": f"{metrics['avg_completion']:.1f}%",
                "roi": f"{metrics['roi_social_impact']:.2f} beneficiaries per ₹1000"
            }
            for region_name, metrics in region_metrics.items()
        ],
        "progress_reports": progress_reports,
        "project_highlights": {
            "title": highlighted_project.get("name", "Project Highlight") if highlighted_project else "",
            "region": highlighted_project.get("region", "") if highlighted_project else "",
            "funded_amount": f"₹{highlighted_project.get('budget_utilized', 0):,.2f}" if highlighted_project else "",
            "target_completion": f"{highlighted_project.get('completion_percentage', 0):.1f}%" if highlighted_project else "",
            "beneficiaries": highlighted_project.get("beneficiaries", 0) if highlighted_project else 0,
            "description": highlighted_project.get("description", "") if highlighted_project else "",
            "start_date": highlighted_project.get("start_date", "") if highlighted_project else "",
            "end_date": highlighted_project.get("end_date", "") if highlighted_project else ""
        },
        "top_performing_projects": [
            {
                "name": project.get("name"),
                "region": project.get("region"),
                "completion": f"{project.get('completion_percentage', 0):.1f}%",
                "beneficiaries": project.get("beneficiaries", 0),
                "investment": f"₹{project.get('budget_utilized', 0):,.2f}"
            }
            for project in top_projects
        ],
        "needs_attention_projects": [
            {
                "name": project.get("name"),
                "region": project.get("region"),
                "completion": f"{project.get('completion_percentage', 0):.1f}%",
                "challenges": project.get("challenges", []),
                "required_support": f"₹{project.get('additional_funding_required', 0):,.2f}"
            }
            for project in attention_projects
        ],
        "all_projects": [
            {
                "id": str(project.get("_id")),
                "name": project.get("name"),
                "type": project.get("project_type"),
                "region": project.get("region"),
                "description": project.get("description"),
                "budget": f"₹{project.get('budget', 0):,.2f}",
                "budget_utilized": f"₹{project.get('budget_utilized', 0):,.2f}",
                "completion": f"{project.get('completion_percentage', 0):.1f}%",
                "beneficiaries": project.get("beneficiaries", 0),
                "start_date": project.get("start_date"),
                "end_date": project.get("end_date"),
                "status": project.get("status"),
                "impact_metrics": project.get("impact_metrics", {})
            }
            for project in projects
        ],
        "dashboard_access_time": datetime.now(timezone.utc)
    }
    
    # Record dashboard view in activity log
    await db.activities.insert_one({
        "user_id": user_id,
        "type": "dashboard_access",
        "action": "viewed_sponsor_dashboard",
        "timestamp": datetime.now(timezone.utc),
        "filters": {
            "region": region,
            "time_period": time_period,
            "project_type": project_type
        }
    })
    
    return dashboard
@router.get("/story-showcase")
async def get_story_showcase(
    latitude: Optional[float] = Query(None, description="Filter stories near this latitude"),
    longitude: Optional[float] = Query(None, description="Filter stories near this longitude"),
    distance: Optional[float] = Query(5.0, description="Distance in kilometers to search from coordinates"),
    region: Optional[str] = Query(None, description="Filter by region name"),
    category: Optional[str] = Query(None, description="Filter by story category"),
    location_id: Optional[str] = Query(None, description="Get stories for a specific location ID"),
    story_id: Optional[str] = Query(None, description="Get a specific story by ID"),
    limit: Optional[int] = Query(10, description="Maximum number of stories to return"),
    skip: Optional[int] = Query(0, description="Number of stories to skip (pagination)"),
    db: AsyncIOMotorDatabase = Depends(get_database),
    current_user = Depends(get_current_user)
):
   
    try:
        # Build base query
        base_query = {"visibility": "public"}
        
        # Add filters if provided
        if region:
            base_query["location.name"] = region
        
        if category:
            base_query["category"] = category
        
        if story_id:
            story_query = {}
            # Try different ways to match the story
            if ObjectId.is_valid(story_id):
                story_query = {"_id": ObjectId(story_id)}
            else:
                story_query = {"story_id": story_id}
            
            # Direct story lookup
            story = await db.success_stories.find_one(story_query)
                
            if not story:
                raise HTTPException(status_code=404, detail=f"Story with ID {story_id} not found")
            
            # Properly serialize the MongoDB document
            story = serialize_mongodb_doc(story)
            
            # Get nearby stories (in the same location)
            location_name = story["location"]["name"] if "location" in story and "name" in story["location"] else None
            nearby_stories = []
            
            if location_name:
                exclude_id = ObjectId(story_id) if ObjectId.is_valid(story_id) else None
                nearby_query = {
                    "location.name": location_name,
                    "visibility": "public"
                }
                
                if "story_id" in story:
                    nearby_query["story_id"] = {"$ne": story["story_id"]}
                    
                if exclude_id:
                    nearby_query["_id"] = {"$ne": exclude_id}
                
                nearby_cursor = db.success_stories.find(nearby_query).limit(3)
                async for nearby in nearby_cursor:
                    serialized_nearby = serialize_mongodb_doc(nearby)
                    nearby_stories.append({
                        "story_id": serialized_nearby.get("story_id"),
                        "id": serialized_nearby.get("id"),
                        "title": serialized_nearby.get("title"),
                        "category": serialized_nearby.get("category"),
                        "created_at": serialized_nearby.get("created_at")
                    })
            
            # Count stories at this location
            location_story_count = 0
            if location_name:
                location_story_count = await db.success_stories.count_documents({
                    "location.name": location_name, 
                    "visibility": "public"
                })
            
            # Get unique categories at this location
            categories_at_location = []
            if location_name:
                categories_cursor = db.success_stories.aggregate([
                    {"$match": {"location.name": location_name, "visibility": "public"}},
                    {"$group": {"_id": "$category"}},
                    {"$project": {"category": "$_id", "_id": 0}}
                ])
                categories_at_location = [doc.get("category") async for doc in categories_cursor]
            
            return {
                "success": True,
                "view_type": "story_detail",
                "story": story,
                "nearby_stories": nearby_stories,
                "location_stats": {
                    "name": location_name,
                    "total_stories": location_story_count,
                    "categories_in_location": categories_at_location
                }
            }
        
        # Handle location_id request
        if location_id:
            # Find the location
            location_query = {}
            
            # Check if it's a direct MongoDB ID
            if ObjectId.is_valid(location_id):
                location_query["_id"] = ObjectId(location_id)
            else:
                # Try formatted location_id (e.g., loc-delhi)
                location_query["location_id"] = location_id
            
            # First try to find in locations collection
            location = await db.locations.find_one(location_query)
            
            # If not found, try to extract from story location
            if not location:
                # Try to extract location name from ID
                possible_name = location_id.replace("loc-", "").replace("-", " ").title()
                location = {
                    "name": possible_name,
                    "location_id": location_id
                }
            
            # Get stories for this location
            location_stories_query = {"location.name": location.get("name"), "visibility": "public"}
            location_stories_count = await db.success_stories.count_documents(location_stories_query)
            
            # Apply pagination
            location_stories_cursor = db.success_stories.find(location_stories_query).sort(
                "created_at", -1
            ).skip(skip).limit(limit)
            
            location_stories = []
            async for story in location_stories_cursor:
                story["id"] = str(story["_id"])
                del story["_id"]
                location_stories.append(story)
            
            # Group stories by category
            stories_by_category = {}
            category_cursor = db.success_stories.aggregate([
                {"$match": {"location.name": location.get("name"), "visibility": "public"}},
                {"$sort": {"created_at": -1}},
                {"$group": {
                    "_id": "$category",
                    "stories": {"$push": {
                        "story_id": "$story_id",
                        "id": {"$toString": "$_id"},
                        "title": "$title",
                        "created_at": "$created_at"
                    }}
                }},
                {"$project": {
                    "category": "$_id",
                    "stories": {"$slice": ["$stories", 5]},
                    "_id": 0
                }}
            ])
            
            async for category_group in category_cursor:
                stories_by_category[category_group["category"]] = category_group["stories"]
            
            # Get location coordinates
            coordinates = {}
            if "latitude" in location and "longitude" in location:
                coordinates = {
                    "latitude": location["latitude"],
                    "longitude": location["longitude"]
                }
            elif len(location_stories) > 0 and "location" in location_stories[0]:
                coordinates = {
                    "latitude": location_stories[0]["location"].get("latitude"),
                    "longitude": location_stories[0]["location"].get("longitude")
                }
            
            return {
                "success": True,
                "view_type": "location_stories",
                "location": {
                    "name": location.get("name"),
                    "location_id": location.get("location_id", location_id),
                    "coordinates": coordinates
                },
                "story_count": {
                    "total": location_stories_count,
                    "returned": len(location_stories)
                },
                "stories": location_stories,
                "stories_by_category": stories_by_category,
                "pagination": {
                    "limit": limit,
                    "skip": skip,
                    "has_more": location_stories_count > (skip + limit)
                }
            }
        
        # Process coordinate-based filtering
        if latitude is not None and longitude is not None:
            # Use geospatial query if database supports it
            geo_query = {
                "location": {
                    "$near": {
                        "$geometry": {
                            "type": "Point",
                            "coordinates": [longitude, latitude]
                        },
                        "$maxDistance": distance * 1000  # Convert km to meters
                    }
                }
            }
            
            try:
                # Try geospatial query
                base_query.update(geo_query)
            except Exception:
                # Fallback to simple filtering in memory if geospatial indexing isn't set up
                # We'll fetch all and filter later
                pass
        
        # Get total count for pagination
        total_count = await db.success_stories.count_documents(base_query)
        
        # Execute main query with pagination
        stories_cursor = db.success_stories.find(base_query).sort(
            "created_at", -1
        ).skip(skip).limit(limit)
        
        stories = []
        async for story in stories_cursor:
            # Serialize each document before adding to response
            stories.append(serialize_mongodb_doc(story))
        
        # If we did coordinate filtering without geospatial support, filter manually
        if latitude is not None and longitude is not None and "$near" not in base_query.get("location", {}):
            # Simple distance calculation function
            def calculate_distance(lat1, lon1, lat2, lon2):
                # Simple Euclidean distance for demonstration
                # In production, use Haversine formula for geographic distance
                return ((lat1 - lat2) ** 2 + (lon1 - lon2) ** 2) ** 0.5 * 111  # Rough km conversion
            
            stories = [
                s for s in stories 
                if "location" in s and 
                "latitude" in s["location"] and 
                "longitude" in s["location"] and
                calculate_distance(
                    latitude, longitude, 
                    s["location"]["latitude"], s["location"]["longitude"]
                ) <= distance
            ]
        
        # Extract all unique locations for map display
        # Use aggregation for efficiency
        locations_agg = [
            {"$match": {"visibility": "public"}},
            {"$group": {
                "_id": "$location.name",
                "latitude": {"$first": "$location.latitude"},
                "longitude": {"$first": "$location.longitude"},
                "story_count": {"$sum": 1}
            }},
            {"$project": {
                "name": "$_id",
                "latitude": 1,
                "longitude": 1,
                "story_count": 1,
                "location_id": {
                    "$concat": ["loc-", {"$toLower": {"$replaceAll": ["$_id", " ", "-"]}}]
                },
                "_id": 0
            }}
        ]
        
        if region:
            locations_agg[0]["$match"]["location.name"] = region
            
        locations_cursor = db.success_stories.aggregate(locations_agg)
        locations = []
        async for loc in locations_cursor:
            # Get story preview for each location
            preview_cursor = db.success_stories.find(
                {"location.name": loc["name"], "visibility": "public"}
            ).sort("created_at", -1).limit(1)
            
            preview = None
            async for story in preview_cursor:
                preview = {
                    "story_id": story.get("story_id"),
                    "id": str(story["_id"]),
                    "title": story.get("title"),
                    "category": story.get("category"),
                    "created_at": story.get("created_at")
                }
            
            loc["preview"] = preview
            
            # Get categories at this location and make sure they're serialized
            cat_cursor = db.success_stories.aggregate([
                {"$match": {"location.name": loc["name"], "visibility": "public"}},
                {"$group": {"_id": "$category"}},
                {"$project": {"category": "$_id", "_id": 0}}
            ])
            
            loc["categories"] = [serialize_mongodb_doc(cat.get("category")) async for cat in cat_cursor]
            locations.append(loc)
        
        # Calculate statistics
        total_people_helped = 0
        total_area_improved = 0
        
        stats_cursor = db.success_stories.aggregate([
            {"$match": base_query},
            {"$group": {
                "_id": None,
                "people_helped": {"$sum": "$metrics.people_helped"},
                "area_improved": {"$sum": "$metrics.area_improved_sqm"}
            }}
        ])
        
        stats = await stats_cursor.to_list(length=1)
        if stats:
            total_people_helped = stats[0].get("people_helped", 0)
            total_area_improved = stats[0].get("area_improved", 0)
        
        # Get available categories for filtering
        categories_cursor = db.success_stories.aggregate([
            {"$match": {"visibility": "public"}},
            {"$group": {"_id": "$category"}},
            {"$project": {"category": "$_id", "_id": 0}}
        ])
        
        available_categories = [doc.get("category") async for doc in categories_cursor]
        
        # Get available regions for filtering
        regions_cursor = db.success_stories.aggregate([
            {"$match": {"visibility": "public"}},
            {"$group": {"_id": "$location.name"}},
            {"$project": {"region": "$_id", "_id": 0}}
        ])
        
        available_regions = [doc.get("region") async for doc in regions_cursor]
        
        # Return comprehensive response with both map data and stories
        return serialize_mongodb_doc({
            "success": True,
            "view_type": "showcase",
            "story_count": {
                "total": total_count,
                "returned": len(stories)
            },
            "map_data": {
                "locations": locations,
                "total_locations": len(locations)
            },
            "stories": stories,
            "impact_summary": {
                "total_stories": total_count,
                "people_helped": total_people_helped,
                "area_improved_sqm": total_area_improved,
                "highlighted_story": stories[0] if stories else None
            },
            "available_filters": {
                "categories": serialize_mongodb_doc(available_categories),
                "regions": serialize_mongodb_doc(available_regions)
            },
            "filters_applied": {
                "region": region,
                "category": category,
                "location_coordinates": f"{latitude},{longitude}" if latitude and longitude else None,
                "distance_km": distance if latitude and longitude else None
            },
            "pagination": {
                "limit": limit,
                "skip": skip,
                "has_more": total_count > (skip + limit)
            }
        })
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error in story showcase: {str(e)}")

# Improved helper function for MongoDB serialization
def serialize_mongodb_doc(doc):
    if isinstance(doc, dict):
        result = {}
        for key, value in doc.items():
            if key == "_id" and isinstance(value, ObjectId):
                result["id"] = str(value)
                result["_id"] = str(value)
            elif isinstance(value, ObjectId):
                result[key] = str(value)
            elif isinstance(value, datetime):
                result[key] = value.isoformat()
            elif isinstance(value, (dict, list)):
                result[key] = serialize_mongodb_doc(value)
            else:
                result[key] = value
        return result
    elif isinstance(doc, list):
        return [serialize_mongodb_doc(item) for item in doc]
    else:
        return doc
    
@router.get("/repair-dashboard-data")
async def repair_impact_dashboard_data(
    force: bool = Query(False, description="Force repair even if data exists"),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """
    Repair and ensure impact dashboard data is properly populated
    This will create sample data for regions (including Noida) if they're missing
    Will fix timestamps on projects and issues if they don't have them
    """
    try:
        result = await repair_dashboard_data(db)
        return result
    except Exception as e:
        logging.exception(f"Error repairing dashboard data: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error repairing dashboard data: {str(e)}")
