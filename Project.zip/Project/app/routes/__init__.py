from fastapi import APIRouter
from .auth import router as auth_router
from .onboarding import router as onboarding_router
from .google import router as google_router
from .marshal import router as marshal_router
from .career import router as career_router
from .skill_share import router as skill_share_router
from .admin import router as admin_router
from .honor_board import router as honor_board_router
from .donation import router as donation_router
from .media import router as media_router
from .certificate import router as certificate_router
from .membership import router as membership_router
from .success_tracker import router as success_tracker_router
from .faq import router as faq_router
from .safety_profile import router as safety_profile_router


router = APIRouter()
router.include_router(onboarding_router)
router.include_router(auth_router)
router.include_router(google_router)
router.include_router(marshal_router)
router.include_router(career_router)
router.include_router(skill_share_router)
router.include_router(admin_router)
router.include_router(honor_board_router)
router.include_router(donation_router)
router.include_router(media_router)
router.include_router(certificate_router)
router.include_router(membership_router)
router.include_router(success_tracker_router)
router.include_router(faq_router)
router.include_router(safety_profile_router)