from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, Form, File, UploadFile
from datetime import datetime
from bson import ObjectId
import os
from pathlib import Path

from app.database import get_database
from app.auth.deps import get_current_user, get_current_admin_user, is_super_admin

from app.database.schemas.media import MediaUpload, MediaReview

router = APIRouter(prefix="/media", tags=["Media Section"])

# Get the base directory (Project folder)
BASE_DIR = Path(__file__).parent.parent.parent.absolute()

# Custom admin check function (deprecated - use get_current_admin_user instead)
async def check_admin_access(current_user=Depends(get_current_user)):
    user_email = current_user.get("sub") or current_user.get("email")
    
    # Check if user is super admin email
    if is_super_admin(user_email):
        return current_user

    ADMIN_EMAIL = "arzumehreen050@gmail.com"
    # If not super admin, check role-based admin
    try:
        return await get_current_admin_user(current_user)
    except HTTPException:
        raise HTTPException(
            status_code=403, 
            detail=f"Admin access required. Current email: {user_email}. Only admins or {ADMIN_EMAIL} can access this."
        )

@router.post("/upload")
async def upload_media(
    # Accept both FormData and file uploads
    title: str = Form(...),
    description: str = Form(...),
    region: str = Form(...),
    content_type: str = Form(...),
    file: UploadFile = File(...),
    db=Depends(get_database)
):
    # Ensure uploads directory exists
    uploads_dir = os.path.join(BASE_DIR, "uploads")
    os.makedirs(uploads_dir, exist_ok=True)
    
    # Save uploaded file to disk with absolute path
    file_location = os.path.join(uploads_dir, file.filename)
    with open(file_location, "wb") as f:
        f.write(await file.read())

    # Store file path as media_url (relative to server root)
    media_url = f"/uploads/{file.filename}"

    media_data = {
        "title": title,
        "description": description,
        "region": region,
        "media_url": media_url,
        "content_type": content_type,
        "uploaded_by": "Anonymous",
        "uploaded_by_id": None,
        "uploader_email": None,
        "uploader_role": "Anonymous",
        "status": "pending",
        "timestamp": datetime.utcnow(),
        "published_at": None,
        "visibility": "private"
    }
    
    result = await db["media"].insert_one(media_data)
    
    return {
        "message": "Media uploaded successfully, pending moderator review",
        "id": str(result.inserted_id),
        "uploaded_by": "Anonymous",
        "region": region,
        "status": "pending",
        "trust_level": None
    }


# Enhanced Moderator Review API
@router.put("/review/{media_id}")
async def review_media(
    media_id: str,
    review: MediaReview,
    db=Depends(get_database),
    admin_user=Depends(check_admin_access)
):
    # Admin authentication already handled by the dependency
    
    # Validate action
    if review.action not in ["approve", "reject"]:
        raise HTTPException(status_code=400, detail="Invalid action. Use 'approve' or 'reject'.")

    # Get the media item to review
    media_item = await db["media"].find_one({"_id": ObjectId(media_id)})
    if not media_item:
        raise HTTPException(status_code=404, detail="Media not found")
    
    # Check if already reviewed
    if media_item.get("status") not in ["pending", "in_review"]:
        return {
            "message": f"Media already {media_item.get('status')}",
            "review_details": media_item.get("review_details", {})
        }
    
    # Mark media as being reviewed if action is anything else
    if review.action not in ["approve", "reject"]:
        result = await db["media"].update_one(
            {"_id": ObjectId(media_id)},
            {"$set": {"status": "in_review"}}
        )
        return {"message": "Media marked for review"}
    
    # Get moderator details
    moderator_email = admin_user.get("sub") or admin_user.get("email")
    moderator_name = admin_user.get("full_name") or admin_user.get("name") or "Admin"
    
    # Prepare review metadata
    review_details = {
        "reviewed_by": moderator_email,
        "reviewer_name": moderator_name,
        "reviewed_at": datetime.utcnow(),
        "action": review.action,
        "feedback": review.feedback or "",
        "accuracy_check": review.accuracy_check if hasattr(review, 'accuracy_check') else True,
        "appropriateness_check": review.appropriateness_check if hasattr(review, 'appropriateness_check') else True,
        "relevance_check": review.relevance_check if hasattr(review, 'relevance_check') else True,
    }
    
    # If rejecting, require feedback
    if review.action == "reject" and not review.feedback:
        raise HTTPException(
            status_code=400, 
            detail="Feedback is required when rejecting media"
        )
    
    # Update media status with comprehensive review details
    result = await db["media"].update_one(
        {"_id": ObjectId(media_id)},
        {
            "$set": {
                "status": "approved" if review.action == "approve" else "rejected",
                "review_details": review_details,
                "published_at": datetime.utcnow() if review.action == "approve" else None,
                "visibility": "public" if review.action == "approve" else "private"
            }
        }
    )

    if result.modified_count == 0:
        raise HTTPException(status_code=500, detail="Failed to update media status")

    # If approved, add to moderation log
    if review.action == "approve":
        log_entry = {
            "action": "media_approved",
            "media_id": media_id,
            "moderator": moderator_email,
            "timestamp": datetime.utcnow(),
            "region": media_item.get("region", "Global"),
            "details": review_details
        }
        
        # Add to moderation log
        await db["moderation_logs"].insert_one(log_entry)
        
        # Notify region subscribers if implemented
        # (In future implementation)

    return {
        "message": f"Media {review.action}d successfully",
        "status": "approved" if review.action == "approve" else "rejected",
        "review_details": review_details,
        "media": {
            "id": str(media_item["_id"]),
            "title": media_item.get("title"),
            "region": media_item.get("region"),
            "visibility": "public" if review.action == "approve" else "private"
        }
    }

# Make sure the endpoint name matches what you're calling in your frontend
@router.get("/region-feed")
async def get_personalized_media_feed(  # Function name doesn't matter for routing
    skip: int = 0,
    limit: int = 20,
    include_global: bool = True,
    include_nearby: bool = True,
    background_tasks: BackgroundTasks = None,
    db=Depends(get_database),
    current_user=Depends(get_current_user)
):
    # Get user's primary region
    user_region = current_user.get("region")
    user_id = current_user.get("user_id")
    user_email = current_user.get("sub") or current_user.get("email")
    
    # If region not in token, get from database
    if not user_region and user_email:
        db_user = await db.vision_users.find_one({"email": user_email})
        if db_user:
            user_region = db_user.get("region")
    
    # Default to Global if no region specified
    if not user_region:
        user_region = "Global"
    
    # Auto-generate content if the media collection is empty
    media_count = await db["media"].count_documents({})
    if media_count < 3:  # Only auto-generate if we have fewer than 3 entries
        await auto_generate_media_content(db, user_region, user_id)
    
    # Define region hierarchy for content prioritization
    region_hierarchy = {
        "North America": ["United States", "Canada", "Mexico"],
        "South America": ["Brazil", "Argentina", "Colombia"],
        "Europe": ["United Kingdom", "Germany", "France", "Italy", "Spain"],
        "Asia": ["India", "China", "Japan", "South Korea"],
        "Africa": ["Nigeria", "South Africa", "Kenya"],
        "Australia": ["Australia", "New Zealand"],
        "Middle East": ["UAE", "Saudi Arabia", "Israel"],
        "Caribbean": ["Jamaica", "Dominican Republic", "Cuba"],
        "Central America": ["Panama", "Costa Rica", "Guatemala"]
    }
    
    # Determine nearby regions for the user's region
    nearby_regions = []
    user_continent = None
    for continent, countries in region_hierarchy.items():
        if user_region in countries:
            user_continent = continent
            break
        if user_region == continent:
            user_continent = continent
            nearby_regions = countries
            break
    
    # If user's region is a continent, use its countries as nearby
    # If user's region is a country, use other countries in the same continent as nearby
    if user_continent and user_continent != user_region:
        nearby_regions = [r for r in region_hierarchy.get(user_continent, []) if r != user_region]
    
    # Build match query for MongoDB
    match_query = {"status": "approved", "visibility": "public"}
    
    # Create region match conditions
    region_conditions = [{"region": user_region}]  # Primary region condition
    
    # Add nearby regions if requested
    if include_nearby and nearby_regions:
        region_conditions.append({"region": {"$in": nearby_regions}})
    
    # Add Global region if requested
    if include_global and user_region != "Global":
        region_conditions.append({"region": "Global"})
    
    # Add region conditions to match query
    match_query["$or"] = region_conditions
    
    # Prepare aggregation pipeline with proper sorting logic
    pipeline = [
        {"$match": match_query},
        # Add field to determine content priority based on region match
        {"$addFields": {
            "priority_score": {
                "$switch": {
                    "branches": [
                        # Exact region match gets highest priority
                        {"case": {"$eq": ["$region", user_region]}, "then": 10},
                        # Nearby regions get medium priority
                        {"case": {"$in": ["$region", nearby_regions]}, "then": 5},
                        # Global content gets lower priority
                        {"case": {"$eq": ["$region", "Global"]}, "then": 3}
                    ],
                    "default": 1
                }
            }
        }},
        # Sort by priority score (region relevance) first, then by date
        {"$sort": {"priority_score": -1, "published_at": -1}},
        {"$skip": skip},
        {"$limit": limit},
        # Project only necessary fields
        {"$project": {
            "_id": 0,
            "id": {"$toString": "$_id"},
            "title": 1,
            "description": 1,
            "region": 1,
            "media_url": 1,
            "uploaded_by": 1,
            "published_at": 1,
            "priority_type": {
                "$switch": {
                    "branches": [
                        {"case": {"$eq": ["$region", user_region]}, "then": "local"},
                        {"case": {"$in": ["$region", nearby_regions]}, "then": "nearby"},
                        {"case": {"$eq": ["$region", "Global"]}, "then": "global"}
                    ],
                    "default": "other"
                }
            },
            "view_count": {"$ifNull": ["$view_count", 0]},
            "tags": {"$ifNull": ["$tags", []]}
        }}
    ]

    # Execute aggregation
    media_items = await db["media"].aggregate(pipeline).to_list(length=None)
    
    # If still no content, generate on-the-fly (don't save to DB)
    if not media_items:
        # Generate at least one item for user's region
        fallback_item = {
            "id": str(ObjectId()),
            "title": f"Welcome to {user_region} Media Feed",
            "description": f"This is your personalized feed for {user_region}. Content is being curated for your region.",
            "region": user_region,
            "media_url": "https://images.unsplash.com/photo-1508921340878-ba53e1f016ec",
            "uploaded_by": "Vision Help",
            "published_at": datetime.utcnow().isoformat(),
            "priority_type": "local",
            "view_count": 1,
            "tags": ["welcome", user_region.lower()]
        }
        media_items = [fallback_item]
        
        # Trigger background content generation but don't wait for it
        # This ensures next time user loads, real content will be available
        background_tasks.add_task(auto_generate_media_content, db, user_region, user_id)
    
    # Get counts of content by region type
    local_count = sum(1 for item in media_items if item.get("priority_type") == "local")
    nearby_count = sum(1 for item in media_items if item.get("priority_type") == "nearby")
    global_count = sum(1 for item in media_items if item.get("priority_type") == "global")
    
    # Add flag to indicate if content was auto-generated
    return {
        "user_region": user_region,
        "nearby_regions": nearby_regions,
        "feed_statistics": {
            "total_items": len(media_items),
            "local_content": local_count,
            "nearby_content": nearby_count,
            "global_content": global_count
        },
        "media_items": media_items,
        "has_sample_content": not bool(await db["media"].count_documents({"is_sample": {"$ne": True}})),
        "auto_generated": media_count < 3
    }

# Replace the initialize_sample_media function with auto-generation functionality
async def auto_generate_media_content(db, user_region=None, user_id=None):
   
    # Don't generate too many entries - check current count first
    current_count = await db["media"].count_documents({})
    if current_count >= 5:  # Only auto-generate if we have fewer than 5 entries
        return 0
    
    # If user_region not provided, default to Global
    if not user_region:
        user_region = "Global"
        
    # Dictionary mapping regions to relevant topics and images
    region_content = {
        "Global": [
            {
                "title": "Vision Help Global Initiative Launch",
                "description": "New program aims to connect resources across continents",
                "media_url": "https://images.unsplash.com/photo-1516834611397-8d633eaec5d0",
                "tags": ["global", "initiative", "network"]
            },
            {
                "title": "Online Education Platform Expansion",
                "description": "Vision Help extends digital learning to 10 new countries",
                "media_url": "https://images.unsplash.com/photo-1554252116-dfbec1a8a25b",
                "tags": ["education", "technology", "access"]
            }
        ],
        "Asia": [
            {
                "title": "Clean Water Project Reaches Rural Villages",
                "description": "Marshal-led initiative brings safe drinking water to 15 communities",
                "media_url": "https://images.unsplash.com/photo-1523541738377-61c9fb92717a",
                "tags": ["water", "health", "rural"]
            },
            {
                "title": "Tech Training for Women in Delhi",
                "description": "Program helps women gain skills for the digital economy",
                "media_url": "https://images.unsplash.com/photo-1524178232363-1fb2b075b655",
                "tags": ["women", "technology", "education"]
            }
        ],
        "North America": [
            {
                "title": "Hurricane Preparedness Campaign",
                "description": "Marshals distribute emergency kits in coastal communities",
                "media_url": "https://images.unsplash.com/photo-1568797629142-895aea5694e9",
                "tags": ["disaster", "preparedness", "safety"]
            }
        ],
        "Africa": [
            {
                "title": "Solar Power Initiative in Rural Schools",
                "description": "Vision Help brings sustainable electricity to education",
                "media_url": "https://images.unsplash.com/photo-1531545514256-b1400bc00f31",
                "tags": ["solar", "education", "sustainability"]
            }
        ],
        "Europe": [
            {
                "title": "Youth Leadership Summit in London",
                "description": "Next generation of Vision marshals gather for training",
                "media_url": "https://images.unsplash.com/photo-1556761175-b413da4baf72",
                "tags": ["youth", "leadership", "training"]
            }
        ],
        "South America": [
            {
                "title": "Amazon Conservation Project",
                "description": "Vision marshals work with local communities to protect rainforest",
                "media_url": "https://images.unsplash.com/photo-1536697498149-989b404d66cc",
                "tags": ["conservation", "environment", "indigenous"]
            }
        ]
    }
    
    # Select content to generate - prioritize user's region
    content_to_generate = []
    
    # First add content for user's region
    if user_region in region_content:
        content_to_generate.extend(region_content[user_region])
    
    # Then add global content if needed
    if user_region != "Global" and len(content_to_generate) < 3:
        content_to_generate.extend(region_content["Global"])
    
    # If we still need more content, add from other regions
    if len(content_to_generate) < 3:
        for region, content in region_content.items():
            if region != user_region and region != "Global":
                content_to_generate.extend(content)
                if len(content_to_generate) >= 3:
                    break
    
    # Limit the number of items to generate
    content_to_generate = content_to_generate[:3]  # Max 3 items
    
    # Create database entries
    new_entries = []
    for content in content_to_generate:
        new_entry = {
            "_id": ObjectId(),
            "title": content["title"],
            "description": content["description"],
            "region": user_region,
            "media_url": content["media_url"],
            "uploaded_by": "Vision Helper",
            "uploaded_by_id": user_id or "auto_generated",
            "uploader_email": "system@visionhelp.org",
            "uploader_role": "Vision Marshal",
            "status": "approved",
            "timestamp": datetime.utcnow(),
            "published_at": datetime.utcnow(),
            "visibility": "public",
            "content_type": "article",
            "tags": content["tags"],
            "auto_generated": True,
            "view_count": 1
        }
        new_entries.append(new_entry)
    
    # Only insert if we have entries to add
    if new_entries:
        await db["media"].insert_many(new_entries)
    
    return len(new_entries)
    # Only insert if we have entries to add
    if new_entries:
        await db["media"].insert_many(new_entries)
    
    return len(new_entries)
    if user_region != "Global" and len(content_to_generate) < 3:
        content_to_generate.extend(region_content["Global"])
    
    # If we still need more content, add from other regions
    if len(content_to_generate) < 3:
        for region, content in region_content.items():
            if region != user_region and region != "Global":
                content_to_generate.extend(content)
                if len(content_to_generate) >= 3:
                    break
    
    # Limit the number of items to generate
    content_to_generate = content_to_generate[:3]  # Max 3 items
    
    # Create database entries
    new_entries = []
    for content in content_to_generate:
        new_entry = {
            "_id": ObjectId(),
            "title": content["title"],
            "description": content["description"],
            "region": user_region,
            "media_url": content["media_url"],
            "uploaded_by": "Vision Helper",
            "uploaded_by_id": user_id or "auto_generated",
            "uploader_email": "system@visionhelp.org",
            "uploader_role": "Vision Marshal",
            "status": "approved",
            "timestamp": datetime.utcnow(),
            "published_at": datetime.utcnow(),
            "visibility": "public",
            "content_type": "article",
            "tags": content["tags"],
            "auto_generated": True,
            "view_count": 1
        }
        new_entries.append(new_entry)
    
    # Only insert if we have entries to add
    if new_entries:
        await db["media"].insert_many(new_entries)
    
    return len(new_entries)
    # Only insert if we have entries to add
    if new_entries:
        await db["media"].insert_many(new_entries)
    
    return len(new_entries)

