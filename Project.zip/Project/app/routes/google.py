from fastapi import APIRouter, Request, Depends
from fastapi.responses import RedirectResponse
from app.utils.oauth import oauth 
from app.database.__init__ import get_database
from passlib.context import CryptContext
from fastapi import APIRouter, Request, Depends, HTTPException, Query
from app.database import get_database
from motor.motor_asyncio import AsyncIOMotorDatabase
router = APIRouter(prefix="/auth", tags=["Google"])

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

@router.get("/google")
async def signup_with_google(request: Request):
    redirect_uri = "http://localhost:8000/auth/google/callback"
    return await oauth.google.authorize_redirect(request, redirect_uri)


@router.get("/google/callback")
async def auth_google_callback(request: Request, db=Depends(get_database)):
    print("Session state (before token):", request.session)  # helpful for debug
    token = await oauth.google.authorize_access_token(request)
    resp = await oauth.google.get("userinfo", token=token)
    user_info = resp.json()

    email = user_info.get("email")
    username = user_info.get("name")

    existing_user = await db["users"].find_one({"email": email})

    if not existing_user:
        hashed_pw = pwd_context.hash(email + "_google")
        user_data = {
            "email": email,
            "username": username,
            "password": hashed_pw,
            "is_active": True
        }
        await db["users"].insert_one(user_data)

    return RedirectResponse(url=f"/dashboard?email={email}")
@router.get("/dashboard")
async def dashboard_data(email: str = Query(...), db: AsyncIOMotorDatabase = Depends(get_database)):
    user = await db["users"].find_one({"email": email})  # or "patients" or your collection name
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Convert ObjectId to string if needed
    user["_id"] = str(user["_id"]) 
    return {"user": user}
