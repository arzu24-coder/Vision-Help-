from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, Request
from app.database import get_database
from bson import ObjectId
from app.utils.honor_utils import serialize_mongodb_doc
from app.database.crud.honor_board_crud import ( 
    get_honor_board,
    add_contribution
)
from app.auth.deps import get_current_admin_user, get_current_user, ADMIN_EMAIL
from datetime import datetime
from typing import Optional
from pathlib import Path
from datetime import datetime
from bson import ObjectId
import qrcode
from motor.motor_asyncio import AsyncIOMotorDatabase
import base64
import logging

router = APIRouter(prefix="/honor-board", tags=["Honor Board"])

# ---- Setup indexes so queries are fast ----
async def setup_db_indexes(db: AsyncIOMotorDatabase):
    await db.issues.create_index("user_id")
    await db.events.create_index("user_id")
    await db.feedback.create_index("user_id")
    await db.contributions.create_index("user_id")

# ---- Dashboard Route ----
@router.get("/impact-dashboard/{user_id}")
async def impact_dashboard(user_id: str, db: AsyncIOMotorDatabase = Depends(get_database)):
   

    # User's reported issues
    issues_count = await db.issues.count_documents({"user_id": user_id})

    # Events attended by user
    events_count = await db.events.count_documents({"user_id": user_id})

    # Feedback submitted
    feedback_count = await db.feedback.count_documents({"user_id": user_id})

    # Contributions (donations, volunteering hours, etc.)
    contributions_count = await db.contributions.count_documents({"user_id": user_id})

    # Total points (sum of all contribution points)
    pipeline = [
        {"$match": {"user_id": user_id}},
        {"$group": {"_id": "$user_id", "total_points": {"$sum": "$points"}}}
    ]
    points_data = await db.contributions.aggregate(pipeline).to_list(1)
    total_points = points_data[0]["total_points"] if points_data else 0

    dashboard_data = {
        "user_id": user_id,
        "issues_reported": issues_count,
        "events_attended": events_count,
        "feedback_given": feedback_count,
        "contributions": contributions_count,
        "total_points": total_points,
        "last_updated": datetime.utcnow()
    }

    return {"success": True, "impact_dashboard": dashboard_data}
# ------------------- Admin Functions -------------------
@router.get("/contributions")
async def get_contributions(week: str = None, user_id: str = None, db=Depends(get_database)):
    filters = {}
    if week:
        filters["week"] = week
    if user_id:
        filters["user_id"] = user_id
    
    contributions_cursor = db.contributions.find(filters).sort("timestamp", -1)
    contributions = [serialize_mongodb_doc(contribution) async for contribution in contributions_cursor]
    
    return {
        "contributions": contributions,
        "total": len(contributions),
        "filters_applied": filters
    }

@router.get("/top-educators")
async def get_top_educators(
    limit: Optional[int] = 10,
    skip: Optional[int] = 0,
    badge_filter: Optional[str] = None,
    min_points: Optional[int] = 0,
    db=Depends(get_database)
):
    try:
        match_query = {"role": "educator"}
        if badge_filter:
            match_query["current_badge"] = badge_filter
        if min_points > 0:
            match_query["educator_points"] = {"$gte": min_points}

        pipeline = [
            {"$match": match_query},
            {"$lookup": {
                "from": "skill_share",
                "let": {"educator_id": "$_id"},
                "pipeline": [
                    {"$match": {
                        "$expr": {
                            "$and": [
                                {"$eq": ["$educator_id", "$$educator_id"]},
                                {"$eq": ["$type", "content"]}
                            ]
                        }
                    }},
                    {"$count": "total_sessions"}
                ],
                "as": "sessions_info"
            }},
            {"$lookup": {
                "from": "educator_badges",
                "let": {"educator_id": "$_id"},
                "pipeline": [
                    {"$match": {
                        "$expr": {"$eq": ["$user_id", "$$educator_id"]}
                    }},
                    {"$sort": {"issued_date": -1}},
                    {"$limit": 1}
                ],
                "as": "latest_badge"
            }},
            {"$addFields": {
                "total_sessions": {"$first": "$sessions_info.total_sessions"},
                "latest_badge": {"$first": "$latest_badge"},
                "educator_points": {"$ifNull": ["$educator_points", 0]}
            }},
            {"$sort": {"educator_points": -1, "total_sessions": -1}},
            {"$skip": skip},
            {"$limit": limit},
            {"$project": {
                "_id": 0,
                "educator_id": {"$toString": "$_id"},
                "name": 1,
                "email": 1,
                "expertise": 1,
                "total_points": "$educator_points",
                "current_badge": 1,
                "total_sessions": 1,
                "achievements": {
                    "badge_name": "$latest_badge.badge_name",
                    "badge_earned_at": "$latest_badge.issued_date"
                },
                "rank_stats": {
                    "sessions": "$total_sessions",
                    "points": "$educator_points"
                },
                "joined_date": "$created_at"
            }}
        ]

        total_count = await db["skill_share"].count_documents(match_query)
        educators = await db["skill_share"].aggregate(pipeline).to_list(length=limit)

        # Serialize each educator object to handle ObjectId, datetime, etc.
        serialized_educators = serialize_mongodb_doc(educators)

        return {
            "total_educators": total_count,
            "showing_results": len(serialized_educators),
            "skip": skip,
            "limit": limit,
            "educators": serialized_educators,
            "leaderboard_updated_at": datetime.utcnow().isoformat(),
            "filters_applied": {
                "badge_filter": badge_filter,
                "min_points": min_points if min_points > 0 else None
            }
        }
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch honor board: {str(e)}"
        )

@router.get("/weekly-highlights")
async def get_weekly_highlights(
    week: Optional[str] = None,
    limit: Optional[int] = 10,
    db=Depends(get_database)
):
    try:
        current_week = week or datetime.utcnow().strftime("%Y-W%U")
        
        # Check if data exists for the week
        existing_entries = await db.honor_board.count_documents({"week": current_week})
        
        # If no data exists, create sample entries with contributions
        if existing_entries == 0:
            # First create sample contributions
            sample_contributions = [
                {
                    "user_id": str(ObjectId()),
                    "type": "content",
                    "points": 50,
                    "week": current_week,
                    "timestamp": datetime.utcnow(),
                    "description": "Created tutorial content"
                },
                {
                    "user_id": str(ObjectId()),
                    "type": "help",
                    "points": 75,
                    "week": current_week,
                    "timestamp": datetime.utcnow(),
                    "description": "Helped new members"
                }
            ]
            
            # Insert contributions first
            await db.contributions.insert_many(sample_contributions)
            
            # Create honor board entries with matching user_ids
            initial_entries = [
                {
                    "user_id": sample_contributions[0]["user_id"],
                    "name": "Sample User 1",
                    "badge": "gold",
                    "badge_level": 3,
                    "total_points": 150,
                    "week": current_week,
                    "contributions": [
                        {
                            "type": "content",
                            "points": 50,
                            "timestamp": datetime.utcnow()
                        },
                        {
                            "type": "help",
                            "points": 100,
                            "timestamp": datetime.utcnow()
                        }
                    ]
                },
                {
                    "user_id": sample_contributions[1]["user_id"],
                    "name": "Sample User 2",
                    "badge": "silver",
                    "badge_level": 2,
                    "total_points": 75,
                    "week": current_week,
                    "contributions": [
                        {
                            "type": "help",
                            "points": 75,
                            "timestamp": datetime.utcnow()
                        }
                    ]
                }
            ]
            await db.honor_board.insert_many(initial_entries)
        pipeline = [
            {"$match": {"week": current_week}},
            {"$lookup": {
                "from": "contributions",
                "let": {"user_id": "$user_id"},
                "pipeline": [
                    {"$match": {
                        "$expr": {
                            "$and": [
                                {"$eq": ["$user_id", "$$user_id"]},
                                {"$eq": ["$week", current_week]}
                            ]
                        }
                    }},
                    {"$project": {
                        "_id": 0,
                        "type": 1,
                        "points": 1,
                        "timestamp": 1,
                        "description": 1
                    }}
                ],
                "as": "contributions"
            }},
            {"$addFields": {
                "total_points": {"$sum": "$contributions.points"}
            }},
            {"$setWindowFields": {
                "partitionBy": {},
                "sortBy": {"total_points": -1},
                "output": {
                    "rank": {"$rank": {}}
                }
            }},
            {"$sort": {"total_points": -1, "badge_level": -1}},
            {"$limit": limit},
            {"$project": {
                "_id": 0,
                "user_id": 1,
                "name": 1,
                "badge": 1,
                "badge_level": 1,
                "total_points": {"$ifNull": ["$total_points", 0]},
                "week": 1,
                "contributions": {"$ifNull": ["$contribution_data.contributions", []]},
                "certificate_url": 1,
                "rank": 1
            }}
        ]
        
        highlights = await db.honor_board.aggregate(pipeline).to_list(length=limit)
        
        # Ensure total_points is a number
        for h in highlights:
            h["total_points"] = int(h.get("total_points", 0))
        
        return {
            "week": current_week,
            "total_users": len(highlights),
            "highlights": highlights,
            "categories": {
                "top_contributors": [h for h in highlights if h["total_points"] >= 100],
                "rising_stars": [h for h in highlights if 50 <= h["total_points"] < 100],
                "active_participants": [h for h in highlights if h["total_points"] < 50]
            },
            "updated_at": datetime.utcnow().isoformat(),
            "has_data": existing_entries > 0,
            "initialized": existing_entries == 0
        }

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch weekly highlights: {str(e)}"
        )

@router.get("/filter-contributions")
async def filter_contributions(
    role: Optional[str] = None,
    contribution_type: Optional[str] = None,
    min_points: Optional[int] = 0,
    week: Optional[str] = None,
    limit: Optional[int] = 10,
    skip: Optional[int] = 0,
    db=Depends(get_database)
):
    try:
        current_week = week or datetime.utcnow().strftime("%Y-W%U")
        
        match_stage = {"week": current_week}

        if role:
            match_stage["role"] = role
        if min_points > 0:
            match_stage["total_points"] = {"$gte": min_points}
            
        pipeline = [
            {"$match": match_stage},
            {"$lookup": {
                "from": "contributions",
                "let": {"user_id": "$user_id"},
                "pipeline": [
                    {
                        "$match": {
                            "$expr": {"$eq": ["$user_id", "$$user_id"]},
                            "week": current_week,
                            **({'type': contribution_type} if contribution_type else {})
                        }
                    },
                    {
                        "$group": {
                            "_id": "$user_id",
                            "total_points": {"$sum": "$points"},
                            "contribution_types": {"$addToSet": "$type"},
                            "contributions": {
                                "$push": {
                                    "type": "$type",
                                    "points": "$points",
                                    "description": "$description",
                                    "timestamp": "$timestamp"
                                }
                            }
                        }
                    }
                ],
                "as": "contribution_data"
            }},
            {"$addFields": {
                "contribution_stats": {"$first": "$contribution_data"},
                "filtered_points": {"$ifNull": [{"$first": "$contribution_data.total_points"}, 0]}
            }},
            {"$sort": {"filtered_points": -1, "badge_level": -1}},
            {"$skip": skip},
            {"$limit": limit},
            {"$project": {
                "_id": 0,
                "user_id": 1,
                "name": 1,
                "region": 1,
                "role": 1,
                "badge": 1,
                "total_points": "$filtered_points",
                "contribution_types": "$contribution_stats.contribution_types",
                "contributions": "$contribution_stats.contributions",
                "week": 1,
                "rank": {"$add": [{"$indexOfArray": ["$filtered_points", "$filtered_points"]}, 1]}
            }}
        ]

        results = await db.honor_board.aggregate(pipeline).to_list(length=limit)
        total_count = await db.honor_board.count_documents(match_stage)

        return {
            "week": current_week,
            "total_entries": total_count,
            "showing_results": len(results),
            "results": results,
            "filters_applied": {
                "role": role,
                "contribution_type": contribution_type,
                "min_points": min_points if min_points > 0 else None
            },
            "summary": {
                "total_points": sum(r["total_points"] for r in results),
                "unique_regions": len(set(r["region"] for r in results if "region" in r)),
                "unique_roles": len(set(r["role"] for r in results if "role" in r))
            },
            "updated_at": datetime.utcnow().isoformat()
        }

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to filter contributions: {str(e)}"
        )

def is_valid_object_id(id_str: str) -> bool:
    try:
        ObjectId(id_str)
        return True
    except Exception:
        return False

def normalize_id(id_str: str) -> str:
    
    try:
        # If it's already a valid ObjectId, return as string
        if ObjectId.is_valid(id_str):
            return id_str
        # If UUID format, get last 24 chars
        if len(id_str) > 24:
            return id_str[-24:]
        # Pad shorter strings with zeros
        if len(id_str) < 24:
            return id_str.zfill(24)
        return id_str
    except Exception:
        return None

@router.post("/generate-promotion/{user_id}")
async def generate_honor_promotion(
    user_id: str,
    request: Request,
    background_tasks: BackgroundTasks,
    db=Depends(get_database),
    current_user=Depends(get_current_user)
):
    try:
        # Normalize and validate ID
        normalized_id = normalize_id(user_id)
        if not normalized_id or not ObjectId.is_valid(normalized_id):
            raise HTTPException(
                status_code=400,
                detail="Invalid user ID format. Please provide a valid ID"
            )
            
        object_id = ObjectId(normalized_id)
        user = await db.users.find_one({"_id": object_id})
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Use normalized ID for honor board lookup
        honor_data = await db.honor_board.find_one({
            "$or": [
                {"user_id": normalized_id},
                {"user_id": str(object_id)}
            ],
            "week": datetime.utcnow().strftime("%Y-W%U")
        })
        if not honor_data:
            raise HTTPException(status_code=404, detail="No honor board entry found")

        # Generate certificate
        certificate_data = {
            "user_name": user.get("name"),
            "badge": honor_data.get("badge", "Contributor"),
            "points": honor_data.get("total_points", 0),
            "week": honor_data.get("week"),
            "certificate_id": f"CERT-{datetime.utcnow().strftime('%Y%m%d')}-{str(user['_id'])[-6:]}",
            "achievements": [
                f"Earned {honor_data.get('total_points', 0)} points",
                f"Achieved {honor_data.get('badge', 'Contributor')} status",
                f"Completed {len(honor_data.get('contributions', []))} contributions"
            ]
        }

        # Generate QR code for verification
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(f"https://localhost:8000/verify/{certificate_data['certificate_id']}")
        qr.make(fit=True)
        qr_image = qr.make_image(fill_color="black", back_color="white")
        
        # Get base URL from request
        base_url = str(request.base_url).rstrip('/')
        verification_path = f"/honor-board/verify/{certificate_data['certificate_id']}"
        verification_url = f"{base_url}{verification_path}"
        
        # Save certificate details
        cert_doc = {
            "user_id": user_id,
            "certificate_id": certificate_data["certificate_id"],
            "generated_at": datetime.utcnow(),
            "honor_data": honor_data,
            "social_media": {
                "twitter": f"🎉 Congratulations {user.get('name')} for achieving {honor_data.get('badge')} status!",
                "linkedin": f"Congratulations to {user.get('name')} for their outstanding contribution!",
                "facebook": f"🌟 Another star in our community! {user.get('name')} has earned {honor_data.get('badge')} badge!"
            },
            "verification_url": verification_url
        }
        
        await db.certificates.insert_one(cert_doc)
        
        # Generate clickable share URLs using base URL
        share_urls = {
            "twitter": f"{base_url}/share/twitter/{certificate_data['certificate_id']}",
            "linkedin": f"{base_url}/share/linkedin/{certificate_data['certificate_id']}",
            "facebook": f"{base_url}/share/facebook/{certificate_data['certificate_id']}"
        }
        
        return {
            "certificate_id": certificate_data["certificate_id"],
            "user_name": user.get("name"),
            "badge": honor_data.get("badge"),
            "verification_url": verification_url,
            "social_media_content": cert_doc["social_media"],
            "share_urls": share_urls,
            "generated_at": cert_doc["generated_at"].isoformat()
        }

    except Exception as e:
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate promotion content: {str(e)}"
        )


# Add new endpoints for social sharing
@router.get("/share/{platform}/{certificate_id}")
async def share_certificate(
    platform: str,
    certificate_id: str,
    request: Request,
    db=Depends(get_database)
):
    base_url = str(request.base_url).rstrip('/')
    verification_url = f"{base_url}/honor-board/verify/{certificate_id}"
    
    cert = await db.certificates.find_one({"certificate_id": certificate_id})
    if not cert:
        raise HTTPException(status_code=404, detail="Certificate not found")
    
    # Get default social media text if missing
    social_media = cert.get("social_media", {})
    default_text = f"Check out this achievement from {cert.get('honor_data', {}).get('name', 'a contributor')}!"
    
    share_text = social_media.get(platform, default_text)
    
    platform_urls = {
        "twitter": f"https://twitter.com/compose/tweet?text={share_text}&url={verification_url}",
        "linkedin": f"https://www.linkedin.com/sharing/share-offsite/?url={verification_url}&summary={share_text}",
        "facebook": f"https://www.facebook.com/sharer.php?u={verification_url}&quote={share_text}"
    }
    
    if platform not in platform_urls:
        raise HTTPException(status_code=400, detail="Invalid social media platform")
    
    return {
        "redirect_url": platform_urls[platform],
        "share_text": share_text,
        "verification_url": verification_url
    }

# Add this helper function to ensure get_honor_board always returns list
async def get_honor_board(db, filter_criteria=None):
    filter_criteria = filter_criteria or {}
    try:
        entries = await db.honor_board.find(filter_criteria).sort("total_points", -1).to_list(100)
        
        # Convert ObjectId to string if present
        for entry in entries:
            if "_id" in entry and isinstance(entry["_id"], ObjectId):
                entry["_id"] = str(entry["_id"])
                
        return entries
    except Exception as e:
        return []

