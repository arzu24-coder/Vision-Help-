from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile, Form, File, Request, Header
from fastapi.security import OAuth2PasswordBearer
from app.database import get_database
from app.auth.deps import get_current_user
from app.utils.auth_utils import  generate_otp, send_email
from app.auth.jwt_handler import create_access_token
from typing import Literal, Optional
from app.database.schemas.join import VisionUserCreate, LoginRequest, ResetPasswordRequest, ForgotPasswordRequest, VerifyOTPRequest
from motor.motor_asyncio import AsyncIOMotorDatabase
from datetime import datetime, timezone, timedelta
import uuid
from app.utils.marshalqr_utils import send_id_card_email
from PIL import Image, ImageDraw, ImageFont
import io
import os
import qrcode
import logging
import random
from bson import ObjectId
from fastapi.responses import StreamingResponse
import bcrypt
from fastapi import APIRouter, Form, File, UploadFile, Depends, HTTPException
from pydantic import BaseModel, EmailStr
from typing import Optional, Literal
import bcrypt, uuid, random, os
from pathlib import Path
import base64
from pathlib import Path

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

router = APIRouter(prefix="/onboarding", tags=["Join Now - Onboarding & Role Identification"])

# Get the base directory (Project folder)
BASE_DIR = Path(__file__).parent.parent.parent.absolute()

# ================= CORE ONBOARDING SYSTEM =================

@router.post("/signup")
async def signup_vision_family(
    first_name: str = Form(...),
    last_name: Optional[str] = Form(""),
    email: EmailStr = Form(...),
    phone_number: str = Form(...),
    location: str = Form(...),
    password: str = Form(...),
    confirm_password: str = Form(...),
    role: Optional[str] = Form(None),
    profile_img: UploadFile = File(...),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    try:
        # Validate using Pydantic
        payload = VisionUserCreate(
            first_name=first_name,
            last_name=last_name,
            email=email,
            phone_number=phone_number,
            location=location,
            password=password,
            confirm_password=confirm_password,
            role=role
        )

        # Check if email exists
        if await db.vision_users.find_one({"email": payload.email}):
            raise HTTPException(status_code=400, detail="Email already registered")

        # Check if phone exists
        if await db.vision_users.find_one({"phone_number": payload.phone_number}):
            raise HTTPException(status_code=400, detail="Phone number already registered")

        full_name = f"{payload.first_name} {payload.last_name}".strip() if payload.last_name else payload.first_name
        hashed_password = bcrypt.hashpw(payload.password.encode('utf-8'), bcrypt.gensalt())
        ID = f"VIS{random.randint(100000, 999999)}"
        username = full_name.lower().replace(" ", "_")
        is_admin = payload.email == "arzumehreen050@gmail.com"
        assigned_role = "Admin" if is_admin else (payload.role or "Career Seeker")

        # Save profile image to disk and store the path
        img_dir = os.path.join(BASE_DIR, "static", "profile_images")
        os.makedirs(img_dir, exist_ok=True)
        unique_filename = f"{uuid.uuid4()}_{profile_img.filename}"
        img_path = os.path.join(img_dir, unique_filename)
        with open(img_path, "wb") as f:
            f.write(await profile_img.read())
        
        # Store relative path for URL serving
        img_url = f"/static/profile_images/{unique_filename}"

        user_document = {
            "_id": str(uuid.uuid4()),
            "first_name": payload.first_name,
            "last_name": payload.last_name,
            "full_name": full_name,
            "username": username,
            "email": payload.email,
            "phone_number": payload.phone_number,
            "location": payload.location,
            "profile_img_path": img_url,
            "password_hash": hashed_password.decode('utf-8'),
            "role": assigned_role,
            "ID": ID,
            "vision_id": ID,  # <-- Ensure this field is present!
            "qr_code_data": f"https://vision.soheru.tech:8000/onboarding/profile/{ID}",
            "dashboard_url": f"https://vision.soheru.tech:8000/onboarding/dashboard/admin" if is_admin else f"https://vision.soheru.tech:8000/onboarding/dashboard/{assigned_role.lower().replace(' ', '-')}",
            "onboarding_status": {
                "profile_setup": True,
                "role_selected": True,
                "dashboard_accessed": is_admin,
                "completion_percentage": 100
            },
            "created_at": datetime.now(timezone.utc),
            "is_active": True,
            "account_status": {
                "is_active": True,
                "email_verified": is_admin,
                "phone_verified": is_admin,
                "profile_complete": True
            },
            "verification_status": {
                "is_verified": is_admin,
                "verified_at": datetime.now(timezone.utc) if is_admin else None,
                "verified_by": "System" if is_admin else None
            },
            "platform_permissions": {
                "can_access_dashboard": True,
                "can_change_role": not is_admin,
                "can_generate_qr": True,
                "is_admin": is_admin,
                "can_manage_users": is_admin,
                "can_approve_content": is_admin,
                "full_access": is_admin
            }
        }

        await db.vision_users.insert_one(user_document)

        return {
            "success": True,
            "message": f"🎉 Account created for {full_name}!",
            "user_id": user_document["_id"],
            "ID": ID
        }

    except HTTPException:
        raise
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail=f"Signup failed: {str(e)}")

@router.post("/login")
async def login(
    payload: LoginRequest,
    db: AsyncIOMotorDatabase = Depends(get_database)  # ✅ Dependency here
    # print(db)
):
    email = payload.email
    password = payload.password

    try:
        # Find user by email
        print(db)
        user = await db.vision_users.find_one({"email": email})
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Verify password
        if not bcrypt.checkpw(password.encode("utf-8"), user["password_hash"].encode("utf-8")):
            raise HTTPException(status_code=401, detail="Invalid password")

        # Generate token
        access_token = create_access_token({
            "sub": user["email"],
            "user_id": user["_id"],
            "role": user["role"],
            "ID": user["ID"],
            "username": user["username"],
            "full_name": user.get("full_name", ""),
            "is_admin": user["platform_permissions"].get("is_admin", False)
        })

        return {
            "success": True,
            "message": f"Welcome back, {user.get('full_name', '')}!",
            "authentication": {
                "access_token": access_token,
                "token_type": "bearer",
                "expires_in": "24 hours"
            },
            "dashboard_url": user.get("dashboard_url"),
            "onboarding_progress": user.get("onboarding_status", {}),
            "user_id": user["_id"]
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Login failed: {str(e)}")

@router.post("/forgot-password")
async def forgot_password(payload: ForgotPasswordRequest, db: AsyncIOMotorDatabase = Depends(get_database)):
    try:
        # Check if user exists
        user = await db.vision_users.find_one({"email": payload.email})
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Generate a simple 6-digit OTP - now calling it correctly without await
        otp = generate_otp()  # Remove await since it's not async anymore
        expiry = datetime.now(timezone.utc) + timedelta(minutes=10)

        # Store OTP in database
        await db.password_otps.update_one(
            {"email": payload.email},
            {"$set": {"otp": otp, "expires_at": expiry}},
            upsert=True
        )

        # Send email with OTP - don't log the OTP
        email_content = f"""
        Dear {user.get('full_name', 'User')},

        You have requested to reset your password for your Vision Help account.
        
        Your One-Time Password (OTP) is: {otp}
        
        This OTP will expire in 10 minutes.
        
        If you did not request this password reset, please ignore this email.
        
        Regards,
        Vision Help Welfare Foundation Team
        """
        
        # Attempt to send email with correct parameters
        email_sent = await send_email(
            payload.email, 
            "Vision Help Password Reset OTP", 
            email_content
        )
        
        # Return response without exposing OTP
        return {
            "success": True,
            "message": "If your email is registered with us, you will receive a password reset OTP shortly",
            "email": payload.email
        }
    except HTTPException:
        raise
    except Exception as e:
        # Log error but don't expose specific error details
        logger.error(f"Password reset request failed: {str(e)}")
        # Return a generic error message
        raise HTTPException(status_code=500, detail="Unable to process your request at this time")

@router.post("/verify-otp")
async def verify_otp(data: VerifyOTPRequest, email: str = Query(...), db=Depends(get_database)):
    record = await db.password_otps.find_one({"email": email, "otp": data.otp})
    if not record:
        raise HTTPException(status_code=400, detail="Invalid OTP")

    expiry = record.get("expires_at")
    # Ensure expiry is timezone-aware
    if expiry is not None:
        if expiry.tzinfo is None:
            expiry = expiry.replace(tzinfo=timezone.utc)
    if not expiry or datetime.now(timezone.utc) > expiry:
        raise HTTPException(status_code=400, detail="OTP expired")

    await db.password_otps.update_one(
        {"_id": record["_id"]},
        {"$set": {"verified": True}}
    )

    return {"message": "OTP verified successfully"}


# ===== API 3: Reset Password =====
@router.post("/reset-password")
async def reset_password(data: ResetPasswordRequest, db=Depends(get_database)):
    if data.new_password != data.confirm_password:
        raise HTTPException(status_code=400, detail="Passwords do not match")

    # Get last verified OTP
    record = await db.password_otps.find_one({"verified": True}, sort=[("created_at", -1)])
    if not record:
        raise HTTPException(status_code=400, detail="No verified OTP found")

    # Update user password
    hashed_pw = data.new_password  # TODO: hash with bcrypt
    await db.users.update_one(
        {"email": record["email"]},
        {"$set": {"password": hashed_pw}}
    )

    # Invalidate OTP
    await db.password_otps.delete_many({"email": record["email"]})

    return {"message": "Password reset successfully"}

# ================= ROLE IDENTIFICATION & MANAGEMENT =================

@router.post("/change-role")
async def change_user_role(
    new_role: Literal["Vision Marshal", "Career Seeker", "Supporter", "Donor"],
    user = Depends(get_current_user),
    db = Depends(get_database)
):
    # Check if user is admin
    user_data = await db.vision_users.find_one({"_id": user.get("user_id")})
    if not user_data or user_data.get("email") != "arzumehreen050@gmail.com":
        raise HTTPException(
            status_code=403,
            detail="Only admin can change user roles"
        )

    # Update role in MongoDB
    update_result = await db.vision_users.update_one(
        {"_id": user.get("user_id")},
        {
            "$set": {
                "role": new_role,
                "dashboard_url": f"https://vision.soheru.tech:8000/onboarding/dashboard/{new_role.lower().replace(' ', '-')}",
                "role_updated_at": datetime.now(timezone.utc),
                "updated_by": {
                    "admin_id": user.get("user_id"),
                    "admin_email": user_data.get("email")
                }
            }
        }
    )

    if update_result.modified_count == 0:
        raise HTTPException(status_code=404, detail="User not found")

    # Do NOT generate or return a new token. The user should continue using their existing token.
    return {
        "success": True,
        "message": f"🎉 Role successfully changed to {new_role}!",
        "new_role": new_role,
        "new_dashboard_url": f"https://vision.soheru.tech:8000/onboarding/dashboard/{new_role.lower().replace(' ', '-')}",
        "updated_by": f"Admin ({user_data.get('email')})"
    }

@router.post("/generate-id-card")
async def generate_id_card(
    user = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    try:
        # Get ID from the authenticated user
        ID = user.get("ID")
        if not ID:
            raise HTTPException(status_code=400, detail="ID not found for current user")

        # Fetch user data from DB
        user_data = await db.vision_users.find_one({"ID": ID})
        if not user_data:
            raise HTTPException(status_code=404, detail="User not found in database")
        user_email = user_data.get("email")
        if not user_email:
            raise HTTPException(status_code=400, detail="User email not found")

        first_name = user_data.get("first_name", "")
        last_name = user_data.get("last_name", "")
        role = user_data.get("role", "")
        phone_number = user_data.get("phone_number", "")
        profile_img_path = user_data.get("profile_img_path", "")

        # === Use provided background template for ID card ===
        import os

# Current file ka directory
        current_dir = os.path.dirname(os.path.abspath(__file__))

        # Project root (current_dir ke upar ka folder)
        project_root = os.path.dirname(os.path.dirname(current_dir))

        # Templates folder path
        templates_dir = os.path.join(project_root, "templates")

        # Agar "templates" folder nahi hai to create kar dega
        os.makedirs(templates_dir, exist_ok=True)

        # Possible ID card background locations (priority order)
        id_card_locations = [
            os.path.join(templates_dir, "id_card.png"),     # templates folder
            os.path.join(current_dir, "id_card.png"),       # current dir
            os.path.join(project_root, "id_card.png"),      # project root
            "id_card.png"                                   # fallback (same dir jaha script run ho rahi)
        ]

# Find the first valid path
        id_card_path = None
        for path in id_card_locations:
            if os.path.exists(path):
                id_card_path = path
                break

# Try to open ID card template
        try:
            if not id_card_path:
                raise FileNotFoundError("ID card template not found in any location.")
            
            card = Image.open(id_card_path).convert("RGBA")
            card_width, card_height = card.size
            draw = ImageDraw.Draw(card)

        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Could not load ID card template: {str(e)}")
        # === Load Fonts ===
        try:
            font_path = "app/fonts/Roboto-Regular.ttf"
            font_mega_bold = ImageFont.truetype(font_path, 80)  # Largest font for names and role
            font_super_bold = ImageFont.truetype(font_path, 72)  # Even larger font for names and role
            font_extra_bold = ImageFont.truetype(font_path, 64)  # Larger font for names and role
            font_bold = ImageFont.truetype(font_path, 54)
            font_regular = ImageFont.truetype(font_path, 38)
            font_small = ImageFont.truetype(font_path, 32)
        except:
            font_mega_bold = font_super_bold = font_extra_bold = font_bold = font_regular = font_small = ImageFont.load_default()

        # === Colors ===
        dark_blue = (30, 65, 120)
        black = (0, 0, 0)
        light_blue = (135, 195, 240)

        # === Blue Photo Section (moved even more to left) ===
        # Position photo moved even more to left
        blue_photo_x = int(card_width * 0.002)   # Moved even more left - was 0.01
        blue_photo_y = int(card_height * 0.29)  # Same vertical position
        blue_photo_w = int(card_width * 0.65)   # Same width
        blue_photo_h = int(card_height * 0.27)  # Same height
        
        # Photo fits properly within the blue section
        photo_frame_x = blue_photo_x + 3  # Padding for proper fit
        photo_frame_y = blue_photo_y + 3
        photo_frame_w = blue_photo_w - 6  # Proper fit within blue section
        photo_frame_h = blue_photo_h - 6
        
        try:
            if profile_img_path and os.path.exists(profile_img_path):
                with open(profile_img_path, "rb") as f:
                    profile_data = f.read()
                profile_img = Image.open(io.BytesIO(profile_data)).convert("RGB")
                
                # Maintain aspect ratio while fitting in the frame
                img_w, img_h = profile_img.size
                aspect_ratio = img_w / img_h
                frame_aspect_ratio = photo_frame_w / photo_frame_h
                
                if aspect_ratio > frame_aspect_ratio:
                    # Image is wider, fit to width
                    new_w = photo_frame_w
                    new_h = int(photo_frame_w / aspect_ratio)
                else:
                    # Image is taller, fit to height
                    new_h = photo_frame_h
                    new_w = int(photo_frame_h * aspect_ratio)
                
                profile_img = profile_img.resize((new_w, new_h), Image.Resampling.LANCZOS)
                
                # Center the image in the frame
                paste_x = photo_frame_x + (photo_frame_w - new_w) // 2
                paste_y = photo_frame_y + (photo_frame_h - new_h) // 2
                card.paste(profile_img, (paste_x, paste_y))
            else:
                # Draw placeholder if no photo available
                draw.rectangle([photo_frame_x, photo_frame_y, photo_frame_x + photo_frame_w, photo_frame_y + photo_frame_h], fill=light_blue)
                draw.text((photo_frame_x + photo_frame_w//3, photo_frame_y + photo_frame_h//2), "PHOTO", font=font_regular, fill=black)
        except Exception:
            # Error handling: draw placeholder
            draw.rectangle([photo_frame_x, photo_frame_y, photo_frame_x + photo_frame_w, photo_frame_y + photo_frame_h], fill=light_blue)
            draw.text((photo_frame_x + photo_frame_w//3, photo_frame_y + photo_frame_h//2), "PHOTO", font=font_regular, fill=black)

        # === Name & Role Section (moved up with increased spacing) ===
        # Position first name and last name moved up with mega bold and largest font size
        full_name = f"{first_name} {last_name}"  # Keep for email purposes
        name_x = blue_photo_x + blue_photo_w - 10  # Same horizontal position
        name_y = blue_photo_y + 70  # Moved up - was 90
        
        # Print first name on first line with mega bold font for maximum size
        draw.text((name_x, name_y), first_name, font=font_mega_bold, fill=dark_blue)
        
        # Print last name with mega bold font and increased spacing
        last_name_y = name_y + 80  # Same spacing between first and last name
        draw.text((name_x, last_name_y), last_name, font=font_mega_bold, fill=dark_blue)
        
        # Role positioned below last name with less bold font moved more left - split into two lines
        role_x = name_x + 20  # Moved more left - was +50
        role_y = last_name_y + 110  # Increased spacing between names and role - was 90
        
        # Split role into two lines for better display
        role_words = role.split()
        if len(role_words) > 1:
            # If role has multiple words, split them into two lines
            mid_point = len(role_words) // 2
            role_line1 = " ".join(role_words[:mid_point])
            role_line2 = " ".join(role_words[mid_point:])
        else:
            # If role is a single word, display it on first line and leave second line empty or add a descriptor
            role_line1 = role
            role_line2 = ""  # You can add a descriptor here if needed
        
        # Print first part of role with less bold font
        draw.text((role_x, role_y), role_line1, font=font_extra_bold, fill=dark_blue)  # Changed from mega_bold to extra_bold
        
        # Print second part of role on next line with less bold font
        if role_line2:  # Only draw second line if there's content
            role_y2 = role_y + 80  # Same spacing between role lines
            draw.text((role_x, role_y2), role_line2, font=font_extra_bold, fill=dark_blue)  # Changed from mega_bold to extra_bold

        # === Phone No Section (moved more to the right) ===
        # Position phone number moved more to the right
        phone_icon_x = int(card_width * 0.17)   # Moved more to right - was 0.15
        phone_icon_y = int(card_height * 0.72)  # Same vertical position
        phone_text_x = phone_icon_x + 56  # Same spacing from icon
        phone_text_y = phone_icon_y + 5   # Perfectly aligned with icon
        
        # Draw phone number in bold black color with increased height
        draw.text((phone_text_x, phone_text_y), phone_number, font=font_bold, fill=black)  # Changed to font_bold for increased height

        # === ID No Section (moved higher up with reduced height) ===
        # Position ID number moved higher up with reduced height
        id_label_x = int(card_width * 0.35)   # Same horizontal position
        id_label_y = int(card_height * 0.58)  # Same vertical position
        draw.text((id_label_x, id_label_y), ID, font=font_bold, fill=dark_blue)  # Reduced height from extra_bold to bold

        # === QR Code Section (moved left and fitted properly) ===
        # Position QR code more to the left and fit it perfectly in the section
        qr_rect_x = int(card_width * 0.62)   # Moved more to left - was 0.68
        qr_rect_y = int(card_height * 0.65)  # Same height
        qr_rect_w = int(card_width * 0.26)   # Slightly wider - was 0.24
        qr_rect_h = int(card_height * 0.25)  # Taller for better fit - was 0.22
        
        # Calculate QR code size to fit perfectly in the section
        qr_padding = 4  # Reduced padding - was 8
        qr_available_w = qr_rect_w - (qr_padding * 2)
        qr_available_h = qr_rect_h - (qr_padding * 2)
        qr_size = min(qr_available_w, qr_available_h)  # Square QR code
        
        verification_url = f"https://vision.soheru.tech:8000/onboarding/verify/{ID}"
        try:
            # Generate QR code with settings optimized for perfect fit
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=5,  # Increased for better quality and fit
                border=0,    # No border for maximum use of space
            )
            qr.add_data(verification_url)
            qr.make(fit=True)
            qr_img = qr.make_image(fill_color="black", back_color="white").convert("RGBA")
            qr_img = qr_img.resize((qr_size, qr_size), Image.Resampling.LANCZOS)
            
            # Center QR code perfectly in the rectangular section
            qr_x = qr_rect_x + (qr_rect_w - qr_size) // 2
            qr_y = qr_rect_y + (qr_rect_h - qr_size) // 2
            card.paste(qr_img, (qr_x, qr_y))
            
        except Exception as e:
            # Error handling: draw placeholder
            placeholder_x = qr_rect_x + qr_padding
            placeholder_y = qr_rect_y + qr_padding
            placeholder_w = qr_available_w
            placeholder_h = qr_available_h
            draw.rectangle([placeholder_x, placeholder_y, placeholder_x + placeholder_w, placeholder_y + placeholder_h], fill=light_blue)
            draw.text((placeholder_x + placeholder_w//3, placeholder_y + placeholder_h//2), "QR CODE", font=font_small, fill=black)

        # === Save card to buffer ===
        buf = io.BytesIO()
        card.save(buf, format="PNG")
        buf.seek(0)

        # Send email if requested
        try:
            # Get bytes for email
            image_bytes = buf.getvalue()

            # 📧 Send email
            email_result = await send_id_card_email(
                full_name,
                image_bytes
            )

            if email_result:
                return {
                    "message": "✅ ID card generated and sent to email successfully!",
                    "email_sent": True,
                    "recipient_name": full_name,
                    "id_card_data": {
                        "ID": ID,
                        "role": role,
                        "phone": phone_number
                    }
                }
            else:
                return {
                    "message": "⚠️ ID card generated, but email sending failed. Returning image instead.",
                    "email_sent": False,
                    "recipient_name": full_name,
                    "id_card_data": {
                        "ID": ID,
                        "role": role,
                        "phone": phone_number
                    }
                }

        except Exception as email_error:
            # If email fails, still return the ID card image
            buf.seek(0)
            return StreamingResponse(buf, media_type="image/png")

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"ID card generation failed: {str(e)}")
# ================ PERSONALIZED DASHBOARDS =================

@router.get("/profile/{vision_id}")
async def get_user_profile(
    vision_id: str,
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    try:
        # First try to find in id_card_profiles
        profile = await db.id_card_profiles.find_one({"vision_id": vision_id})
        if profile:
            return {
                "success": True,
                "profile_type": "id_card",
                "profile": {
                    "vision_id": profile.get("vision_id"),
                    "full_name": profile.get("full_name"),
                    "role": profile.get("role"),
                    "website": profile.get("website", "www.visionhelp.org"),
                    "verified": True,
                    "member_type": "ID Card Holder"
                }
            }
        
        # Try to find in vision_users
        user = await db.vision_users.find_one({"vision_id": vision_id})
        if user:
            return {
                "success": True,
                "profile_type": "member",
                "profile": {
                    "vision_id": user.get("vision_id"),
                    "full_name": user.get("full_name"),
                    "username": user.get("username"),
                    "role": user.get("role"),
                    "member_since": user.get("created_at"),
                    "verified": user.get("is_active", True),
                    "member_type": "Vision Family Member",
                    "dashboard_url": user.get("dashboard_url")
                }
            }
        
        raise HTTPException(
            status_code=404,
            detail=f"No profile found for Vision ID: {vision_id}"
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error fetching profile: {str(e)}"
        )

# ================ PERSONALIZED DASHBOARDS =================

@router.get("/profile/{vision_id}")
async def get_user_profile(
    vision_id: str,
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    try:
        # First try to find in id_card_profiles
        profile = await db.id_card_profiles.find_one({"vision_id": vision_id})
        if profile:
            return {
                "success": True,
                "profile_type": "id_card",
                "profile": {
                    "vision_id": profile.get("vision_id"),
                    "full_name": profile.get("full_name"),
                    "role": profile.get("role"),
                    "website": profile.get("website", "www.visionhelp.org"),
                    "verified": True,
                    "member_type": "ID Card Holder"
                }
            }
        
        # Try to find in vision_users
        user = await db.vision_users.find_one({"vision_id": vision_id})
        if user:
            return {
                "success": True,
                "profile_type": "member",
                "profile": {
                    "vision_id": user.get("vision_id"),
                    "full_name": user.get("full_name"),
                    "username": user.get("username"),
                    "role": user.get("role"),
                    "member_since": user.get("created_at"),
                    "verified": user.get("is_active", True),
                    "member_type": "Vision Family Member",
                    "dashboard_url": user.get("dashboard_url")
                }
            }
        
        raise HTTPException(
            status_code=404,
            detail=f"No profile found for Vision ID: {vision_id}"
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error fetching profile: {str(e)}"
        )

@router.get("/dashboard/{role}")
async def get_personalized_dashboard(
    role: Literal["vision-marshal", "career-seeker", "supporter", "donor"],
    request: Request,
    user_id: str = Query(None),  # Make user_id optional
    authorization: str = Header(None),  # Try to get user from auth header
    db = Depends(get_database)
):
    try:
        # If no user_id provided, try to extract from auth token
        if not user_id and authorization:
            if authorization.startswith("Bearer "):
                token = authorization.replace("Bearer ", "")
                try:
                    from app.utils.auth_utils import decode_jwt_token
                    payload = decode_jwt_token(token)
                    user_id = payload.get("user_id")
                except Exception as e:
                    logger.warning(f"Failed to decode token: {e}")
        
        # If still no user_id, create a demo experience
        if not user_id:
            return {
                "success": True,
                "role": role.replace("-", " ").title(),
                "dashboard_type": role,
                "demo_mode": True,
                "user_info": {
                    "username": "demo_user",
                    "vision_id": "VIS000000",
                    "full_name": "Demo User",
                    "member_since": datetime.now(timezone.utc).isoformat(),
                    "profile_url": f"{str(request.base_url).rstrip('/')}/onboarding/profile/VIS000000"
                },
                "dashboard_data": {
                    "total_activities": 1,
                    "completion_score": 10,
                    "recent_activities": [],
                    "last_active": datetime.now(timezone.utc).isoformat(),
                    "demo_data": True
                },
                "last_access": datetime.now(timezone.utc),
                "permissions": {"demo_access": True},
            }

        # Get user data
        user_data = await db.vision_users.find_one({"_id": user_id})
        if not user_data:
            raise HTTPException(
                status_code=404,
                detail="User profile not found."
            )

        # Normalize roles
        user_role = user_data.get("role", "").lower().replace(" ", "-")
        requested_role = role.lower()

        # Check role match (less strict since no auth)
        if user_role not in [requested_role, "admin", "super_admin"]:
            raise HTTPException(
                status_code=403,
                detail=f"Access denied. Your role: {user_role}, Requested: {role}"
            )

        # Update dashboard access status
        await db.vision_users.update_one(
            {"_id": user_id},
            {
                "$set": {
                    "onboarding_status.dashboard_accessed": True,
                    "last_dashboard_access": datetime.now(timezone.utc)
                }
            }
        )

        # Get dashboard data
        dashboard_data = await get_efficient_dashboard_data(role, user_id, db)

        base_url = str(request.base_url).rstrip('/')

        return {
            "success": True,
            "role": user_data.get("role"),
            "dashboard_type": role,
            "user_info": {
                "username": user_data.get("username"),
                "vision_id": user_data.get("vision_id"),
                "full_name": f"{user_data.get('first_name', '')} {user_data.get('last_name', '')}",
                "member_since": user_data.get("created_at"),
                "profile_url": f"{base_url}/onboarding/profile/{user_data.get('vision_id')}"
            },
            "dashboard_data": dashboard_data,
            "last_access": datetime.now(timezone.utc),
            "permissions": user_data.get("platform_permissions", {})
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Dashboard access failed: {str(e)}"
        )

async def get_efficient_dashboard_data(role: str, user_id: str, db):
    try:
        # Check if activities exist
        has_activities = await db.activities.count_documents({"user_id": user_id}) > 0

        if not has_activities:
            sample_activities = [
                {
                    "_id": str(ObjectId()),
                    "user_id": user_id,
                    "type": "profile_update",
                    "action": "completed_profile",
                    "points": 50,
                    "timestamp": datetime.now(timezone.utc),
                    "description": "Completed profile setup"
                },
                {
                    "_id": str(ObjectId()),
                    "user_id": user_id,
                    "type": "job_application" if role == "career-seeker" else "content",
                    "action": "job_application" if role == "career-seeker" else "uploaded_media",
                    "points": 75,
                    "timestamp": datetime.now(timezone.utc),
                    "description": "First application submitted" if role == "career-seeker" else "Shared first story"
                }
            ]
            await db.activities.insert_many(sample_activities)

        # Get recent activities
        cursor = db.activities.find({"user_id": user_id}).sort("timestamp", -1).limit(5)
        recent_activities = []
        async for activity in cursor:
            activity['_id'] = str(activity['_id'])
            recent_activities.append(activity)

        total_activities = await db.activities.count_documents({"user_id": user_id})

        base_data = {
            "total_activities": total_activities or 1,
            "completion_score": min(100, (total_activities or 1) * 10),
            "recent_activities": recent_activities,
            "last_active": datetime.now(timezone.utc).isoformat()
        }

        # Role-specific extras
        if role == "career-seeker":
            applications = await db.activities.count_documents({
                "user_id": user_id,
                "action": "job_application"
            }) or 1
            base_data.update({
                "applications_sent": applications,
                "profile_completion": 80,
                "skill_score": "Intermediate",
                "job_matches": applications * 3,
                "interview_invites": max(1, applications // 2)
            })

        elif role == "vision-marshal":
            uploads = await db.activities.count_documents({
                "user_id": user_id,
                "action": "uploaded_media"
            })
            base_data.update({
                "stories_shared": uploads,
                "community_impact": uploads * 10,
                "marshal_level": "Rising Star" if uploads < 5 else "Community Leader"
            })

        elif role == "supporter":
            support_events = await db.activities.count_documents({
                "user_id": user_id,
                "action": "supported_project"
            })
            base_data.update({
                "projects_supported": support_events,
                "people_helped": support_events * 5,
                "support_level": "Community Helper" if support_events < 5 else "Impact Maker"
            })

        elif role == "donor":
            donations = await db.donations.count_documents({"user_id": user_id})
            base_data.update({
                "total_donations": donations,
                "impact_score": donations * 25,
                "donor_level": "Bronze Donor" if donations < 5 else "Silver Donor"
            })

        return base_data

    except Exception as e:
        return {
            "total_activities": 1,
            "completion_score": 10,
            "recent_activities": [],
            "error": str(e),
            "applications_sent": 1 if role == "career-seeker" else 0,
            "profile_completion": 50,
            "default_data": True,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
# ================= ONBOARDING STATUS & PROGRESS =================

@router.get("/status")
async def check_onboarding_status(user = Depends(get_current_user), db = Depends(get_database)):

    user_data = await db.vision_users.find_one({"_id": user.get("user_id")})
    if not user_data:
        raise HTTPException(status_code=404, detail="User not found")
    
    onboarding_status = user_data.get("onboarding_status", {})
    
    return {
        "user_id": user.get("user_id"),
        "vision_id": user.get("vision_id"),
        "role": user.get("role"),
        "progress": {
            "profile_setup": onboarding_status.get("profile_setup", False),
            "role_selected": onboarding_status.get("role_selected", False),
            "dashboard_accessed": onboarding_status.get("dashboard_accessed", False),
            "completion_percentage": onboarding_status.get("completion_percentage", 0)
        },
        "next_action": get_next_onboarding_action(onboarding_status, user.get("role")),
        "dashboard_url": user_data.get("dashboard_url"),
        "qr_code_url": user_data.get("qr_code_data")
    }

def get_next_onboarding_action(status: dict, role: str) -> str:
    if not status.get("dashboard_accessed", False):
        return f"Access your {role} dashboard"
    elif status.get("completion_percentage", 0) < 100:
        return "Complete your first activity"
    else:
        return "Explore advanced features"

# ================= EFFICIENT USER MANAGEMENT =================

@router.get("/my-profile")
async def get_my_profile(user = Depends(get_current_user), db = Depends(get_database)):
      
    user_data = await db.vision_users.find_one({"_id": user.get("user_id")})
    if not user_data:
        raise HTTPException(status_code=404, detail="Profile not found")
    
    return {
        "profile": {
            "user_id": user_data.get("_id"),
            "full_name": user_data.get("full_name"),
            "username": user_data.get("username"),
            "email": user_data.get("email"),
            "phone_number": user_data.get("phone_number"),
            "location": user_data.get("location"),
            "role": user_data.get("role"),
            "vision_id": user_data.get("vision_id"),
            "member_since": user_data.get("created_at"),
            "is_active": user_data.get("is_active", True)
        },
        "onboarding_progress": user_data.get("onboarding_status", {}),
        "platform_access": user_data.get("platform_permissions", {}),
        "dashboard_url": user_data.get("dashboard_url"),
        "qr_code_url": user_data.get("qr_code_data"),
        "role_specific_data": await get_efficient_dashboard_data(
            user_data.get("role", "").lower().replace(" ", "-"),
            user.get("user_id"),
            db
        )
    }

@router.delete("/delete-account")
async def delete_vision_account(user = Depends(get_current_user), db = Depends(get_database)):
    
    result = await db.vision_users.delete_one({"_id": user.get("user_id")})
    
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Account not found")
    
    return {
        "success": True,
        "message": "Vision account permanently deleted",
        "deleted_user_id": user.get("user_id"),
        "deleted_vision_id": user.get("vision_id"),
    }

# ================= PROFILE VERIFICATION SYSTEM =================

@router.get("/verify/{vision_id}")
async def verify_profile(
    vision_id: str,
    user = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    try:
        # Check if user is admin
        admin_user = await db.vision_users.find_one({"_id": user.get("user_id")})
        if not admin_user or admin_user.get("email") != "arzumehreen050@gmail.com":
            raise HTTPException(
                status_code=403,
                detail="Only admin can verify profiles"
            )

        # Find profile in database
        profile = await db.id_card_profiles.find_one({"vision_id": vision_id})
        
        if not profile:
            # Try to find in main users collection as fallback
            user = await db.vision_users.find_one({"vision_id": vision_id})
            if user:
                return {
                    "success": True,
                    "message": "Profile verified by admin from user database",
                    "verification_type": "user_profile",
                    "profile": {
                        "vision_id": user.get("vision_id"),
                        "full_name": user.get("full_name"),
                        "email": user.get("email"),
                        "phone": user.get("phone"),
                        "role": user.get("selected_role", "Member"),
                        "verified": True,
                        "member_since": user.get("created_at"),
                        "verified_by": {
                            "admin_email": admin_user.get("email"),
                            "verified_at": datetime.now(timezone.utc)
                        }
                    }
                }
            else:
                raise HTTPException(status_code=404, detail="Profile not found")
        
        # Return ID card profile information with admin verification details
        return {
            "success": True,
            "message": "ID Card profile verified successfully by admin",
            "verification_type": "id_card_profile",
            "profile": {
                "vision_id": profile.get("vision_id"),
                "id_number": profile.get("id_number"),
                "full_name": profile.get("full_name"),
                "role": profile.get("role"),
                "phone": profile.get("phone"),
                "email": profile.get("email"),
                "website": profile.get("website"),
                "verified": profile.get("is_verified", True),
                "card_generated_at": profile.get("qr_generated_at"),
                "verification_url": profile.get("verification_url"),
                "verified_by": {
                    "admin_email": admin_user.get("email"),
                    "verified_at": datetime.now(timezone.utc)
                }
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Verification failed: {str(e)}")


