from fastapi import APIRouter, Depends, HTTPException, Form, UploadFile, File
from pydantic import EmailStr  # <-- already imported
from typing import Optional
from motor.motor_asyncio import AsyncIOMotorDatabase  # <-- Add this import for AsyncIOMotorDatabase
from app.database.schemas.users import UserCreate, UserLogin, UserOut
from app.database.schemas.join import VisionUserCreate, VisionUserResponse, LoginRequest
from app.database.models.users import UserDB
from app.database.crud.user_crud import get_user_by_email
from app.database.__init__ import get_database
from app.auth.deps import  get_current_user
from app.utils.auth_utils import verify_password,  hash_password
from app.auth.jwt_handler import create_access_token
import bcrypt
import os
import uuid
from datetime import datetime, timezone
import random

router = APIRouter(prefix="/marshal", tags=["Marshal Panel"])



@router.post("/signup")
async def signup_vision_family(
    first_name: str = Form(...),
    last_name: Optional[str] = Form(""),
    email: EmailStr = Form(...),
    phone_number: str = Form(...),
    location: str = Form(...),
    password: str = Form(...),
    confirm_password: str = Form(...),
    role: Optional[str] = Form(None),
    profile_img: UploadFile = File(...),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    try:
        # Validate using Pydantic
        payload = VisionUserCreate(
            first_name=first_name,
            last_name=last_name,
            email=email,
            phone_number=phone_number,
            location=location,
            password=password,
            confirm_password=confirm_password,
            role=role
        )

        # Check if email exists
        if await db.vision_users.find_one({"email": payload.email}):
            raise HTTPException(status_code=400, detail="Email already registered")

        # Check if phone exists
        if await db.vision_users.find_one({"phone_number": payload.phone_number}):
            raise HTTPException(status_code=400, detail="Phone number already registered")

        full_name = f"{payload.first_name} {payload.last_name}".strip() if payload.last_name else payload.first_name
        hashed_password = bcrypt.hashpw(payload.password.encode('utf-8'), bcrypt.gensalt())
        ID = f"VIS{random.randint(100000, 999999)}"
        username = full_name.lower().replace(" ", "_")
        is_admin = payload.email == "arzumehreen050@gmail.com"
        assigned_role = "Admin" if is_admin else (payload.role or "Career Seeker")

        # Save profile image to disk and store the path
        img_dir = "static/profile_images"
        os.makedirs(img_dir, exist_ok=True)
        img_path = f"{img_dir}/{uuid.uuid4()}_{profile_img.filename}"
        with open(img_path, "wb") as f:
            f.write(await profile_img.read())

        user_document = {
            "_id": str(uuid.uuid4()),
            "first_name": payload.first_name,
            "last_name": payload.last_name,
            "full_name": full_name,
            "username": username,
            "email": payload.email,
            "phone_number": payload.phone_number,
            "location": payload.location,
            "profile_img_path": img_path,
            "password_hash": hashed_password.decode('utf-8'),
            "role": assigned_role,
            "ID": ID,
            "qr_code_data": f"http://localhost:8000/onboarding/profile/{ID}",
            "dashboard_url": f"http://localhost:8000/onboarding/dashboard/admin" if is_admin else f"http://localhost:8000/onboarding/dashboard/{assigned_role.lower().replace(' ', '-')}",
            "onboarding_status": {
                "profile_setup": True,
                "role_selected": True,
                "dashboard_accessed": is_admin,
                "completion_percentage": 100
            },
            "created_at": datetime.now(timezone.utc),
            "is_active": True,
            "account_status": {
                "is_active": True,
                "email_verified": is_admin,
                "phone_verified": is_admin,
                "profile_complete": True
            },
            "verification_status": {
                "is_verified": is_admin,
                "verified_at": datetime.now(timezone.utc) if is_admin else None,
                "verified_by": "System" if is_admin else None
            },
            "platform_permissions": {
                "can_access_dashboard": True,
                "can_change_role": not is_admin,
                "can_generate_qr": True,
                "is_admin": is_admin,
                "can_manage_users": is_admin,
                "can_approve_content": is_admin,
                "full_access": is_admin
            }
        }

        await db.vision_users.insert_one(user_document)

        return {
            "success": True,
            "message": f"🎉 Account created for {full_name}!",
            "user_id": user_document["_id"],
            "ID": ID
        }

    except HTTPException:
        raise
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail=f"Signup failed: {str(e)}")

@router.post("/login")
async def login(
    payload: LoginRequest,
    db: AsyncIOMotorDatabase = Depends(get_database)  # ✅ Dependency here
    # print(db)
):
    email = payload.email
    password = payload.password

    try:
        # Find user by email
        print(db)
        user = await db.vision_users.find_one({"email": email})
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Verify password
        if not bcrypt.checkpw(password.encode("utf-8"), user["password_hash"].encode("utf-8")):
            raise HTTPException(status_code=401, detail="Invalid password")

        # Generate token
        access_token = create_access_token({
            "sub": user["email"],
            "user_id": user["_id"],
            "role": user["role"],
            "ID": user["ID"],
            "username": user["username"],
            "full_name": user.get("full_name", ""),
            "is_admin": user["platform_permissions"].get("is_admin", False)
        })

        return {
            "success": True,
            "message": f"Welcome back, {user.get('full_name', '')}!",
            "authentication": {
                "access_token": access_token,
            },
            "dashboard_url": user.get("dashboard_url"),
            "onboarding_progress": user.get("onboarding_status", {})
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Login failed: {str(e)}")

@router.post("/check-user")
async def check_user_exists(
    request: dict,
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    try:
        email = request.get("email")
        if not email:
            raise HTTPException(status_code=400, detail="Email is required")

        # Check if user exists in vision_users collection
        user = await db.vision_users.find_one({"email": email})
        
        return {
            "success": True,
            "exists": user is not None,
            "email": email
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to check user: {str(e)}")

@router.get("/me", response_model=UserOut)
async def get_me(current_user: UserOut = Depends(get_current_user)):
    return current_user

@router.post("/logout")
async def logout():
    # JWT is stateless – so just tell frontend to delete token
    return {"message": "Logged out (client should delete the token)"}
