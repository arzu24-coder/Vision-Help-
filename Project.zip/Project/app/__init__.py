from fastapi.middleware.cors import CORSMiddleware
from fastapi import FastAPI 
from fastapi.staticfiles import StaticFiles
from app.routes import router  
from starlette.middleware.sessions import SessionMiddleware
import secrets
import os
from pathlib import Path

app = FastAPI()

# Get the base directory (Project folder)
BASE_DIR = Path(__file__).parent.parent.absolute()

# Add session middleware with a secure secret key
app.add_middleware(
    SessionMiddleware, 
    secret_key=secrets.token_urlsafe(32),
    max_age=3600,  # 1 hour
    same_site='lax',
    https_only=False  # Set to True in production with HTTPS
)

# Mount static files for uploads with absolute paths
uploads_dir = os.path.join(BASE_DIR, "uploads")
static_dir = os.path.join(BASE_DIR, "static")

# Ensure directories exist
os.makedirs(uploads_dir, exist_ok=True)
os.makedirs(static_dir, exist_ok=True)

app.mount("/uploads", StaticFiles(directory=uploads_dir), name="uploads")
app.mount("/static", StaticFiles(directory=static_dir), name="static")

# Include all routes from the centralized router
app.include_router(router)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # More specific origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

from fastapi.openapi.utils import get_openapi

def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    schema = get_openapi(
        title="Vision Help API",
        version="1.0.0",
        description="API for Vision Help Welfare Foundation Platform",
        routes=app.routes,
    )
    schema["components"]["securitySchemes"] = {
        "HTTPBearer": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT"
        }
    }
    for path in schema["paths"].values():
        for method in path.values():
            if isinstance(method, dict):  # Ensure it's a method object
                method["security"] = [{"HTTPBearer": []}]
    app.openapi_schema = schema
    return app.openapi_schema

app.openapi = custom_openapi