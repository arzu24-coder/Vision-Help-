from fastapi import APIRouter, HTTPException
from typing import List
from app.database.__init__ import get_database
from uuid import uuid4
from datetime import datetime
from apscheduler.schedulers.background import BackgroundScheduler
import pytz

from . import models, schemas

get_database: List[models.Task] = []
sos_signals: List[models.SOSSignal] = []
def check_missed_tasks():
    now = datetime.now(pytz.UTC)
    for task in get_database():
        if not task.completed and task.due_time < now:
            print(f"⚠️ Notify family: Task '{task.title}' missed by user")

# Start background scheduler
scheduler = BackgroundScheduler()
scheduler.add_job(check_missed_tasks, "interval", minutes=1)  # check every 1 minute
scheduler.start()

