from fastapi import APIRouter, Depends, HTTPException, Query, Body, BackgroundTasks
from fastapi.concurrency import run_in_threadpool
from app.database import get_database
from app.auth.deps import get_current_user, is_admin
from typing import Optional, List, Dict, Any
from bson import ObjectId
from datetime import datetime
import logging
import difflib
import os
import math
import asyncio
import random

# Configure logging
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

# Optional OpenAI client (only used if OPENAI_API_KEY set)
try:
    import openai
    OPENAI_PY_AVAILABLE = True
except Exception:
    OPENAI_PY_AVAILABLE = False

# Constants
OPENAI_API_KEY = os.getenv("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", None)  # or set here as string
OPENAI_EMBEDDING_MODEL = "text-embedding-3-small"   # small & affordable; change if desired
OPENAI_CHAT_MODEL = "gpt-4o-mini"                   # change if desired
FAQ_MATCH_THRESHOLD = float(os.getenv("FAQ_MATCH_THRESHOLD", 0.70))  # stricter by default

if OPENAI_API_KEY and OPENAI_PY_AVAILABLE:
    openai.api_key = OPENAI_API_KEY
    logger.info("OpenAI client available - embeddings/chat enabled")
else:
    if OPENAI_API_KEY and not OPENAI_PY_AVAILABLE:
        logger.warning("OPENAI_API_KEY provided but openai package not installed. Install openai to enable embeddings and chat.")
    logger.info("Running in local similarity mode (no OpenAI)")


def _cosine_similarity(a: List[float], b: List[float]) -> float:
    if not a or not b:
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return max(min(dot / (norm_a * norm_b), 1.0), -1.0)  # clamp -1..1

def _normalize_cosine_to_01(val: float) -> float:
    return (val + 1.0) / 2.0

def calculate_similarity_local(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    return difflib.SequenceMatcher(None, a.lower(), b.lower()).ratio()

from typing import Dict, Optional

def create_sample_suggestions(
    question: Optional[str] = None,
    answer: str = "I don't have a specific answer for that question at the moment. Our team will work on adding this information soon.",
    confidence: float = 0.3,
    faq_id: Optional[str] = None,
    video_url: Optional[str] = None,
    suggested: bool = True
) -> Dict:
    
    return {
        "question": question,
        "answer": answer,
        "source": "system",
        "confidence": confidence,
        "faq_id": faq_id,
        "video_url": video_url,
        "suggested": suggested
    }

def get_sample_suggestions(current_user):
    now = datetime.utcnow()
    user_id = current_user.get("user_id") or current_user.get("sub") or current_user.get("email")
    return [
        {
            "query": "How can I contact Vision Help?",
            "answer": "You can contact Vision Help Welfare Foundation through our website contact form, by email at contact@visionhelp.org, or by phone at +91-1234567890.",
            "suggested_category": "Contact",
            "user_id": user_id,
            "created_at": now,
            "updated_at": now,
            "reviewed": True,
            "source": "sample"
        },
        {
            "query": "What are the education programs at Vision Help?",
            "answer": "Vision Help Welfare Foundation runs several education programs including after-school tutoring, digital literacy classes, scholarships for underprivileged students, and skills development workshops.",
            "suggested_category": "Programs",
            "user_id": user_id,
            "created_at": now,
            "updated_at": now,
            "reviewed": False,
            "source": "sample"
        },
        {
            "query": "How is my donation used?",
            "answer": "Your donations to Vision Help Welfare Foundation are used to fund our education, healthcare, and community development programs. 85% of all donations go directly to program costs, with only 15% used for administrative expenses.",
            "suggested_category": "Donations",
            "user_id": user_id,
            "created_at": now,
            "updated_at": now,
            "reviewed": True,
            "source": "sample"
        }
    ]

async def create_sample_suggestions(db, current_user):
    try:
        sample_suggestions = get_sample_suggestions(current_user)
        await db.faq_suggestions.insert_many(sample_suggestions)
        logger.info(f"Created {len(sample_suggestions)} sample suggestions")
    except Exception as e:
        logger.error(f"Failed to create sample suggestions: {str(e)}")
