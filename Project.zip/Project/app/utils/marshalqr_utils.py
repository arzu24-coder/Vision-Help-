from fastapi import FastAPI
from pathlib import Path
from PIL import Image
import io, smtplib, ssl
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from twilio.rest import Client
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
import qrcode
import os
import logging
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI()

# Export list for explicit imports
__all__ = [
    'send_id_card_email',
    'send_email', 
    'send_whatsapp_message',
    'upload_to_youtube',
    'upload_video_to_youtube',
    'generate_qr_code',
    'process_media_file'
]

LOGO_PATH = Path("/fonts/data/your_logo.png")  # Optional: your org logo

async def send_id_card_email(recipient_email, recipient_name, id_card_image_bytes):
    try:
        # Updated credentials - make sure these are correct
        EMAIL_HOST = "smtp.gmail.com"
        EMAIL_PORT = 587
        EMAIL_ADDRESS = "arzumehreen050@gmail.com"
        EMAIL_PASSWORD = "hsbh ufkl vddt mveu"  # Replace with your actual app password
        
        # Create message
        message = MIMEMultipart()
        message["From"] = EMAIL_ADDRESS
        message["To"] = recipient_email
        message["Subject"] = f"Your Vision Help ID Card - {recipient_name}"
        
        # Simple plain text body in case HTML doesn't work
        plain_text = f"""
        Dear {recipient_name},
        
        Thank you for being part of Vision Help. Your ID card is attached.
        
        Best regards,
        Vision Help Team
        """
        
        # Email body
        html_body = f"""
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                .header {{ background-color: #003366; color: white; padding: 10px; text-align: center; }}
                .content {{ padding: 20px; }}
                .footer {{ text-align: center; margin-top: 20px; font-size: 12px; color: #666; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>Vision Help Welfare Foundation</h1>
                </div>
                <div class="content">
                    <p>Dear <b>{recipient_name}</b>,</p>
                    <p>Thank you for being part of the Vision Help family. We're pleased to provide your official ID card.</p>
                    <p>Your ID card is attached to this email. You can print it or keep it on your device for identification purposes.</p>
                    <p>If you have any questions, please contact us.</p>
                    <p>Best regards,<br>Vision Help Team</p>
                </div>
                <div class="footer">
                    <p>© {datetime.now().year} Vision Help Welfare Foundation.</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        # Attach plain text version first
        message.attach(MIMEText(plain_text, "plain"))
        
        # Attach HTML body
        message.attach(MIMEText(html_body, "html"))
        
        # Ensure the image bytes are properly processed
        if isinstance(id_card_image_bytes, bytes):
            # Already bytes, use directly
            image_data = id_card_image_bytes
        else:
            # Try to read if it's a file-like object
            image_data = id_card_image_bytes.read()
        
        # Create image attachment with explicit content type
        image_attachment = MIMEImage(image_data)
        image_attachment.add_header(
            "Content-Disposition", 
            f"attachment; filename=VisionHelp_ID_{recipient_name.replace(' ', '_')}.png"
        )
        message.attach(image_attachment)
        
        # Use context manager for safer connection handling
        with smtplib.SMTP(EMAIL_HOST, EMAIL_PORT) as server:
            server.ehlo()  # Identify to the SMTP server
            server.starttls()  # Secure the connection
            server.ehlo()  # Re-identify over TLS connection
            server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
            server.send_message(message)
        
        return True
        
    except smtplib.SMTPAuthenticationError:
        # Most common error - authentication failure
        logger.error("SMTP Authentication failed - check email password")
        return False
    except smtplib.SMTPRecipientsRefused:
        # Recipient email address was refused
        logger.error(f"Recipient email refused: {recipient_email}")
        return False
    except smtplib.SMTPException as e:
        # Other SMTP error
        logger.error(f"SMTP error: {str(e)}")
        return False
    except Exception as e:
        # Any other error
        logger.error(f"Failed to send ID card email: {str(e)}")
        return False

# Import configuration
try:
    from config import *
except ImportError:
    # Fallback values if config.py is not found
    EMAIL_HOST = "smtp.gmail.com"
    EMAIL_PORT = 587
    EMAIL_ADDRESS = "arzumehreen050@gmail.com"
    EMAIL_PASSWORD = "hsbh ufkl vddt mveu"
    TWILIO_ACCOUNT_SID = "AC789ce4a17a8b95edcd3ed8354b4316ec"
    TWILIO_AUTH_TOKEN = "a8f9162544f474c6fc85dd720c5f0336"
    TWILIO_WHATSAPP_NUMBER = "whatsapp:+14155238886"
    TWILIO_SMS_NUMBER = "+14155238886"
    YOUTUBE_API_KEY = "AIzaSyDwVLmPcANg49Ta2uVAWBw6POZbFsFRD80"
    ENABLE_YOUTUBE_UPLOAD = True
    ENABLE_WHATSAPP_NOTIFICATIONS = True

# --- Helper: Simple location formatter ---
def format_location(location_string):
    if not location_string or location_string.strip() == "":
        return "Location not specified"
    
    # Clean the location string
    location = location_string.strip()
    
    # Capitalize the first letter of each word
    location_words = location.split()
    formatted_words = [word.capitalize() for word in location_words]
    
    return " ".join(formatted_words)

# --- YouTube Upload Functions ---
try:
    from googleapiclient.errors import HttpError
    from google_auth_oauthlib.flow import InstalledAppFlow
except ImportError:
    # Handle import errors
    pass

def upload_to_youtube(video_path, title, description):
    try:
        # First try OAuth method which is more reliable
        try:
            # Set up YouTube API client directly with API key if OAuth not available
            youtube = build('youtube', 'v3', developerKey=YOUTUBE_API_KEY)
            
            # Create upload request
            body = {
                'snippet': {
                    'title': title,
                    'description': description,
                    'tags': ['Vision Help', 'Community Story'],
                    'categoryId': '22'  # People & Blogs
                },
                'status': {
                    'privacyStatus': 'unlisted',
                    'selfDeclaredMadeForKids': False
                }
            }
            
            # Upload the file
            media = MediaFileUpload(
                video_path, 
                chunksize=1024*1024,
                resumable=True,
                mimetype='video/*'
            )
            
            # Execute the request
            request = youtube.videos().insert(
                part=','.join(body.keys()),
                body=body,
                media_body=media
            )
            
            # Process the request
            response = None
            while response is None:
                status, response = request.next_chunk()
            
            # Get video ID
            if 'id' in response:
                return f"http://localhost:8000/watch/?v={response['id']}"
            
        except Exception as e:
            # Try the OAuth flow as a fallback
            try:
                # Set up OAuth 2.0 flow for YouTube API
                client_secrets_file = "youtube_credentials.json"
                scopes = ["https://www.googleapis.com/auth/youtube.upload"]
                
                flow = InstalledAppFlow.from_client_secrets_file(client_secrets_file, scopes)
                credentials = flow.run_local_server(port=0)
                youtube = build('youtube', 'v3', credentials=credentials)
                
                # Create request body
                body = {
                    'snippet': {
                        'title': title,
                        'description': description,
                        'tags': ['Vision Help', 'Community Story'],
                        'categoryId': '22'  # People & Blogs
                    },
                    'status': {
                        'privacyStatus': 'unlisted',
                        'selfDeclaredMadeForKids': False
                    }
                }
                
                # Upload the file
                media = MediaFileUpload(
                    video_path, 
                    chunksize=1024*1024,
                    resumable=True
                )
                
                # Execute the request
                request = youtube.videos().insert(
                    part=','.join(body.keys()),
                    body=body,
                    media_body=media
                )
                
                # Process the request
                response = None
                while response is None:
                    status, response = request.next_chunk()
                
                # Get video ID
                if 'id' in response:
                    return f"http://localhost:8000/watch/?v={response['id']}"
            except Exception as oauth_error:
                return None
                
        return None
        
    except Exception as e:
        return None

def upload_with_api_key(video_path, title, description):
    try:
        # Build YouTube service
        youtube = build('youtube', 'v3', developerKey=YOUTUBE_API_KEY)
        
        # Define video metadata
        body = {
            'snippet': {
                'title': title,
                'description': description,
                'tags': ['community', 'social', 'vision help', 'welfare'],
                'categoryId': '25'  # News & Politics category
            },
            'status': {
                'privacyStatus': 'public',  # Make videos public
                'selfDeclaredMadeForKids': False
            }
        }
        
        # Create media upload object
        media = MediaFileUpload(video_path, chunksize=-1, resumable=True)
        
        # Execute upload request
        request = youtube.videos().insert(
            part=','.join(body.keys()),
            body=body,
            media_body=media
        )
        
        response = request.execute()
        
        if response and 'id' in response:
            video_id = response['id']
            youtube_url = f"http://localhost:8000/watch/{video_id}"
            return youtube_url
        else:
            return None
        
    except Exception as e:
        # Log the error and return None to try other methods
        return None

def upload_with_oauth2(video_path, title, description):
    try:
        import pickle
        from google.auth.transport.requests import Request
        from google_auth_oauthlib.flow import InstalledAppFlow
        
        SCOPES = ['https://www.googleapis.com/auth/youtube.upload']
        credentials = None
        
        # Load existing credentials
        if os.path.exists('youtube_token.pickle'):
            with open('youtube_token.pickle', 'rb') as token:
                credentials = pickle.load(token)
        
        # If no valid credentials, create new ones
        if not credentials or not credentials.valid:
            if credentials and credentials.expired and credentials.refresh_token:
                credentials.refresh(Request())
            else:
                if not os.path.exists('youtube_client_secret.json'):
                    raise Exception("Missing youtube_client_secret.json")
                
                flow = InstalledAppFlow.from_client_secrets_file(
                    'youtube_client_secret.json', SCOPES)
                credentials = flow.run_local_server(port=0)
            
            # Save credentials
            with open('youtube_token.pickle', 'wb') as token:
                pickle.dump(credentials, token)
        
        # Build YouTube service and upload
        youtube = build('youtube', 'v3', credentials=credentials)
        return execute_youtube_upload(youtube, video_path, title, description)
    except ImportError:
        raise Exception("OAuth2 libraries not installed")
    except Exception as e:
        raise Exception(f"OAuth2 authentication failed: {str(e)}")

def upload_with_service_account(video_path, title, description):
    try:
        from google.oauth2 import service_account
        
        if not os.path.exists('youtube_service_account.json'):
            raise Exception("Missing youtube_service_account.json")
        
        credentials = service_account.Credentials.from_service_account_file(
            'youtube_service_account.json',
            scopes=['https://www.googleapis.com/auth/youtube.upload']
        )
        
        youtube = build('youtube', 'v3', credentials=credentials)
        return execute_youtube_upload(youtube, video_path, title, description)
    except ImportError:
        raise Exception("Service account libraries not installed")
    except Exception as e:
        raise Exception(f"Service account upload failed: {str(e)}")

def execute_youtube_upload(youtube, video_path, title, description):
    video_metadata = {
        "snippet": {
            "title": title,
            "description": description,
            "tags": ["Vision Help", "Community", "Welfare", "Social Impact"],
            "categoryId": "25"  # News & Politics
        },
        "status": {
            "privacyStatus": "public",
            "selfDeclaredMadeForKids": False
        }
    }
    
    media = MediaFileUpload(video_path, chunksize=-1, resumable=True)
    
    insert_request = youtube.videos().insert(
        part=",".join(video_metadata.keys()),
        body=video_metadata,
        media_body=media
    )
    
    response = insert_request.execute()
    
    if response and 'id' in response:
        video_id = response['id']
        return f"http://localhost:8000/watch/{video_id}"
    else:
        raise Exception("Upload response missing video ID")

# Alias function for backward compatibility - MUST be at module level
def upload_video_to_youtube(video_path, title, description):
    return upload_to_youtube(video_path, title, description)



client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

def send_whatsapp_message(to_number: str, message: str):
    if not ENABLE_WHATSAPP_NOTIFICATIONS:
        return {"status": "disabled", "message": "WhatsApp notifications are disabled"}
    
    # Clean and format phone number
    clean_number = to_number.strip()
    if not clean_number.startswith('+'):
        # Add +91 for Indian numbers if no country code
        if len(clean_number) == 10:
            clean_number = f"+91{clean_number}"
        else:
            clean_number = f"+{clean_number}"
    
    # Try WhatsApp first for ALL numbers (not just sandbox)
    try:
        msg = client.messages.create(
            from_=TWILIO_WHATSAPP_NUMBER,
            body=message,
            to=f"whatsapp:{clean_number}"
        )
        
        return {
            "status": "sent", 
            "sid": msg.sid, 
            "type": "whatsapp", 
            "to": clean_number
        }
        
    except Exception as whatsapp_error:
        # If WhatsApp fails, try SMS as fallback
        try:
            sms_msg = client.messages.create(
                from_=TWILIO_SMS_NUMBER,
                body=f"📱 {message}",
                to=clean_number
            )
            return {
                "status": "sent", 
                "sid": sms_msg.sid, 
                "type": "sms",
                "to": clean_number,
                "note": "WhatsApp failed, sent via SMS"
            }
        except Exception as sms_error:
            return {
                "status": "failed",
                "type": "notification_failed", 
                "to": clean_number,
                "error": "Both WhatsApp and SMS failed"
            }

# Additional utility functions
def send_email(to_email: str, subject: str, body: str, attachment_path: str = None):
    try:
        message = MIMEMultipart()
        message['From'] = EMAIL_ADDRESS
        message['To'] = to_email
        message['Subject'] = subject
        
        message.attach(MIMEText(body, 'plain'))
        
        if attachment_path:
            with open(attachment_path, "rb") as attachment:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(attachment.read())
                encoders.encode_base64(part)
                part.add_header(
                    'Content-Disposition',
                    f'attachment; filename= {attachment_path.split("/")[-1]}'
                )
                message.attach(part)
        
        context = ssl.create_default_context()
        with smtplib.SMTP(EMAIL_HOST, EMAIL_PORT) as server:
            server.starttls(context=context)
            server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
            server.send_message(message)
        
        return True
    except Exception as e:
        return False

def send_tagged_user_email(email, story_title, story_description, location, youtube_url, uploader_name="Someone"):
    try:
        subject = f"📢 You've been tagged in a new story: {story_title}"
        
        # Create HTML email body
        html_body = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                .email-container {{ max-width: 600px; margin: 0 auto; font-family: Arial, sans-serif; }}
                .header {{ background: linear-gradient(135deg, #1455a0, #6cbaed); color: white; padding: 20px; text-align: center; }}
                .content {{ padding: 20px; background-color: #f9f9f9; }}
                .story-details {{ background: white; padding: 15px; border-radius: 8px; margin: 15px 0; }}
                .button {{ display: inline-block; background-color: #1455a0; color: white; padding: 12px 25px; text-decoration: none; border-radius: 5px; margin: 10px 0; }}
                .footer {{ text-align: center; padding: 20px; color: #666; font-size: 12px; }}
            </style>
        </head>
        <body>
            <div class="email-container">
                <div class="header">
                    <h1>🌟 Vision Help Welfare Foundation</h1>
                    <p>You've been tagged in a community story!</p>
                </div>
                
                <div class="content">
                    <h2>📢 New Story Alert!</h2>
                    <p>Hi there! <strong>{uploader_name}</strong> has tagged you in a new community story.</p>
                    
                    <div class="story-details">
                        <h3>📖 {story_title}</h3>
                        <p><strong>Description:</strong> {story_description}</p>
                        <p><strong>📍 Location:</strong> {location}</p>
                        <p><strong>👤 Tagged by:</strong> {uploader_name}</p>
                    </div>
                    
                    <a href="{youtube_url}" class="button">🎬 Watch Now</a>
                    
                    <p>This story was shared as part of our community impact initiative. Thank you for being part of the Vision Help community!</p>
                </div>
                
                <div class="footer">
                    <p>Vision Help Welfare Foundation | Empowering Through Service</p>
                    <p>This is an automated notification. Please do not reply to this email.</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        # Create message
        message = MIMEMultipart("alternative")
        message['From'] = f"Vision Help Welfare Foundation <{EMAIL_ADDRESS}>"
        message['To'] = email
        message['Subject'] = subject
        
        # Add HTML body
        html_part = MIMEText(html_body, 'html')
        message.attach(html_part)
        
        # Send email
        context = ssl.create_default_context()
        
        with smtplib.SMTP(EMAIL_HOST, EMAIL_PORT) as server:
            server.starttls(context=context)
            server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
            server.send_message(message)
        
        return {
            "status": "sent", 
            "type": "email", 
            "recipient": email,
            "message": f"Email notification sent to {email}"
        }
        
    except smtplib.SMTPAuthenticationError as e:
        return {"status": "failed", "type": "email", "recipient": email, "error": f"Authentication failed: {str(e)}"}
    except smtplib.SMTPRecipientsRefused as e:
        return {"status": "failed", "type": "email", "recipient": email, "error": f"Recipient refused: {str(e)}"}
    except smtplib.SMTPException as e:
        return {"status": "failed", "type": "email", "recipient": email, "error": f"SMTP error: {str(e)}"}
    except Exception as e:
        return {"status": "failed", "type": "email", "recipient": email, "error": str(e)}

def generate_qr_code(data: str, file_path: str = None):
    try:
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(data)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        
        if file_path:
            img.save(file_path)
            return file_path
        else:
            buf = io.BytesIO()
            img.save(buf, format='PNG')
            buf.seek(0)
            return buf
    except Exception as e:
        return None

# Process media file without GPS
def process_media_file(file_path: str, file_type: str = "image"):
    try:
        if file_type == "image":
            img = Image.open(file_path)
            return {
                "file_path": file_path,
                "size": img.size,
                "format": img.format
            }
        elif file_type == "video":
            return {
                "file_path": file_path
            }
        else:
            return {"file_path": file_path}
    except Exception as e:
        return None
 
def generate_qr_code(data: str, file_path: str = None):
    try:
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(data)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        
        if file_path:
            img.save(file_path)
            return file_path
        else:
            buf = io.BytesIO()
            img.save(buf, format='PNG')
            buf.seek(0)
            return buf
    except Exception as e:
        return None

def process_media_file(file_path: str, file_type: str = "image"):
    try:
        if file_type == "image":
            img = Image.open(file_path)
            return {
                "file_path": file_path,
                "size": img.size,
                "format": img.format,
            }
        elif file_type == "video":
            return {
                "file_path": file_path,
                "size": None,
                "format": None,
            }
        else:
            return {"file_path": file_path}
    except Exception as e:
        return None
    except Exception as e:
        return None

def process_media_file(file_path: str, file_type: str = "image"):
    try:
        if file_type == "image":
            img = Image.open(file_path)
            return {
                "file_path": file_path,
                "size": img.size,
                "format": img.format,
               
            }
        elif file_type == "video":
            return {
                "file_path": file_path,
                "size": None,
                "format": None,
            }
        else:
            return {"file_path": file_path}
    except Exception as e:
        return None
    except Exception as e:
        return None

def send_tagged_user_email(email, title, description, location, media_url, sender_name):
    try:
        subject = f"📢 You've been tagged in a new story: {title}"
        
        # Create HTML email body with proper media handling
        html_body = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                .email-container {{ max-width: 600px; margin: 0 auto; font-family: Arial, sans-serif; }}
                .header {{ background: linear-gradient(135deg, #1455a0, #6cbaed); color: white; padding: 20px; text-align: center; }}
                .content {{ padding: 20px; background-color: #f9f9f9; }}
                .story-details {{ background: white; padding: 15px; border-radius: 8px; margin: 15px 0; }}
                .button {{ display: inline-block; background-color: #1455a0; color: white; padding: 12px 25px; text-decoration: none; border-radius: 5px; margin: 10px 0; }}
                .footer {{ text-align: center; padding: 20px; color: #666; font-size: 12px; }}
                .media-container {{ margin: 15px 0; text-align: center; }}
            </style>
        </head>
        <body>
            <div class="email-container">
                <div class="header">
                    <h1>🌟 Vision Help Welfare Foundation</h1>
                    <p>You've been tagged in a community story!</p>
                </div>
                
                <div class="content">
                    <h2>📢 New Story Alert!</h2>
                    <p>Hi there! <strong>{sender_name}</strong> has tagged you in a new community story.</p>
                    
                    <div class="story-details">
                        <h3>📖 {title}</h3>
                        <p><strong>Description:</strong> {description}</p>
                        <p><strong>📍 Location:</strong> {location}</p>
                        <p><strong>👤 Tagged by:</strong> {sender_name}</p>
                    </div>
                    
                    <div class="media-container">
                        {get_media_embed(media_url) if media_url else ''}
                    </div>
                    
                    <a href="{media_url if media_url else 'http://localhost:8000/stories'}" class="button">
                        {get_button_text(media_url)}
                    </a>
                    
                    <p>This story was shared as part of our community impact initiative. Thank you for being part of the Vision Help community!</p>
                </div>
                
                <div class="footer">
                    <p>Vision Help Welfare Foundation | Empowering Through Service</p>
                    <p>This is an automated notification. Please do not reply to this email.</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        # Create message
        message = MIMEMultipart("alternative")
        message['From'] = f"Vision Help Welfare Foundation <{EMAIL_ADDRESS}>"
        message['To'] = email
        message['Subject'] = subject
        
        # Add HTML body
        html_part = MIMEText(html_body, 'html')
        message.attach(html_part)
        
        # Send email
        context = ssl.create_default_context()
        
        with smtplib.SMTP(EMAIL_HOST, EMAIL_PORT) as server:
            server.starttls(context=context)
            server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
            server.send_message(message)
        
        return {
            "status": "sent", 
            "type": "email", 
            "recipient": email,
            "message": f"Email notification sent to {email}"
        }
        
    except smtplib.SMTPAuthenticationError as e:
        return {"status": "failed", "type": "email", "recipient": email, "error": f"Authentication failed: {str(e)}"}
    except smtplib.SMTPRecipientsRefused as e:
        return {"status": "failed", "type": "email", "recipient": email, "error": f"Recipient refused: {str(e)}"}
    except smtplib.SMTPException as e:
        return {"status": "failed", "type": "email", "recipient": email, "error": f"SMTP error: {str(e)}"}
    except Exception as e:
        return {"status": "failed", "type": "email", "recipient": email, "error": str(e)}
    
# Helper function to generate appropriate media embed HTML
def get_media_embed(url):
    if not url:
        return ""
        
    if "youtube.com" in url or "youtu.be" in url:
        # Extract YouTube video ID and create embed
        video_id = ""
        if "?v=" in url:
            video_id = url.split("?v=")[1].split("&")[0]
        elif "youtu.be/" in url:
            video_id = url.split("youtu.be/")[1].split("?")[0]
            
        if video_id:
            return f"""
            <div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; max-width: 100%; margin: 15px 0;">
                <iframe 
                    style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;" 
                    src="https://www.youtube.com/embed/{video_id}" 
                    frameborder="0" 
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    allowfullscreen>
                </iframe>
            </div>
            """
    
    # For images, include an img tag
    if any(ext in url.lower() for ext in ['.jpg', '.jpeg', '.png', '.gif']):
        return f'<img src="{url}" alt="Story media" style="max-width: 100%; height: auto; border-radius: 8px;">'
    
    # For videos, add a fallback text with link
    if any(ext in url.lower() for ext in ['.mp4', '.mov', '.avi']):
        return f'<p style="text-align:center;"><strong>📹 Video attached - <a href="{url}">Click here to view</a></strong></p>'
    
    # Default - just a link to the content
    return f'<p style="text-align:center;"><a href="{url}">Click to view media content</a></p>'

# Helper function for button text
def get_button_text(url):
    if not url:
        return "🔍 View Stories"
        
    if "youtube.com" in url or "youtu.be" in url:
        return "🎬 Watch on YouTube"
    
    if any(ext in url.lower() for ext in ['.mp4', '.mov', '.avi']):
        return "📹 Watch Video"
        
    if any(ext in url.lower() for ext in ['.jpg', '.jpeg', '.png', '.gif']):
        return "🖼️ View Image"
    
    return "🔍 View Content"
