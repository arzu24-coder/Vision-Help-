import razorpay
import os

# Get from .env or use working test credentials  
RAZORPAY_KEY_ID = os.getenv("RAZORPAY_KEY_ID", "rzp_test_R7vr1NPWxZnHX7")
RAZORPAY_KEY_SECRET = os.getenv("RAZORPAY_KEY_SECRET", "R8O0b4amJRxjWsK9HyZvMowZ")

# Create Razorpay client with error handling
try:
    client = razorpay.Client(auth=(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET))
    print(f"Razorpay client initialized with key: {RAZORPAY_KEY_ID}")
except Exception as e:
    print(f"Razorpay client initialization failed: {e}")
    client = None

import hashlib
import hmac
import json
from typing import Optional, Tuple

import stripe


# ---------- Razorpay ----------
def calculate_price(role: str, sub_role: str | None, membership_plan: str | None):
    if role == "Career Seeker":
        return 0
    if role == "Career Supporter":
        return 500
    if role == "Skill Guru":
        return 51
    if role == "Skill Learner":
        return 51
    if role == "Vision Marshal":
        if membership_plan == "Standard":
            return 500
        if membership_plan == "Premium":
            return 2000
    return 0

try:
    import razorpay
except Exception:
    razorpay = None  # allow app to start without package for local dev

def razorpay_client():
    if not razorpay:
        raise RuntimeError("razorpay package not installed")
    return razorpay.Client(auth=(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET))

async def create_razorpay_order(amount: float, currency: str, receipt: str) -> dict:
    client = razorpay_client()
    # Razorpay takes amount in paise
    order = client.order.create({
        "amount": int(amount * 100),
        "currency": currency,
        "receipt": receipt,
        "payment_capture": 1
    })
    return order

def verify_razorpay_signature(payload: bytes, signature: str, secret: str) -> bool:
    # Razorpay webhooks: X-Razorpay-Signature over raw body with webhook secret (NOT key secret)
    # If you’re using the "key secret" here, set that as the webhook secret in dashboard.
    digest = hmac.new(
        bytes(secret, "utf-8"),
        msg=payload,
        digestmod=hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(digest, signature)

# ---------- Stripe ----------
async def create_stripe_payment_intent(amount: float, currency: str, metadata: dict) -> stripe.PaymentIntent:
    # Stripe takes amount in the smallest unit (INR paise / USD cents)
    pi = stripe.PaymentIntent.create(
        amount=int(amount * 100),
        currency=currency.lower(),
        metadata=metadata,
        automatic_payment_methods={"enabled": True}
    )
    return pi

def verify_stripe_event(signature: str, payload: bytes) -> stripe.Event:
    event = stripe.Webhook.construct_event(
        payload=payload,
        sig_header=signature,
        secret=initiate_payment_gateway.STRIPE_WEBHOOK_SECRET,
    )
    return event

def initiate_payment_gateway(amount: float, donor_email: str) -> dict:
    try:
        # Razorpay expects amount in paise (if INR)
        razorpay_order = client.order.create({
            "amount": int(amount * 100),
            "currency": "INR",
            "receipt": f"receipt_{donor_email}",
            "payment_capture": 1  # auto capture
        })

        return {
            "order_id": razorpay_order["id"],
            "amount": amount,
            "currency": "INR",
            "email": donor_email,
            "status": "created"
        }
    except Exception as e:
        return {"error": str(e)}

import smtplib
from email.mime.text import MIMEText

def send_acknowledgment_email(to_email: str, donor_name: str, amount: float):
    sender_email = "arzumehreen050@gmail.com"
    sender_password = "hsbh ufkl vddt mveu"  # App Password or SMTP password
    subject = "Thank You for Your Donation"
    

    message = MIMEText(f"Dear {donor_name},\n\nThank you for donating ₹{amount} to Vision Welfare Foundation")
    message["Subject"] = subject
    message["From"] = sender_email
    message["To"] = to_email

    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, to_email, message.as_string())
    except Exception as e:
        print(f"Failed to send email: {e}")

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

EMAIL_HOST = "smtp.gmail.com"
EMAIL_PORT = 587
EMAIL_ADDRESS = "arzumehreen050@gmail.com"
EMAIL_PASSWORD = "hsbh ufkl vddt mveu"

def send_email_receipt(to_email: str, subject: str, html_body: str):
    try:
        msg = MIMEMultipart("alternative")
        msg["From"] = EMAIL_ADDRESS
        msg["To"] = to_email
        msg["Subject"] = subject
        msg.attach(MIMEText(html_body, "html"))

        with smtplib.SMTP(EMAIL_HOST, EMAIL_PORT) as server:
            server.starttls()
            server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
            server.sendmail(EMAIL_ADDRESS, to_email, msg.as_string())

        print(f"✅ Receipt email sent to {to_email}")
    except Exception as e:
        print(f"❌ Failed to send email: {e}")

from datetime import datetime

def render_receipt_html(name: str, amount: float, currency: str, campaign_title: str, receipt_no: str) -> str:
    today = datetime.utcnow().strftime("%d %B %Y, %H:%M UTC")

    return f"""
    <html>
    <body style="font-family: Arial, sans-serif; background:#f9f9f9; padding:20px;">
        <div style="max-width:600px; margin:auto; background:#ffffff; border:1px solid #ddd; border-radius:8px; padding:20px;">
            <h2 style="text-align:center; color:#2c3e50;">Donation Receipt</h2>
            <p>Dear <b>{name}</b>,</p>
            <p>Thank you for your generous contribution to <b>{campaign_title}</b>. Your support helps us continue our mission at <b>Vision Help</b>.</p>
            
            <table style="width:100%; border-collapse:collapse; margin:20px 0;">
                <tr>
                    <td style="padding:8px; border:1px solid #ddd;"><b>Receipt No</b></td>
                    <td style="padding:8px; border:1px solid #ddd;">{receipt_no}</td>
                </tr>
                <tr>
                    <td style="padding:8px; border:1px solid #ddd;"><b>Donor Name</b></td>
                    <td style="padding:8px; border:1px solid #ddd;">{name}</td>
                </tr>
                <tr>
                    <td style="padding:8px; border:1px solid #ddd;"><b>Campaign</b></td>
                    <td style="padding:8px; border:1px solid #ddd;">{campaign_title}</td>
                </tr>
                <tr>
                    <td style="padding:8px; border:1px solid #ddd;"><b>Amount</b></td>
                    <td style="padding:8px; border:1px solid #ddd;">{currency.upper()} {amount:.2f}</td>
                </tr>
                <tr>
                    <td style="padding:8px; border:1px solid #ddd;"><b>Date</b></td>
                    <td style="padding:8px; border:1px solid #ddd;">{today}</td>
                </tr>
            </table>
            
            <p style="margin-top:20px;">This receipt acknowledges your donation. Please keep it for your records.</p>
            <p style="color:#555;">With gratitude,<br><b>Vision Help Foundation</b></p>
        </div>
    </body>
    </html>
    """