from bson import ObjectId
from datetime import datetime
def serialize_mongodb_doc(doc):
    if isinstance(doc, list):
        return [serialize_mongodb_doc(d) for d in doc]
    if isinstance(doc, dict):
        result = {}
        for k, v in doc.items():
            if isinstance(v, ObjectId):
                result[k] = str(v)
            elif isinstance(v, datetime):
                result[k] = v.isoformat()
            elif isinstance(v, dict) or isinstance(v, list):
                result[k] = serialize_mongodb_doc(v)
            else:
                result[k] = v
        return result
    return doc

