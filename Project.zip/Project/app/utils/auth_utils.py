from jose import jwt, JWTError
from datetime import datetime, timedelta
from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from passlib.context import CryptContext
from app.database.schemas.users import UserOut
from app.database.crud.user_crud import get_user_by_email
from app.database.__init__ import get_database
import random
import logging
import string
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import traceback

SMTP_EMAIL = "arzumehreen050@gmail.com"
SMTP_PASSWORD = "cpus ctsa fdtm dmqs"
SECRET_KEY = "iLPceCf3HeWJzcFHwdOJkroxwAxDGazIrolBLMymCAo"
ALGORITHM = "HS256"

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


# Change from async to regular function since it doesn't need to be async
def generate_otp(length=6):
    return ''.join(random.choice('0123456789') for _ in range(length))

logger = logging.getLogger(__name__)

async def send_email(to_email: str, subject: str, body: str) -> bool:
   
    try:
        message = MIMEMultipart()
        message["From"] = SMTP_EMAIL
        message["To"] = to_email
        message["Subject"] = subject
        
        # Add body to email
        message.attach(MIMEText(body, "plain"))
        
        # Connect to SMTP server and send email
        with smtplib.SMTP("smtp.gmail.com", 587) as server:
            server.starttls()  # Secure the connection
            server.login(SMTP_EMAIL, SMTP_PASSWORD)
            server.send_message(message)
            
        logger.info(f"Email sent successfully to {to_email}")
        return True
        
    except Exception as e:
        logger.error(f"Failed to send email: {str(e)}")
        return False