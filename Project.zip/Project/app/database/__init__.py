from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase
from pymongo.collection import Collection
import os

MONGO_DETAILS = os.getenv("MONGO_DETAILS")
print(MONGO_DETAILS)
client = AsyncIOMotorClient('mongodb+srv://amit24ve:Amit%402403.@trading.70xxozj.mongodb.net/?retryWrites=true&w=majority&appName=trading')
database = client["Vission_Users"]
user_collection: Collection = database.get_collection("user")
vision_users_collection: Collection = database.get_collection("vision_users")  # Fixed naming
marshal_collection: Collection= database.get_collection("marshals")
skill_share_collection: Collection = database.get_collection("skill_share")
career_collection: Collection = database.get_collection("career")
honor_board_collection: Collection = database.get_collection("honor_board")
admin_collection: Collection = database.get_collection("admin")
donation_collection: Collection = database.get_collection("donation")

def get_database() -> AsyncIOMotorDatabase:
    return database