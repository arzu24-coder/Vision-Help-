
from app.database.__init__ import get_database

async def ensure_indexes():
    db= get_database()
    await db.campaigns.create_index("verified")
    await db.campaigns.create_index("created_at")
    await db.donations.create_index("campaign_id")
    await db.donations.create_index("status")
    await db.donations.create_index("provider")
    await db.donations.create_index("provider_payment_id", unique=False, sparse=True)
    await db.donations.create_index("provider_order_id", unique=False, sparse=True)
    await db.donations.create_index("event_id", unique=True, sparse=True)  # webhook idempotency

async def create_campaign(db, data: dict):
    await db["donation"].insert_one(data)
    return data

async def get_campaigns(db):
    campaigns = []
    cursor = db["campaigns"].find({})
    async for doc in cursor:
        doc["_id"] = str(doc["_id"])  # convert ObjectId to string
        campaigns.append(doc)
    return campaigns

async def donate_to_campaign(db, donation_data: dict):
    from bson import ObjectId
    
    # Save donation entry
    await db["donation"].insert_one(donation_data)

    # Convert campaign_id string to ObjectId for MongoDB query
    try:
        campaign_object_id = ObjectId(donation_data["campaign_id"])
    except Exception as e:
        raise ValueError(f"Invalid campaign_id: {e}")

    # Increment raised amount in the campaigns collection
    updated_campaign = await db["campaigns"].find_one_and_update(
        {"_id": campaign_object_id},
        {"$inc": {"amount_raised": donation_data["amount"]}},
        return_document=True
    )
    
    if not updated_campaign:
        raise ValueError(f"Campaign with id {donation_data['campaign_id']} not found")

    # Check if campaign is now complete
    if updated_campaign["amount_raised"] >= updated_campaign.get("target_amount", 0):
        await db["campaigns"].update_one(
            {"_id": campaign_object_id},
            {"$set": {"completed": True}}
        )