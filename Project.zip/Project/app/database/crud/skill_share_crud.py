from motor.motor_asyncio import AsyncIOMotorDatabase
from bson import ObjectId
from app.database.__init__ import skill_share_collection
from datetime import datetime

# ------------------ Helper ------------------

def serialize_doc(doc):
    doc["id"] = str(doc["_id"])
    del doc["_id"]
    return doc

# ------------------ CREATE ------------------


async def save_user_profile(db, user_profile: dict):
    # Upsert user profile data based on user_id
    await skill_share_collection.update_one(
        {"user_id": user_profile["user_id"]},
        {"$set": user_profile},
        upsert=True
    )

async def create_learner(db: AsyncIOMotorDatabase, data: dict):
    data["type"] = "learner"
    data["created_at"] = datetime.utcnow()
    result = await db["skill_share"].insert_one(data)
    return {"id": str(result.inserted_id)}

async def enroll_learner(db: AsyncIOMotorDatabase, data: dict):
    data["type"] = "enrollment"
    data["created_at"] = datetime.utcnow()
    data["learner_id"] = ObjectId(data["learner_id"])
    data["content_id"] = ObjectId(data["content_id"])
    result = await db["skill_share"].insert_one(data)
    return str(result.inserted_id)

async def create_content(db: AsyncIOMotorDatabase, data: dict):
    data["type"] = "content"
    data["created_at"] = datetime.utcnow()
    data["educator_id"] = ObjectId(data["educator_id"])
    result = await db["skill_share"].insert_one(data)
    return str(result.inserted_id)

async def create_quiz(db: AsyncIOMotorDatabase, data: dict):
    data["type"] = "quiz"
    data["created_at"] = datetime.utcnow()
    data["content_id"] = ObjectId(data["content_id"])
    result = await db["skill_share"].insert_one(data)
    return str(result.inserted_id)

async def save_quiz(db, quiz_data: dict):
    result = await db["skill_share"].insert_one(quiz_data)
    return result.inserted_id
# ------------------ AUTH ------------------

async def authenticate_learner(db: AsyncIOMotorDatabase, email: str, password: str):
    learner = await db["skill_share"].find_one({
        "type": "learner", 
        "email": email, 
        "password": password  # Password hash match assumed
    })
    return serialize_doc(learner) if learner else None

# ------------------ GET ------------------

async def list_learners(db: AsyncIOMotorDatabase):
    learners_cursor = db["skill_share"].find({"type": "learner"})
    return [serialize_doc(learner) async for learner in learners_cursor]

async def get_contents_by_educator(db: AsyncIOMotorDatabase, educator_id: str):
    contents_cursor = db["skill_share"].find({
        "type": "content",
        "educator_id": ObjectId(educator_id)
    })
    contents = []
    async for content in contents_cursor:
        content["id"] = str(content["_id"])
        content["educator_id"] = str(content["educator_id"])
        del content["_id"]
        contents.append(content)
    return contents

async def get_enrollments(db: AsyncIOMotorDatabase, content_id: str):
    enroll_cursor = db["skill_share"].find({
        "type": "enrollment",
        "content_id": ObjectId(content_id)
    })
    enrollments = []
    async for e in enroll_cursor:
        e["id"] = str(e["_id"])
        e["learner_id"] = str(e["learner_id"])
        e["content_id"] = str(e["content_id"])
        del e["_id"]
        enrollments.append(e)
    return enrollments
