from motor.motor_asyncio import AsyncIOMotorDatabase
from fastapi import HTTPException
from bson import ObjectId
from datetime import datetime
import uuid
from app.database.schemas.membership import PaymentMethod


# Add missing PaymentMethod class that was referenced but not defined


async def get_available_plans(db: AsyncIOMotorDatabase):
    plans = await db.membership_plans.find({}).to_list(100)
    
    # If no plans exist, create default ones with the new pricing structure
    if not plans:
        default_plans = [
            {
                "plan_id": str(uuid.uuid4()),
                "name": "Seeker Support",
                "role": "Supporter",
                "price": 100,
                "duration_days": 30,
                "benefits": [
                    "Support partial course fee for one Seeker",
                    "Monthly impact report",
                    "Support acknowledgment"
                ],
                "description": "Help a Career Seeker with partial course fees",
                "is_popular": False,
                "impact": "Supports 1 Career Seeker"
            },
            {
                "plan_id": str(uuid.uuid4()),
                "name": "Marshal & Mentor Support",
                "role": "Supporter",
                "price": 500,
                "duration_days": 30,
                "benefits": [
                    "Provide tools or support to one Marshal or Mentor",
                    "Monthly impact report",
                    "Personalized thank you message",
                    "Support acknowledgment on website"
                ],
                "description": "Equip our Vision Marshals and Mentors with the tools they need",
                "is_popular": True,
                "impact": "Supports 1 Marshal or Mentor"
            },
            {
                "plan_id": str(uuid.uuid4()),
                "name": "Child Education Sponsor",
                "role": "Donor",
                "price": 1000,
                "duration_days": 30,
                "benefits": [
                    "Sponsor complete 30-day education for one child",
                    "Detailed impact report",
                    "Child progress updates",
                    "Certificate of appreciation",
                    "Tax benefits"
                ],
                "description": "Provide full educational support to a child for a month",
                "is_popular": True,
                "impact": "Sponsors 1 child's education for 30 days"
            },
            {
                "plan_id": str(uuid.uuid4()),
                "name": "Device & Medical Support",
                "role": "Donor",
                "price": 2500,
                "duration_days": 30,
                "benefits": [
                    "Device support for 5 children or one medical case",
                    "Comprehensive impact documentation",
                    "Monthly video updates",
                    "VIP donor recognition",
                    "Tax benefits"
                ],
                "description": "Fund devices for education or support medical treatment",
                "is_popular": False,
                "impact": "Supports 5 children with devices or 1 medical case"
            },
            {
                "plan_id": str(uuid.uuid4()),
                "name": "Vision Premium Sponsor",
                "role": "Donor",
                "price": 5000,
                "duration_days": 30,
                "benefits": [
                    "Sponsor education/health for 10 needy individuals",
                    "Premium donor status",
                    "Personalized impact reports",
                    "Recognition in annual report",
                    "Direct communication with beneficiaries",
                    "Tax benefits"
                ],
                "description": "Make a significant impact by supporting education and health needs",
                "is_popular": True,
                "impact": "Sponsors 10 individuals with education/health support",
                "discount_percent": 5
            }
        ]
        await db.membership_plans.insert_many(default_plans)
        plans = default_plans
    
    return plans

async def process_payment(payment_method: PaymentMethod, amount: float, user_id: str, db: AsyncIOMotorDatabase):
    if payment_method.method == "wallet":
        # Check wallet balance
        wallet = await db.wallets.find_one({"user_id": user_id})
        if not wallet or wallet.get("balance", 0) < amount:
            raise HTTPException(status_code=400, detail="Insufficient wallet balance")
        
        # Deduct from wallet
        await db.wallets.update_one(
            {"user_id": user_id},
            {"$inc": {"balance": -amount}}
        )
        
        # Create transaction record
        transaction_id = str(uuid.uuid4())
        await db.transactions.insert_one({
            "transaction_id": transaction_id,
            "user_id": user_id,
            "amount": amount,
            "type": "membership_payment",
            "payment_method": "wallet",
            "status": "completed",
            "timestamp": datetime.utcnow()
        })
        
        return {"success": True, "transaction_id": transaction_id, "method": "wallet"}
    
    elif payment_method.method == "direct_payment":
        # Simulate payment processing
        transaction_id = payment_method.transaction_id or str(uuid.uuid4())
        
        # Record transaction
        await db.transactions.insert_one({
            "transaction_id": transaction_id,
            "user_id": user_id,
            "amount": amount,
            "type": "membership_payment",
            "payment_method": "direct_payment",
            "status": "completed",
            "timestamp": datetime.utcnow(),
            "details": payment_method.details
        })
        
        return {"success": True, "transaction_id": transaction_id, "method": "direct_payment"}
    
    else:
        # Other payment methods would be implemented here
        raise HTTPException(status_code=400, detail=f"Payment method {payment_method.method} not supported yet")

async def unlock_role_benefits(user_id: str, role: str, db: AsyncIOMotorDatabase):
    # Update user role
    await db.vision_users.update_one(
        {"_id": user_id},
        {"$set": {
            "role": role,
            "membership_active": True,
            "role_updated_at": datetime.utcnow(),
            "permissions_updated": True
        }}
    )
    
    # Add specific permissions based on role
    permissions = {
        "Vision Marshal": {
            "can_upload_content": True,
            "can_create_campaigns": True,
            "can_track_impact": True,
            "content_auto_approved": False
        },
        "Career Seeker": {
            "can_apply_jobs": True,
            "can_track_applications": True,
            "can_receive_alerts": True,
            "resume_builder_access": True
        },
        "Supporter": {
            "can_donate": True,
            "can_join_events": True,
            "can_receive_updates": True
        },
        "Donor": {
            "can_donate": True,
            "donation_tax_receipts": True,
            "impact_tracking": True,
            "premium_updates": True
        }
    }
    
    role_permissions = permissions.get(role, {})
    
    # Update user permissions
    await db.vision_users.update_one(
        {"_id": user_id},
        {"$set": {"role_permissions": role_permissions}}
    )
    
    # Create benefit activation record
    await db.benefit_activations.insert_one({
        "user_id": user_id,
        "role": role,
        "benefits": list(role_permissions.keys()),
        "activated_at": datetime.utcnow(),
        "activated_by": "system"
    })
    
    return role_permissions

async def process_role_payment(
    user_id: str, 
    amount: float, 
    payment_method: str, 
    role_name: str, 
    db,
    payment_details=None,
    transaction_id=None
):
    try:
        # Generate a transaction ID if one is not provided
        tx_id = transaction_id or f"TX-{str(uuid.uuid4())[:8]}"
        
        # For testing/development, simulate successful payment for all methods
        # In production, each method would connect to appropriate payment gateway
        
        # Handle wallet payment
        if payment_method == "wallet":
            # Create wallet document if it doesn't exist
            wallet = await db.user_wallets.find_one({"user_id": user_id})
            if not wallet:
                # For testing purposes, initialize with a sufficient balance
                await db.user_wallets.insert_one({
                    "user_id": user_id,
                    "balance": 10000,  # Start with ₹10,000 for testing
                    "created_at": datetime.now(),
                    "updated_at": datetime.now()
                })
                wallet = await db.user_wallets.find_one({"user_id": user_id})
            
            # Check if there's enough balance
            if wallet.get("balance", 0) < amount:
                # Add funds automatically for testing/development
                await db.user_wallets.update_one(
                    {"user_id": user_id},
                    {"$set": {"balance": 10000, "updated_at": datetime.now()}}
                )
                await db.transaction_history.insert_one({
                    "user_id": user_id,
                    "date": datetime.now(),
                    "balance_after": 10000 - amount,
                    "status": "completed",
                })

        # Handle direct payment options
        elif payment_method == "direct_payment":
            # Process direct payment logic
            await db.payments.insert_one({
                "user_id": user_id,
                "payment_id": tx_id,
                "amount": amount,
                "method": "direct_payment",
                "purpose": f"Role activation: {role_name}",
                "status": "completed",
                "date": datetime.now(),
                "details": payment_details
            })
            
            return {
                "success": True,
                "method": "direct_payment",
                "amount": amount,
                "transaction_id": tx_id,
                "message": "Payment processed successfully via direct payment"
            }
            
        # Handle bank transfers
        elif payment_method == "bank_transfer":
            # Process bank transfer logic
            await db.payments.insert_one({
                "user_id": user_id,
                "payment_id": tx_id,
                "amount": amount,
                "method": "bank_transfer",
                "purpose": f"Role activation: {role_name}",
                "status": "completed",
                "date": datetime.now(),
                "details": payment_details
            })
            
            return {
                "success": True,
                "method": "bank_transfer",
                "amount": amount,
                "transaction_id": tx_id,
                "message": "Payment processed successfully via bank transfer"
            }
            
        # Handle credit card payments
        elif payment_method == "credit_card":
            # Process credit card payment logic
            await db.payments.insert_one({
                "user_id": user_id,
                "payment_id": tx_id,
                "amount": amount,
                "method": "credit_card",
                "purpose": f"Role activation: {role_name}",
                "status": "completed",
                "date": datetime.now(),
                "card_info": {
                    "last4": payment_details.get("last4", "****") if payment_details else "****",
                    "brand": payment_details.get("brand", "Card") if payment_details else "Card",
                }
            })
            
            return {
                "success": True,
                "method": "credit_card",
                "amount": amount,
                "transaction_id": tx_id,
                "message": "Payment processed successfully via credit card"
            }
        else:
            return {
                "success": False,
                "message": f"Unsupported payment method: {payment_method}"
            }
    except Exception as e:
        return {
            "success": False,
            "message": f"Payment processing error: {str(e)}"
        }
