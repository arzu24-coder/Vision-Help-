from typing import List
from uuid import uuid4
from motor.motor_asyncio import AsyncIOMotorDatabase
from bson import ObjectId
from typing import List, Optional, Dict, Union, Any
from datetime import datetime
from app.database.models.safety_profile import SafetyProfileDB, SafetyTaskDB, SafetySOSDB
from app.database.schemas.safety_profile import SafetyProfileCreate, TaskCreate, SOSCreate

# Helper function to check if user is authorized to access safety data
async def check_safety_access(requesting_user_id: str, profile_id: str, requesting_user: dict, db: AsyncIOMotorDatabase) -> bool:
    # Admin email constant
    ADMIN_EMAIL = "arzumehreen050@gmail.com"
    
    # Get the profile
    profile = await db["safety_profiles"].find_one({"user_id": profile_id})
    if not profile:
        return False
    
    # Check access permissions
    # 1. Profile owner can always access their own profile
    if requesting_user_id == profile_id:
        return True
    
    # 2. Admin can access if admin_visibility is true
    if requesting_user.get("sub") == ADMIN_EMAIL and profile.get("admin_visibility", True):
        return True
    
    # 3. Family members can access if family_visibility is true and they're in family_members list
    if profile.get("family_visibility", True):
        # Check if user's email matches any family member email
        family_members = profile.get("family_members", [])
        user_email = requesting_user.get("sub")
        
        for member in family_members:
            if isinstance(member, dict) and member.get("email") == user_email:
                return True
    
    return False

# Function to convert email to user_id
async def get_user_id_from_email(email: str, db: AsyncIOMotorDatabase) -> Optional[str]:
    user = await db["vision_users"].find_one({"email": email})
    if user:
        return str(user["_id"])
    return None

# Function to process family members by looking up or creating users if needed
async def process_family_members(family_members: List[Dict], db: AsyncIOMotorDatabase) -> List[Dict]:
    processed_members = []
    
    for member in family_members:
        if isinstance(member, dict) and "email" in member:
            # Keep the original member data
            processed_member = member.copy()
            
            # Try to find the user by email
            user = await db["vision_users"].find_one({"email": member["email"]})
            
            if user:
                # Add user_id to the member data
                processed_member["user_id"] = str(user["_id"])
            else:
                # Create a basic user for this family member if they don't exist
                new_user = {
                    "_id": str(ObjectId()),
                    "email": member["email"],
                    "username": member["email"].split("@")[0],
                    "is_active": True,
                    "created_at": datetime.now(),
                    "role": "family_member"
                }
                await db["vision_users"].insert_one(new_user)
                
                # Add the new user_id to the member data
                processed_member["user_id"] = new_user["_id"]
            
            processed_members.append(processed_member)
    
    return processed_members

# In-memory "databases"
async def check_safety_access(user_id: str, profile_id: str, requesting_user: dict, db: AsyncIOMotorDatabase):
    # Admin email constant
    ADMIN_EMAIL = "arzumehreen050@gmail.com"
    
    # Get the profile
    profile = await db["safety_profiles"].find_one({"user_id": profile_id})
    if not profile:
        return False
    
    # Check access permissions
    # 1. Profile owner can always access their own profile
    if user_id == profile_id:
        return True
    
    # 2. Admin can access if admin_visibility is true
    if requesting_user.get("sub") == ADMIN_EMAIL and profile.get("admin_visibility", True):
        return True
    
    # 3. Family members can access if family_visibility is true and they're in family_members list
    if profile.get("family_visibility", True) and user_id in profile.get("family_members", []):
        return True
        
    return False

# -------- Safety Profile --------
async def create_profile(db: AsyncIOMotorDatabase, profile: SafetyProfileCreate) -> SafetyProfileDB:
    profile_dict = profile.dict()
    result = await db["safety_profiles"].insert_one(profile_dict)
    profile_dict["_id"] = result.inserted_id
    return SafetyProfileDB(**profile_dict)


async def get_profile(db: AsyncIOMotorDatabase, user_id: str) -> Optional[SafetyProfileDB]:
    data = await db["safety_profiles"].find_one({"user_id": user_id})
    return SafetyProfileDB(**data) if data else None


async def update_profile(db: AsyncIOMotorDatabase, user_id: str, update_data: dict) -> Optional[SafetyProfileDB]:
    await db["safety_profiles"].update_one({"user_id": user_id}, {"$set": update_data})
    data = await db["safety_profiles"].find_one({"user_id": user_id})
    return SafetyProfileDB(**data) if data else None


async def update_safety_profile(profile_id: str, update_data: dict, db: AsyncIOMotorDatabase):
    """
    Update a safety profile with proper handling of updated_at field
    """
    # Ensure we have an updated_at value
    if "updated_at" not in update_data:
        update_data["updated_at"] = datetime.now()
    
    # Try to find by ObjectId first
    try:
        profile_object_id = ObjectId(profile_id)
        result = await db["safety_profiles"].find_one_and_update(
            {"_id": profile_object_id},
            {"$set": update_data},
            return_document=True
        )
        if result:
            return result
    except:
        pass
    
    # If not found or invalid ObjectId, try by user_id
    result = await db["safety_profiles"].find_one_and_update(
        {"user_id": profile_id},
        {"$set": update_data},
        return_document=True
    )
    
    return result

# Add family member to a safety profile
async def add_family_member_to_profile(profile_id: str, family_member: Dict, db: AsyncIOMotorDatabase):
    # Process the family member to ensure it has a user_id
    processed_members = await process_family_members([family_member], db)
    
    if not processed_members:
        return None
    
    processed_member = processed_members[0]
    
    # Try to update the profile by ID first
    try:
        profile_object_id = ObjectId(profile_id)
        # Use addToSet to prevent duplicate entries
        result = await db["safety_profiles"].find_one_and_update(
            {"_id": profile_object_id},
            {
                "$addToSet": {"family_members": processed_member},
                "$set": {"updated_at": datetime.now()}
            },
            return_document=True
        )
        if result:
            return result
    except:
        pass
    
    # If not found or invalid ObjectId, try by user_id
    result = await db["safety_profiles"].find_one_and_update(
        {"user_id": profile_id},
        {
            "$addToSet": {"family_members": processed_member},
            "$set": {"updated_at": datetime.now()}
        },
        return_document=True
    )
    
    return result

# -------- Safety Task --------
async def create_task(db: AsyncIOMotorDatabase, user_id: str, task: TaskCreate) -> SafetyTaskDB:
    task_doc = {
        "user_id": user_id,
        "task_name": task.description,
        "geo_lat": task.geo_lat,
        "geo_lng": task.geo_lng,
        "status": "pending"
    }
    result = await db["safety_tasks"].insert_one(task_doc)
    task_doc["_id"] = result.inserted_id
    return SafetyTaskDB(**task_doc)


async def get_tasks(db: AsyncIOMotorDatabase, user_id: str) -> List[SafetyTaskDB]:
    cursor = db["safety_tasks"].find({"user_id": user_id})
    return [SafetyTaskDB(**doc) async for doc in cursor]


# -------- Safety SOS --------
async def trigger_sos(db: AsyncIOMotorDatabase, user_id: str, sos: SOSCreate) -> SafetySOSDB:
    sos_doc = {
        "user_id": user_id,
        "message": sos.message,
        "geo_lat": sos.geo_lat,
        "geo_lng": sos.geo_lng,
        "resolved": False
    }
    result = await db["safety_sos"].insert_one(sos_doc)
    sos_doc["_id"] = result.inserted_id

    # ⚠️ Notify family/admin
    print(f"🚨 SOS triggered by user {user_id}: {sos.message}")

    return SafetySOSDB(**sos_doc)


async def get_active_sos(db: AsyncIOMotorDatabase, user_id: str) -> List[SafetySOSDB]:
    cursor = db["safety_sos"].find({"user_id": user_id, "resolved": False})
    return [SafetySOSDB(**doc) async for doc in cursor]

async def update_task_status(task_id: str, status: str, user_id: str, db: AsyncIOMotorDatabase):
    """
    Update a task's status and set completion fields if needed
    """
    update_data = {"status": status}
    
    # Add completion data if task is being completed
    if status == "completed":
        completion_time = datetime.now()
        update_data.update({
            "completed_at": completion_time,
            "completed_by": user_id
        })
    
    # Update the task
    try:
        task_object_id = ObjectId(task_id)
        result = await db["safety_tasks"].find_one_and_update(
            {"_id": task_object_id},
            {"$set": update_data},
            return_document=True
        )
        return result
    except Exception as e:
        return None
