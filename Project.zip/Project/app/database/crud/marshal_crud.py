from motor.motor_asyncio import AsyncIOMotorDatabase
from typing import List
from app.database.schemas.marshal import StoryCreate
from bson import ObjectId
def serialize_doc(doc):
    doc["id"] = str(doc["_id"])
    del doc["_id"]
    return doc

async def save_story(db: AsyncIOMotorDatabase, story: StoryCreate):
    story_dict = story.dict() 
    result = await db["marshals"].insert_one(story_dict)
    return str(result.inserted_id)

# 1. Get All Stories (from marshals)
async def get_all_stories(db: AsyncIOMotorDatabase):
    stories = db["marshals"].find()
    return await stories.to_list(length=None)

# 2. Tag a Story (in marshals)
async def tag_story(db: AsyncIOMotorDatabase, story_id: str, tags: List[str]):
    try:
        result = await db["marshals"].update_one(
            {"_id": ObjectId(story_id)},
            {"$set": {"tags": tags}}
        )
        return result.modified_count
    except Exception as e:
        raise Exception(f"Failed to tag story: {e}")

# 3. Get Impact Report by Area (from marshals)
async def get_impact_report(db: AsyncIOMotorDatabase, area: str = None):
    query = {}
    if area:
        query["area"] = area

    stories = db["marshals"].find(query)
    return await stories.to_list(length=None)

async def save_badge(db, user_id: str, badge_data: dict):
    # Update marshal document by appending to "badges" list
    result = await db["marshals"].update_one(
        {"_id": ObjectId(user_id)},
        {"$push": {"badges": badge_data}},
        upsert=True  # Create doc if not exists
    )
    return result
