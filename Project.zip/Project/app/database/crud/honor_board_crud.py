from motor.motor_asyncio import AsyncIOMotorDatabase
from bson import ObjectId
from datetime import datetime
from app.database.schemas.honor_board import ContributionCreate
from app.utils.honor_utils import serialize_mongodb_doc
# ------------------ Honor Board ------------------

async def add_honor_entry(db: AsyncIOMotorDatabase, entry_data: dict):
    entry_data["created_at"] = datetime.utcnow()
    result = await db["honor_board"].insert_one(entry_data)
    return str(result.inserted_id)


async def get_honor_board(db: AsyncIOMotorDatabase, filters: dict):
    entries = db["honor_board"].find(filters).sort("score", -1)
    return [serialize_mongodb_doc(entry) async for entry in entries]


def generate_certificate_url(user_id: str, badge: str) -> str:
    return f"https://localhost:8000/certificates.yourapp.com/{user_id}_{badge}_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}.pdf"


async def generate_weekly_entries(db: AsyncIOMotorDatabase, week: str):
    contributions = await db["honor_board"].find({"week": week}).sort("score", -1).to_list(100)

    honors = []
    for i, contrib in enumerate(contributions[:10]):
        badge = (
            "gold" if i == 0 else
            "silver" if i == 1 else
            "bronze" if i == 2 else
            None
        )

        honor_doc = {
            "user_id": contrib["user_id"],
            "name": contrib.get("name", ""),
            "badge": badge,
            "score": contrib["score"],
            "week": week,
            "certificate_url": generate_certificate_url(contrib["user_id"], badge or "Participant"),
            "created_at": datetime.utcnow(),
            "source": "auto_generated"
        }
        honors.append(honor_doc)

    if honors:
        await db.honor_board.insert_many(honors)


# ------------------ Contributions ------------------

async def add_contribution(db: AsyncIOMotorDatabase, contribution: ContributionCreate):
    data = contribution.dict()
    
    # Handle user_id as ObjectId if needed
    if "user_id" in data:
        if isinstance(data["user_id"], ObjectId):
            data["user_id"] = str(data["user_id"])
        elif isinstance(data["user_id"], str) and ObjectId.is_valid(data["user_id"]):
            # Keep as string but remember we can convert to ObjectId if needed
            pass
    
    data["created_at"] = datetime.utcnow()
    result = await db["honor_board"].insert_one(data)
    return str(result.inserted_id)

import os
import aiosmtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

SMTP_HOST = "smtp.gmail.com"
SMTP_PORT = 587
SMTP_USER = "arzumehreen050@gmail.com"
SMTP_PASS = "cpus ctsa fdtm dmqs"

async def send_email_receipt(to_email: str, subject: str, html_body: str):
    try:
        msg = MIMEMultipart("alternative")
        msg["From"] = SMTP_USER
        msg["To"] = to_email
        msg["Subject"] = subject

        msg.attach(MIMEText(html_body, "html"))

        await aiosmtplib.send(
            msg,
            hostname=SMTP_HOST,
            port=SMTP_PORT,
            start_tls=True,
            username=SMTP_USER,
            password=SMTP_PASS,
        )
        print(f"✅ Receipt email sent to {to_email}")
    except Exception as e:
        print(f"❌ Failed to send email to {to_email}: {e}")
