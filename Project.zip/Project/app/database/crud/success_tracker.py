import uuid
from datetime import datetime, timedelta, timezone
import logging
from typing import Dict, Optional
from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorDatabase

logging.basicConfig(level=logging.INFO)

# ---- Sponsor Tier Logic ----
def get_sponsor_tier(total_contribution: float) -> str:
    if total_contribution >= 500000:
        return "Platinum Sponsor"
    elif total_contribution >= 100000:
        return "Gold Sponsor"
    elif total_contribution >= 50000:
        return "Silver Sponsor"
    elif total_contribution >= 10000:
        return "Bronze Sponsor"
    else:
        return "Contributor"

# ---- Progress Reports ----
def generate_progress_reports(projects, time_period: str) -> list:
    now = datetime.now(timezone.utc)
    periods = []

    # Time period setup
    if time_period == "monthly":
        for i in range(6):
            month = now.month - i
            year = now.year
            while month <= 0:
                month += 12
                year -= 1
            start = datetime(year, month, 1, tzinfo=timezone.utc)
            end = datetime(year, month + 1, 1, tzinfo=timezone.utc) if month < 12 else datetime(year + 1, 1, 1, tzinfo=timezone.utc)
            periods.append({"label": f"{year}-{month:02d}", "start": start, "end": end})

    elif time_period == "quarterly":
        current_quarter = ((now.month - 1) // 3) + 1
        for i in range(4):
            quarter = current_quarter - i
            year = now.year
            while quarter <= 0:
                quarter += 4
                year -= 1
            start = datetime(year, 3 * quarter - 2, 1, tzinfo=timezone.utc)
            end = datetime(year, 3 * quarter + 1, 1, tzinfo=timezone.utc) if quarter < 4 else datetime(year + 1, 1, 1, tzinfo=timezone.utc)
            periods.append({"label": f"Q{quarter} {year}", "start": start, "end": end})

    else:  # yearly
        for i in range(3):
            year = now.year - i
            periods.append({"label": str(year), "start": datetime(year, 1, 1, tzinfo=timezone.utc), "end": datetime(year + 1, 1, 1, tzinfo=timezone.utc)})

    reports = []
    for period in periods:
        period_projects = [
            p for p in projects
            if (p.get("start_date") and p.get("start_date") < period["end"])
            and (not p.get("end_date") or p.get("end_date") > period["start"])
        ]
        total_investment = sum(p.get("budget_utilized", 0) for p in period_projects)
        total_beneficiaries = sum(p.get("beneficiaries", 0) for p in period_projects)
        avg_completion = sum(p.get("completion_percentage", 0) for p in period_projects) / len(period_projects) if period_projects else 0

        reports.append({
            "period": period["label"],
            "projects": len(period_projects),
            "investment": f"₹{total_investment:,.2f}",
            "beneficiaries": total_beneficiaries,
            "avg_completion": f"{avg_completion:.1f}%"
        })
    return reports

# ---- Heatmap Aggregation ----
def classify_zone(issues: int, resolved: int) -> str:
    if issues == 0:
        return "low"
    ratio = resolved / issues if issues else 0
    if issues > 50 and ratio < 0.5:
        return "critical"
    elif issues > 20:
        return "medium"
    else:
        return "low"

def resolve_range(time_period: str):
    end_date = datetime.now(timezone.utc)
    if time_period == "day":
        start_date = end_date - timedelta(days=1)
    elif time_period == "week":
        start_date = end_date - timedelta(weeks=1)
    elif time_period == "month":
        start_date = end_date - timedelta(days=30)
    elif time_period == "year":
        start_date = end_date - timedelta(days=365)
    else:
        start_date = datetime(2020, 1, 1, tzinfo=timezone.utc)
    return start_date, end_date

async def aggregate_regions_data(db: AsyncIOMotorDatabase, start_date, end_date, region=None):
    pipeline = [
        {"$match": {"created_at": {"$gte": start_date, "$lte": end_date}}},
        {"$group": {
            "_id": "$region",
            "total_projects": {"$sum": 1},
            "active_projects": {"$sum": {"$cond": [{"$eq": ["$status", "active"]}, 1, 0]}},
            "total_budget": {"$sum": "$budget"},
            "total_utilized": {"$sum": "$budget_utilized"},
            "total_beneficiaries": {"$sum": "$beneficiaries"}
        }},
        {"$project": {
            "region": "$_id",
            "metrics": {
                "total_projects": "$total_projects",
                "active_projects": "$active_projects",
                "total_budget": "$total_budget",
                "total_utilized": "$total_utilized",
                "total_beneficiaries": "$total_beneficiaries"
            },
            "_id": 0
        }}
    ]

    if region:
        pipeline[0]["$match"]["region"] = region

    results = await db.projects.aggregate(pipeline).to_list(length=100)

    for region_data in results:
        metrics = region_data["metrics"]

        completion_rate = (metrics["total_utilized"] / metrics["total_budget"]) * 100 if metrics["total_budget"] > 0 else 0
        metrics["completion_rate"] = f"{completion_rate:.1f}%"

        metrics["total_budget_formatted"] = f"₹{metrics['total_budget']:,.2f}"
        metrics["total_utilized_formatted"] = f"₹{metrics['total_utilized']:,.2f}"

        if metrics["total_beneficiaries"] > 0:
            cost_per_beneficiary = metrics["total_utilized"] / metrics["total_beneficiaries"]
        else:
            cost_per_beneficiary = 0
        metrics["cost_per_beneficiary"] = f"₹{cost_per_beneficiary:,.2f}"

    return results

# ---- Trend Data ----
async def get_trend_data(db: AsyncIOMotorDatabase, start_date=None, end_date=None, region=None):
    """
    Generate comprehensive trend data for projects and activities over time.
    Aggregates data from multiple collections to provide a complete picture.
    """
    # Default date range is last 3 years if not specified
    if not end_date:
        end_date = datetime.utcnow()
    if not start_date:
        start_date = end_date - timedelta(days=365*3)  # 3 years of data
    
    # Determine appropriate interval based on date range
    days_diff = (end_date - start_date).days
    if days_diff <= 31:
        interval = "day"
        date_format = "%Y-%m-%d"
        step_days = 1
    elif days_diff <= 180:
        interval = "week"
        date_format = "%Y-W%U"  # Year-Week format
        step_days = 7
    else:
        interval = "month"
        date_format = "%Y-%m"
        step_days = 30
    
    # Build base query
    query = {"created_at": {"$gte": start_date, "$lte": end_date}}
    if region and region != "Global" and region != "All Regions":
        query["region"] = region
    
    # Step 1: Get project trend data
    project_pipeline = [
        {"$match": query},
        {"$group": {
            "_id": {"$dateToString": {"format": date_format, "date": "$created_at"}},
            "beneficiaries": {"$sum": "$beneficiaries"},
            "budget": {"$sum": "$budget"},
            "utilized": {"$sum": "$budget_utilized"},
            "project_count": {"$sum": 1}
        }},
        {"$sort": {"_id": 1}}
    ]
    
    # Try both projects and career collections
    project_results = []
    try:
        project_results = await db.projects.aggregate(project_pipeline).to_list(length=None)
    except Exception as e:
        logging.warning(f"Error getting project data from projects collection: {str(e)}")
    
    # If no results from projects collection, try career collection
    if not project_results:
        try:
            project_results = await db.career.aggregate(project_pipeline).to_list(length=None)
        except Exception as e:
            logging.warning(f"Error getting project data from career collection: {str(e)}")
            # Initialize with empty list if both fail
            project_results = []
    
    # Step 2: Get activity trend data (user engagement)
    activity_results = []
    
    # Try multiple collections that might contain activity data
    activity_collections = ["activities", "user_activities"]
    
    for collection_name in activity_collections:
        try:
            activity_query = {"timestamp": {"$gte": start_date, "$lte": end_date}}
            activity_pipeline = [
                {"$match": activity_query},
                {"$group": {
                    "_id": {"$dateToString": {"format": date_format, "date": "$timestamp"}},
                    "activity_count": {"$sum": 1}
                }},
                {"$sort": {"_id": 1}}
            ]
            
            collection_results = await db[collection_name].aggregate(activity_pipeline).to_list(length=None)
            activity_results.extend(collection_results)
        except Exception as e:
            logging.warning(f"Error getting activity data from {collection_name}: {str(e)}")
    
    # Combine results by date if we have duplicates
    activity_by_date = {}
    for entry in activity_results:
        date = entry["_id"]
        if date in activity_by_date:
            activity_by_date[date]["activity_count"] += entry["activity_count"]
        else:
            activity_by_date[date] = entry
    
    activity_results = list(activity_by_date.values())
    
    # Step 3: Get user activity (marshal stories, responses)
    story_query = {"reported_at": {"$gte": start_date, "$lte": end_date}}
    if region and region != "Global" and region != "All Regions":
        story_query["region"] = region
        
    story_pipeline = [
        {"$match": story_query},
        {"$group": {
            "_id": {"$dateToString": {"format": date_format, "date": "$reported_at"}},
            "story_count": {"$sum": 1}
        }},
        {"$sort": {"_id": 1}}
    ]
    
    story_results = await db.marshals.aggregate(story_pipeline).to_list(length=None)
    
    # Step 4: Get response data
    response_results = []
    
    # Try to get response data from both story_responses and responses collections
    response_collections = ["story_responses", "responses"]
    
    for collection_name in response_collections:
        try:
            response_pipeline = [
                {"$match": {"created_at": {"$gte": start_date, "$lte": end_date}}},
                {"$group": {
                    "_id": {"$dateToString": {"format": date_format, "date": "$created_at"}},
                    "response_count": {"$sum": 1}
                }},
                {"$sort": {"_id": 1}}
            ]
            
            collection_results = await db[collection_name].aggregate(response_pipeline).to_list(length=None)
            response_results.extend(collection_results)
        except Exception as e:
            logging.warning(f"Error getting response data from {collection_name}: {str(e)}")
    
    # Combine results by date if we have duplicates
    response_by_date = {}
    for entry in response_results:
        date = entry["_id"]
        if date in response_by_date:
            response_by_date[date]["response_count"] += entry["response_count"]
        else:
            response_by_date[date] = entry
    
    response_results = list(response_by_date.values())
    
    # Generate complete date labels based on interval
    labels = []
    current = start_date
    while current <= end_date:
        if interval == "day":
            label = current.strftime("%Y-%m-%d")
            current += timedelta(days=1)
        elif interval == "week":
            label = current.strftime("%Y-W%U")
            current += timedelta(days=7)
        else:  # month
            label = current.strftime("%Y-%m")
            current = (current.replace(day=1) + timedelta(days=32)).replace(day=1)  # Next month
        labels.append(label)
    
    # Create result dictionary with all dates and initialize with zeros
    result_dict = {
        label: {
            "beneficiaries": 0, 
            "budget": 0, 
            "utilized": 0,
            "project_count": 0,
            "activity_count": 0,
            "story_count": 0,
            "response_count": 0
        } 
        for label in labels
    }
    
    # Fill in project data
    for entry in project_results:
        label = entry["_id"]
        if label in result_dict:
            result_dict[label]["beneficiaries"] = entry.get("beneficiaries", 0)
            result_dict[label]["budget"] = entry.get("budget", 0)
            result_dict[label]["utilized"] = entry.get("utilized", 0)
            result_dict[label]["project_count"] = entry.get("project_count", 0)
    
    # Fill in activity data
    for entry in activity_results:
        label = entry["_id"]
        if label in result_dict:
            result_dict[label]["activity_count"] = entry.get("activity_count", 0)
    
    # Fill in story data
    for entry in story_results:
        label = entry["_id"]
        if label in result_dict:
            result_dict[label]["story_count"] = entry.get("story_count", 0)
            
    # Fill in response data
    for entry in response_results:
        label = entry["_id"]
        if label in result_dict:
            result_dict[label]["response_count"] = entry.get("response_count", 0)
    
    # Calculate cumulative values for certain metrics
    # This ensures trends grow over time rather than just showing zero for periods with no new data
    cumulative_metrics = ["beneficiaries", "budget", "utilized"]
    
    for metric in cumulative_metrics:
        running_total = 0
        for label in labels:
            running_total += result_dict[label][metric]
            result_dict[label][metric] = running_total
    
    # Format for response
    return {
        "interval": interval,
        "labels": labels,
        "beneficiaries": [result_dict[label]["beneficiaries"] for label in labels],
        "budget": [result_dict[label]["budget"] for label in labels],
        "utilized": [result_dict[label]["utilized"] for label in labels],
        "project_count": [result_dict[label]["project_count"] for label in labels],
        "activity_count": [result_dict[label]["activity_count"] for label in labels],
        "story_count": [result_dict[label]["story_count"] for label in labels],
        "response_count": [result_dict[label]["response_count"] for label in labels]
    }

async def get_real_contributions(user_id=None, user_role=None, db=None):
    """Get real contributions data, optionally filtered by user_id"""
    
    contributions = []
    query = {}
    
    # If user_id is provided, use it to filter
    if user_id:
        # Try to filter by user_id or email
        query = {"$or": [{"user_id": user_id}]}
        
    try:
        # Get a sample of contributions
        cursor = db.contributions.find(query).limit(5)
        async for doc in cursor:
            # Ensure _id is converted to string
            if "_id" in doc and doc["_id"]:
                doc["_id"] = str(doc["_id"])
            contributions.append(doc)
        
        # If no contributions found, get general sample
        if not contributions:
            cursor = db.contributions.find({}).limit(5)
            async for doc in cursor:
                if "_id" in doc and doc["_id"]:
                    doc["_id"] = str(doc["_id"])
                # Mark these as examples
                doc["is_example"] = True
                contributions.append(doc)
    except Exception as e:
        # Handle any database errors
        print(f"Error getting contributions: {str(e)}")
        # Return some default contributions
        contributions = [
            {
                "amount": 1000,
                "currency": "INR",
                "project_id": "default_project_1",
                "date": "2025-01-15",
                "is_example": True
            },
            {
                "amount": 2000,
                "currency": "INR",
                "project_id": "default_project_2",
                "date": "2025-02-20",
                "is_example": True
            }
        ]
    
    return contributions