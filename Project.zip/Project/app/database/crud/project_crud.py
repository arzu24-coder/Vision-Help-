from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorDatabase
import logging

logger = logging.getLogger(__name__)

async def get_projects(
    db: AsyncIOMotorDatabase,
    filter_query: Dict = None,
    skip: int = 0,
    limit: int = 100
) -> List[Dict]:
    """
    Get projects with optional filtering, pagination and sorting
    """
    query = filter_query or {}
    
    try:
        cursor = db.projects.find(query).skip(skip).limit(limit)
        projects = await cursor.to_list(length=limit)
        return projects
    except Exception as e:
        logger.error(f"Error fetching projects: {str(e)}")
        return []

async def get_project_by_id(db: AsyncIOMotorDatabase, project_id: str) -> Optional[Dict]:
    """
    Get a single project by ID
    """
    try:
        if ObjectId.is_valid(project_id):
            project = await db.projects.find_one({"_id": ObjectId(project_id)})
        else:
            project = await db.projects.find_one({"project_id": project_id})
        
        return project
    except Exception as e:
        logger.error(f"Error fetching project {project_id}: {str(e)}")
        return None

async def create_project(db: AsyncIOMotorDatabase, project_data: Dict) -> Optional[str]:
    """
    Create a new project
    """
    try:
        # Ensure created_at and updated_at are set
        now = datetime.utcnow()
        if "created_at" not in project_data:
            project_data["created_at"] = now
        if "updated_at" not in project_data:
            project_data["updated_at"] = now
            
        # Set default values for metrics if not provided
        if "beneficiaries" not in project_data:
            project_data["beneficiaries"] = 0
        if "budget" not in project_data:
            project_data["budget"] = 0
        if "budget_utilized" not in project_data:
            project_data["budget_utilized"] = 0
            
        result = await db.projects.insert_one(project_data)
        return str(result.inserted_id)
    except Exception as e:
        logger.error(f"Error creating project: {str(e)}")
        return None

async def update_project(db: AsyncIOMotorDatabase, project_id: str, update_data: Dict) -> bool:
    """
    Update an existing project
    """
    try:
        # Set updated_at timestamp
        update_data["updated_at"] = datetime.utcnow()
        
        if ObjectId.is_valid(project_id):
            result = await db.projects.update_one(
                {"_id": ObjectId(project_id)},
                {"$set": update_data}
            )
        else:
            result = await db.projects.update_one(
                {"project_id": project_id},
                {"$set": update_data}
            )
            
        return result.modified_count > 0
    except Exception as e:
        logger.error(f"Error updating project {project_id}: {str(e)}")
        return False

async def delete_project(db: AsyncIOMotorDatabase, project_id: str) -> bool:
    """
    Delete a project
    """
    try:
        if ObjectId.is_valid(project_id):
            result = await db.projects.delete_one({"_id": ObjectId(project_id)})
        else:
            result = await db.projects.delete_one({"project_id": project_id})
            
        return result.deleted_count > 0
    except Exception as e:
        logger.error(f"Error deleting project {project_id}: {str(e)}")
        return False

async def get_project_metrics(db: AsyncIOMotorDatabase, start_date=None, end_date=None, region=None):
    """
    Get aggregated project metrics with optional date range and region filtering
    """
    try:
        # Default to last 30 days if no dates provided
        if not end_date:
            end_date = datetime.utcnow()
        if not start_date:
            start_date = end_date - timedelta(days=30)
            
        # Build query
        query = {"created_at": {"$gte": start_date, "$lte": end_date}}
        if region and region != "Global" and region != "All Regions":
            query["region"] = region
            
        # Count projects by status
        pipeline = [
            {"$match": query},
            {"$group": {
                "_id": "$status",
                "count": {"$sum": 1},
                "total_budget": {"$sum": "$budget"},
                "total_utilized": {"$sum": "$budget_utilized"},
                "total_beneficiaries": {"$sum": "$beneficiaries"}
            }}
        ]
        
        status_results = await db.projects.aggregate(pipeline).to_list(length=None)
        
        # Count projects by region
        region_pipeline = [
            {"$match": {"created_at": {"$gte": start_date, "$lte": end_date}}},
            {"$group": {
                "_id": "$region",
                "count": {"$sum": 1},
                "total_budget": {"$sum": "$budget"},
                "total_utilized": {"$sum": "$budget_utilized"},
                "total_beneficiaries": {"$sum": "$beneficiaries"}
            }}
        ]
        
        region_results = await db.projects.aggregate(region_pipeline).to_list(length=None)
        
        # Get overall totals
        total_projects = await db.projects.count_documents(query)
        
        overall_pipeline = [
            {"$match": query},
            {"$group": {
                "_id": None,
                "total_budget": {"$sum": "$budget"},
                "total_utilized": {"$sum": "$budget_utilized"},
                "total_beneficiaries": {"$sum": "$beneficiaries"}
            }}
        ]
        
        overall_results = await db.projects.aggregate(overall_pipeline).to_list(length=1)
        overall = overall_results[0] if overall_results else {
            "total_budget": 0,
            "total_utilized": 0,
            "total_beneficiaries": 0
        }
        
        # Format results
        status_metrics = {
            item["_id"]: {
                "count": item["count"],
                "budget": item["total_budget"],
                "utilized": item["total_utilized"],
                "beneficiaries": item["total_beneficiaries"]
            } for item in status_results
        }
        
        region_metrics = {
            item["_id"] or "Unknown": {
                "count": item["count"],
                "budget": item["total_budget"],
                "utilized": item["total_utilized"],
                "beneficiaries": item["total_beneficiaries"]
            } for item in region_results
        }
        
        return {
            "total_projects": total_projects,
            "total_budget": overall.get("total_budget", 0),
            "total_utilized": overall.get("total_utilized", 0),
            "total_beneficiaries": overall.get("total_beneficiaries", 0),
            "by_status": status_metrics,
            "by_region": region_metrics
        }
    except Exception as e:
        logger.error(f"Error getting project metrics: {str(e)}")
        return {
            "total_projects": 0,
            "total_budget": 0,
            "total_utilized": 0,
            "total_beneficiaries": 0,
            "by_status": {},
            "by_region": {}
        }
