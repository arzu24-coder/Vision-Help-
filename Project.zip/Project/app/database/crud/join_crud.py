from motor.motor_asyncio import AsyncIOMotorDatabase
from bson import ObjectId
from fastapi import HTTPException, Depends, Header
from datetime import datetime, timedelta
from typing import Optional

# Helper to serialize MongoDB ObjectId
def serialize_user(user):
    user["id"] = str(user["_id"])
    del user["_id"]
    return user

# Create a new Vision user
async def create_vision_user(db: AsyncIOMotorDatabase, user_data: dict):
    result = await db["vision_users"].insert_one(user_data)
    return str(result.inserted_id)

# Get user by ID
async def get_user_by_id(db: AsyncIOMotorDatabase, user_id: str) -> Optional[dict]:
    user = await db["vision_users"].find_one({"_id": ObjectId(user_id)})
    return serialize_user(user) if user else None

# Get user by email
async def get_user_by_email(db: AsyncIOMotorDatabase, email: str) -> Optional[dict]:
    user = await db["vision_users"].find_one({"email": email})
    return serialize_user(user) if user else None

# Get user by vision_id
async def get_user_by_vision_id(db: AsyncIOMotorDatabase, vision_id: str) -> Optional[dict]:
    user = await db["vision_users"].find_one({"vision_id": vision_id})
    return serialize_user(user) if user else None

# Update user's QR code (used in your latest question)
async def update_qr_code(db: AsyncIOMotorDatabase, user_id: str, qr_code_base64: str):
    result = await db["vision_users"].update_one(
        {"_id": ObjectId(user_id)},
        {"$set": {"qr_code": qr_code_base64}}
    )
    return result.modified_count

# Update user's role or dashboard access
async def update_user_role_or_access(db: AsyncIOMotorDatabase, user_id: str, updates: dict):
    result = await db["vision_users"].update_one(
        {"_id": ObjectId(user_id)},
        {"$set": updates}
    )
    return result.modified_count

# Delete user by ID
async def delete_user(db: AsyncIOMotorDatabase, user_id: str):
    result = await db["vision_users"].delete_one({"_id": ObjectId(user_id)})
    return result.deleted_count

# List all Vision users (optional utility)
async def list_vision_users(db: AsyncIOMotorDatabase):
    users = db["vision_users"].find()
    return [serialize_user(user) async for user in users]

async def get_efficient_dashboard_data(user_id: str, db: AsyncIOMotorDatabase):
    try:
        # 1️⃣ Aggregate user's related counts (e.g., tasks, insights, etc.)
        pipeline = [
            {"$match": {"user_id": user_id}},
            {
                "$group": {
                    "_id": None,
                    "total_tasks": {"$sum": {"$cond": [{"$eq": ["$type", "task"]}, 1, 0]}},
                    "completed_tasks": {"$sum": {"$cond": [{"$and": [
                        {"$eq": ["$type", "task"]},
                        {"$eq": ["$status", "completed"]}
                    ]}, 1, 0]}},
                    "total_insights": {"$sum": {"$cond": [{"$eq": ["$type", "insight"]}, 1, 0]}},
                }
            }
        ]
        counts_cursor = db.dashboard_items.aggregate(pipeline)
        counts_data = await counts_cursor.to_list(length=1)
        counts_summary = counts_data[0] if counts_data else {
            "total_tasks": 0,
            "completed_tasks": 0,
            "total_insights": 0
        }

        # 2️⃣ Fetch recent activities (last 7 days)
        recent_date = datetime.utcnow() - timedelta(days=7)
        recent_activities_cursor = db.dashboard_items.find(
            {"user_id": user_id, "created_at": {"$gte": recent_date}},
            {"_id": 0, "title": 1, "type": 1, "created_at": 1}
        ).sort("created_at", -1).limit(10)
        recent_activities = await recent_activities_cursor.to_list(length=10)

        # 3️⃣ Combine into one response
        dashboard_data = {
            "summary": counts_summary,
            "recent_activities": recent_activities
        }
        return {"success": True, "dashboard": dashboard_data}

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Dashboard data fetch failed: {str(e)}")