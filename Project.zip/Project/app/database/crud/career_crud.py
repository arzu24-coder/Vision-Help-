from motor.motor_asyncio import AsyncIOMotorDatabase
from bson import ObjectId
from typing import Optional


# Helper to serialize MongoDB ObjectId
def serialize_doc(doc):
    doc["id"] = str(doc["_id"])
    del doc["_id"]
    return doc

# ---------------- USERS ----------------

async def get_user_by_email(db: AsyncIOMotorDatabase, email: str) -> Optional[dict]:
    user = await db["career"].find_one({"email": email})
    return serialize_doc(user) if user else None

async def get_user_by_id(db: AsyncIOMotorDatabase, user_id: str) -> Optional[dict]:
    user = await db["career"].find_one({"_id": ObjectId(user_id)})
    return serialize_doc(user) if user else None

async def create_user(db: AsyncIOMotorDatabase, user_data: dict):
    result = await db["career"].insert_one(user_data)
    return str(result.inserted_id)

# ---------------- PROJECTS ----------------

async def create_project(db: AsyncIOMotorDatabase, project_data: dict):
    result = await db["career"].insert_one(project_data)
    return str(result.inserted_id)

async def create_volunteer_project(db: AsyncIOMotorDatabase, project_data: dict):
    result = await db["career"].insert_one(project_data)
    return str(result.inserted_id)

# ---------------- JOBS ----------------

async def post_job(db: AsyncIOMotorDatabase, job_data: dict):
    result = await db["career"].insert_one(job_data)  # Stored in `career_users`
    return str(result.inserted_id)

# ---------------- RESUME UPLOAD ----------------

async def save_resume(db: AsyncIOMotorDatabase, resume_data: dict):
    result = await db["career"].insert_one(resume_data)  # Stored in `career_users`
    return str(result.inserted_id)

# ---------------- APPLICATIONS ----------------

async def apply_for_job(db: AsyncIOMotorDatabase, application_data: dict):
    result = await db["career"].insert_one(application_data)
    return str(result.inserted_id)

# ---------------- RATINGS ----------------

async def rate_job(db: AsyncIOMotorDatabase, rating_data: dict):
    result = await db["career"].insert_one(rating_data)
    return str(result.inserted_id)

# ---------------- QUERIES ----------------

async def list_jobs(db: AsyncIOMotorDatabase):
    jobs = db["career"].find({"type": "job"})
    return [serialize_doc(job) async for job in jobs]

async def list_resumes(db: AsyncIOMotorDatabase):
    resumes = db["career"].find({"type": "resume"})
    return [serialize_doc(resume) async for resume in resumes]


def project_helper(project) -> dict:
    from datetime import date
    
    # Helper function to extract date from datetime or provide default
    def extract_date(date_value):
        if date_value is None:
            return date.today()  # Default to today's date
        if hasattr(date_value, 'date'):  # It's a datetime object
            return date_value.date()
        if isinstance(date_value, date):  # It's already a date object
            return date_value
        return date.today()  # Fallback to today
    
    return {
        "id": str(project["_id"]),
        "title": project.get("title", ""),
        "description": project.get("description", ""),
        "location": project.get("location", ""),
        "start_date": extract_date(project.get("start_date")),
        "end_date": extract_date(project.get("end_date")),
        "volunteers_needed": project.get("volunteers_needed", 0),
        "volunteers_joined": project.get("volunteers_joined", 0),
        "skills_required": project.get("skills_required", []),
        "category": project.get("category", ""),
        "status": project.get("status", "open"),
        "project_link": f"https://yourdomain.com/projects/{str(project['_id'])}"
    }
