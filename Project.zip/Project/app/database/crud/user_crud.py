from motor.motor_asyncio import AsyncIOMotorDatabase
from app.database.schemas.users import UserCreate
from bson import ObjectId

async def get_user_by_email(db: AsyncIOMotorDatabase, email: str):
    result = await db["user"].find_one({"email": email})  # Changed from "users" to "user"
    return result

async def get_user_by_id(db: AsyncIOMotorDatabase, user_id: str):
    return await db["user"].find_one({"_id": ObjectId(user_id)})  # Changed from "users" to "user"

async def create_user(db: AsyncIOMotorDatabase, user: UserCreate, hashed_pw: str):
    user_dict = user.dict()
    user_dict["password"] = hashed_pw
    user_dict["is_active"] = True
    result = await db["user"].insert_one(user_dict)  # Changed from "users" to "user"
    new_user = await db["user"].find_one({"_id": result.inserted_id})  # Changed from "users" to "user"
    return new_user

async def update_user(db: AsyncIOMotorDatabase, user_id: str, update_data: dict):
    await db["user"].update_one({"_id": ObjectId(user_id)}, {"$set": update_data})  # Changed from "users" to "user"
    return await get_user_by_id(db, user_id)

async def delete_user(db: AsyncIOMotorDatabase, user_id: str):
    return await db["user"].delete_one({"_id": ObjectId(user_id)})  # Changed from "users" to "user"
