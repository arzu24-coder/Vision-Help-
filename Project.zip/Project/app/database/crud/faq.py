from motor.motor_asyncio import AsyncIOMotorDatabase
from difflib import SequenceMatcher
from typing import Dict, Any, List
from datetime import datetime
import logging
from fastapi import APIRouter, Depends, HTTPException, Query, Body, BackgroundTasks
from fastapi.concurrency import run_in_threadpool
from app.database.__init__ import get_database
from app.auth.deps import get_current_user, is_admin
from typing import Optional, List, Dict, Any
from bson import ObjectId
from app.utils.faq_utils import (
    OPENAI_API_KEY, OPENAI_PY_AVAILABLE, OPENAI_CHAT_MODEL, OPENAI_EMBEDDING_MODEL, _cosine_similarity, _normalize_cosine_to_01, calculate_similarity_local
)
from datetime import datetime 
import logging
import openai

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

async def get_embeddings_openai(texts: List[str]) -> List[List[float]]:
    if not OPENAI_API_KEY or not OPENAI_PY_AVAILABLE:
        raise RuntimeError("OpenAI not configured/installed")

    def blocking_call():
        resp = openai.Embedding.create(model=OPENAI_EMBEDDING_MODEL, input=texts)
        return resp

    resp = await run_in_threadpool(blocking_call)
    embeddings = [item["embedding"] for item in resp["data"]]
    return embeddings

async def calculate_similarity(a: str, b: str, faq_embedding: Optional[List[float]] = None) -> float:
    # If faq_embedding provided and OpenAI available, compute query embedding and cosine
    if faq_embedding and OPENAI_API_KEY and OPENAI_PY_AVAILABLE:
        try:
            query_emb = (await get_embeddings_openai([a]))[0]
            cos = _cosine_similarity(query_emb, faq_embedding)
            return _normalize_cosine_to_01(cos)
        except Exception as e:
            logger.warning("Embedding similarity failed, falling back to local similarity: %s", e)
            return calculate_similarity_local(a, b)
    # If OpenAI available but no precomputed faq_embedding: compute both embeddings
    if OPENAI_API_KEY and OPENAI_PY_AVAILABLE:
        try:
            emb_a, emb_b = await get_embeddings_openai([a, b])
            cos = _cosine_similarity(emb_a, emb_b)
            return _normalize_cosine_to_01(cos)
        except Exception as e:
            logger.warning("OpenAI embedding on-the-fly failed, falling back: %s", e)
            return calculate_similarity_local(a, b)
    # Local fallback
    return calculate_similarity_local(a, b)

async def call_ai_service(query: str, user_id: Optional[str] = None) -> Dict[str, Any]:
    """
    Call AI service to generate answer. Returns safe default if service fails.
    """
    try:
        if OPENAI_API_KEY and OPENAI_PY_AVAILABLE:
            def blocking_call():
                return openai.ChatCompletion.create(
                    model=OPENAI_CHAT_MODEL,
                    messages=[
                        {"role": "system", "content": "You are a helpful support assistant for Vision Help Welfare Foundation. Keep answers concise and provide steps and links when possible."},
                        {"role": "user", "content": query}
                    ],
                    max_tokens=450,
                    temperature=0.2,
                )
            resp = await run_in_threadpool(blocking_call)
            ai_answer = resp["choices"][0]["message"]["content"].strip()
            # We don't have a reliable confidence score from the model; set a reasonable default for UI
            return {"answer": ai_answer, "confidence": 0.5, "suggested_category": None}
    except Exception as e:
        logger.error(f"Error calling AI service: {str(e)}")
        # Return a safe default response
        return {
            "answer": "I don't have enough information to answer that question accurately.",
            "confidence": 0.3,
            "suggested_category": "General" 
        }

async def store_ai_suggestion(db, query: str, answer: str, category: str = "General", user_id: Optional[str] = None) -> None:
    """
    Store AI suggestion with error handling
    """
    try:
        # Don't store empty answers
        if not answer or not isinstance(answer, str):
            return
            
        # Set some suggestions as reviewed automatically (20% chance)
        import random
        is_reviewed = random.random() < 0.2
        
        suggestion = {
            "query": query,
            "answer": answer,
            "suggested_category": category or "General",
            "user_id": user_id,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
            "reviewed": is_reviewed,  # Some suggestions are automatically reviewed
            "source": "ai"
        }
        await db.faq_suggestions.insert_one(suggestion)
    except Exception as e:
        logger.error(f"Failed to store AI suggestion: {str(e)}")
        # This is a background task, so we just log errors rather than propagating them