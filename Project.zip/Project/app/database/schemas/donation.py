from pydantic import BaseModel, Field, EmailStr, HttpUrl
from pydantic import BaseModel, EmailStr, constr, condecimal
from typing import Optional, Literal, List
from datetime import datetime

# ---------- Campaign ----------
class CampaignCreate(BaseModel):
    title: str
    description: str
    goal_amount: float = Field(gt=0, alias="goal")
    category: str
    location: str
    duration: int
    proof_video: Optional[str] = None
    proof_image: Optional[str] = None

class CampaignResponse(BaseModel):
    id: str
    title: str
    description: str
    goal_amount: float
    category: str
    location: str
    duration: int
    collected_amount: float
    verified: bool
    created_at: datetime
    updated_at: datetime
    end_date: datetime
    proof_image: Optional[str] = None
    proof_video: Optional[str] = None

# ---------- Donations ----------
PaymentProvider = Literal["razorpay", "stripe"]

class DirectDonateRequest(BaseModel):
    donor_name: str
    donor_email: str
    donor_phone: Optional[str] = None
    amount: int # INR like 500.00


class DonateRequestEnroll(BaseModel):
    full_name: str
    email: str
    phone: Optional[str] = None
    amount: int # INR like 500.00

class DonationModel(BaseModel):
    id: Optional[str] = None  # Remove alias, make optional
    donor_name: str
    donor_email: str
    donor_phone: Optional[str] = None
    amount: int
    currency: str = "INR"
    campaign_id: str
    provider: str
    status: str = "created"
    provider_order_id: Optional[str] = None
    payment_id: Optional[str] = None
    created_at: Optional[datetime] = Field(default_factory=datetime.utcnow)
    updated_at: Optional[datetime] = Field(default_factory=datetime.utcnow)

    class Config:
        json_schema_extra = {
            "example": {
                "donor_name": "Arzu Mehreen",
                "donor_email": "arzu@example.com",
                "donor_phone": "9876543210",
                "amount": 500,
                "currency": "INR",
                "campaign_id": "64f7c8f5a2b3d5c8e4f1d2a1",
                "provider": "razorpay",
                "status": "created"
            }
        }
        allow_population_by_field_name = True


class DonationModelEnroll(BaseModel):
    id: Optional[str] = None  # Remove alias, make optional
    full_name: str
    email: str
    phone: Optional[str] = None
    amount: int
    currency: str = "INR"
    campaign_id: str
    provider: str
    status: str = "created"
    provider_order_id: Optional[str] = None
    payment_id: Optional[str] = None
    created_at: Optional[datetime] = Field(default_factory=datetime.utcnow)
    updated_at: Optional[datetime] = Field(default_factory=datetime.utcnow)

    class Config:
        json_schema_extra = {
            "example": {
                "donor_name": "Arzu Mehreen",
                "donor_email": "arzu@example.com",
                "donor_phone": "9876543210",
                "amount": 500,
                "currency": "INR",
                "campaign_id": "64f7c8f5a2b3d5c8e4f1d2a1",
                "provider": "razorpay",
                "status": "created"
            }
        }
        allow_population_by_field_name = True
# -------------------------
# Donation Init Request
# -------------------------
class DonationInit(BaseModel):
    donor_name: str
    donor_email: str
    donor_phone: Optional[str] = None  # <-- Add this line
    amount: int   # in INR paise (100 = 1 INR)
    campaign_id: str  # <-- Add this line
    currency: str = "INR"  # <-- Add this line
    provider: str  # <-- Add this line

    class Config:
        json_schema_extra = {
            "example": {
                "donor_name": "Arzu Mehreen",
                "donor_email": "arzu@example.com",
                "donor_phone": "9876543210",  # <-- Add example value
                "amount": 50000,  # 500 INR
                "campaign_id": "64f7c8f5a2b3d5c8e4f1d2a1",  # <-- Add example value
                "currency": "INR",  # <-- Add example value
                "provider": "razorpay"  # <-- Add example value
            }
        }


# -------------------------
# Donation Init Response
# -------------------------
class DonationInitResponse(BaseModel):
    donation_id: str
    provider: Optional[str] = None
    razorpay_order_id: Optional[str] = None
    razorpay_key_id: Optional[str] = None
    client_secret: Optional[str] = None
    amount: Optional[int] = None
    currency: Optional[str] = None

    class Config:
        json_schema_extra = {
            "example": {
                "donation_id": "64f7c8f5a2b3d5c8e4f1d2a1",
                "provider": "razorpay",
                "razorpay_order_id": "order_9A33XWu170gUtm",
                "razorpay_key_id": "rzp_test_xxxxxxxx",
                "client_secret": None,
                "amount": 50000,
                "currency": "INR"
            }
        }


# -------------------------
# Donation Verify Request
# -------------------------
class DonationVerifyRequest(BaseModel):
    donation_id: str
    order_id: str
    payment_id: str
    signature: str

class DonationVerifyResponse(BaseModel):
    status: str
    donation_id: str
    payment_id: str

class Donation(BaseModel):
    donor: str
    amount: float
    campaign: str
    date: datetime
