from pydantic import BaseModel, Field, validator
from typing import List, Optional
from datetime import datetime
from bson import ObjectId  # Add this import to fix the error

# ---------- Emergency Contact Models ----------
class EmergencyContactCreate(BaseModel):
    name: str
    phone: str
    relation: str

class EmergencyContactOut(BaseModel):
    name: str
    phone: str
    relation: str

# ---------- Safe Zone Models ----------
class SafeZoneCreate(BaseModel):
    name: str
    address: str
    lat: float
    lng: float

class SafeZoneOut(BaseModel):
    name: str
    address: str
    lat: float
    lng: float

# ---------- Family Member Models ----------
class FamilyMemberCreate(BaseModel):
    email: str
    role: str = "viewer"  # viewer, admin

class FamilyMemberOut(BaseModel):
    email: str
    role: str

# ---------- Safety Profile Models ----------
class SafetyProfileCreate(BaseModel):
    emergency_contacts: List[EmergencyContactCreate] = []
    safe_zones: List[SafeZoneCreate] = []
    family_visibility: bool = True
    family_members: List[FamilyMemberCreate] = []

class SafetyProfileUpdate(BaseModel):
    emergency_contacts: Optional[List[EmergencyContactCreate]] = None
    safe_zones: Optional[List[SafeZoneCreate]] = None
    is_active: Optional[bool] = None
    family_visibility: Optional[bool] = None
    admin_visibility: Optional[bool] = None
    family_members: Optional[List[FamilyMemberCreate]] = None

class SafetyProfileOut(BaseModel):
    id: str
    user_id: str
    emergency_contacts: List[dict]
    safe_zones: List[dict]
    is_active: bool
    family_visibility: bool
    admin_visibility: bool
    family_members: List[dict]
    created_at: datetime
    updated_at: Optional[datetime] = None
    
    @validator('updated_at', pre=True, always=True)
    def set_updated_at(cls, v, values):
        # If updated_at is None, set it to created_at
        if v is None and 'created_at' in values:
            return values['created_at']
        return v

# ---------- Safety Task Models ----------
class TaskCreate(BaseModel):
    description: str
    due_time: Optional[datetime] = Field(default_factory=datetime.now)
    visible_to_family: bool = True
    visible_to_admin: bool = True

class TaskUpdate(BaseModel):
    description: Optional[str] = None
    due_time: Optional[datetime] = None
    visible_to_family: Optional[bool] = None
    visible_to_admin: Optional[bool] = None
    completed: Optional[bool] = None
    status: Optional[str] = None

class TaskResponse(BaseModel):
    id: str
    description: str
    due_time: datetime
    completed: bool = False
    missed: bool = False
    visible_to_family: bool = True
    visible_to_admin: bool = True
    completed_at: Optional[datetime] = None
    completed_by: Optional[str] = None
    
    class Config:
        json_encoders = {
            ObjectId: str,
            datetime: lambda dt: dt.isoformat() if dt else None
        }
        
    @validator('completed_at', 'completed_by', pre=True)
    def ensure_completion_fields(cls, value, values):
        # If task is marked as completed but these fields are None, set default values
        if values.get('completed') and value is None:
            if 'completed_at' in values.field_names:
                return datetime.now()
            if 'completed_by' in values.field_names:
                return "system"
        return value

# ---------- SOS Models ----------
class GeoLocation(BaseModel):
    lat: float
    lng: float
    address: Optional[str] = None
    name: Optional[str] = None

class SOSCreate(BaseModel):
    message: str
    location: Optional[GeoLocation] = None
    geo_lat: Optional[float] = 0
    geo_lng: Optional[float] = 0
    triggered_at: Optional[datetime] = None
    
    @validator('location', pre=True)
    def validate_location(cls, value):
        # If location is a dict with additionalProps, convert to GeoLocation format
        if isinstance(value, dict):
            if any(key.startswith('additionalProp') for key in value.keys()):
                # Extract actual geo data from request if available
                return None
            
            # If it has lat/lng already, it's properly formatted
            if 'lat' in value and 'lng' in value:
                return value
                
        return value

class SOSResponse(BaseModel):
    id: str
    message: str
    location: Optional[GeoLocation] = None
    triggered_at: datetime
    resolved: bool = False
    resolved_at: Optional[datetime] = None
    resolved_by: Optional[str] = None
    visible_to_family: bool = True
    visible_to_admin: bool = True
    notified_contacts: int = 0
    geo_lat: Optional[float] = 0
    geo_lng: Optional[float] = 0
