from pydantic import BaseModel, EmailStr, Field, HttpUrl
from typing import List, Optional, Union
from datetime import datetime
# ------------------- Educator -------------------

class SkillGuruRegister(BaseModel):
    name: str 
    email: EmailStr
    password: str
    expertise: Optional[List[str]] = []
    bio: Optional[str] 
    achievements: Optional[List[str]] = []
    profile_image: Optional[str] = None
    social_links: Optional[dict] = {}


class SkillGuruLogin(BaseModel):
    email: EmailStr
    password: str

class SkillGuruOut(BaseModel):
    id: str
    name: str
    email: EmailStr
    expertise: Optional[List[str]] = None
    bio: Optional[str] = None
    achievements: Optional[List[dict]] = None
    created_at: Optional[datetime] = None

# ------------------- Quiz -------------------


class Question(BaseModel):
    question: str
    options: List[str]
    correct_answer: str

class CreateQuiz(BaseModel):
    content_id: str
    questions: List[Question]


class EnrollmentRequest(BaseModel):
    content_id: str
# ------------------- Enrollment -------------------

class EnrollmentOut(BaseModel):
    id: str
    learner_id: str
    learner_name: str
    content_id: str
    progress_percent: float


# ------------------- Auth / Me -------------------

class CurrentUserOut(BaseModel):
    user_id: str
    email: EmailStr
    role: str
    message: str

class LearnerRegister(BaseModel):
    name: str
    email: EmailStr
    password: str

class LearnerLogin(BaseModel):
    email: EmailStr
    password: str

class LearnerOut(BaseModel):
    id: str
    name: str
    email: EmailStr


# ------------------- Course -------------------
class ContentCreate(BaseModel):
    title: str
    video_url: Optional[str] 


# ------------------- Enrollment -------------------

class EnrollRequest(BaseModel):
    course_id: str
    learner_id: str

class Enrollment(BaseModel):
    course_id: str
    learner_id: str
    enrolled_at: Optional[datetime] = None
    progress_percent: float = 0.0

class EnrollmentOut(BaseModel):
    id: str
    course_id: str
    learner_id: str
    progress_percent: float


# ------------------- Quiz -------------------

# --------- Quiz Schemas ----------
class Question(BaseModel):
    question: str
    options: List[str]
    correct_answer: str

class QuizCreate(BaseModel):
    course_id: str
    questions: List[Question]

class QuizAnswer(BaseModel):
    question_id: str
    selected_option: Union[str, int]

class SubmitQuizRequest(BaseModel):
    quiz_id: str
    answers: List[QuizAnswer]
    score: int


# ------------------- Quiz Result -------------------

class QuizSubmission(BaseModel):
    course_id: str
    learner_id: str
    answers: dict

class QuizResultOut(BaseModel):
    score: int
    badge_awarded: bool


# ------------------- Certificate -------------------

class CertificateOut(BaseModel):
    certificate_url: str



# ------- Progress Tracker ----------
class Progress(BaseModel):
    learner_id: str
    course_id: str
    progress_percent: float
    completed_at: Optional[datetime]

# --------- Badge / Certificate ----------
class Achievement(BaseModel):
    learner_id: str
    course_id: str
    badge: str
    certificate_url: Optional[str]
    awarded_at: datetime

# --------- Q&A ----------
class QA(BaseModel):
    course_id: str
    learner_id: str
    question: str
    answer: Optional[str]
    created_at: datetime
    answered_at: Optional[datetime]


class EnrollRequest(BaseModel):
    content_id: str = Field(..., description="ID of the content to enroll in")

# Schema (Data Model)
# Schema (Data Model)
class LiveSession(BaseModel):
    id: str
    title: str
    platform_link: HttpUrl
    created_at: datetime

class LiveSessionCreate(BaseModel):
    title: str
    platform_link: HttpUrl
