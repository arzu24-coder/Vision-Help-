from pydantic import BaseModel, Field, validator
from typing import Optional, List, Dict, Any
from datetime import datetime

class FAQCreate(BaseModel):
    question: str
    answer: str
    category: str
    video_url: Optional[str] = None
    
    # Add validators to ensure data is properly formatted
    @validator('question', 'answer', 'category')
    def not_empty(cls, v):
        if not v or not v.strip():
            raise ValueError('Cannot be empty or just whitespace')
        return v.strip()
    
    @validator('video_url')
    def validate_url(cls, v):
        if v is None:
            return None
        v = v.strip()
        if not v:
            return None
        # Basic URL validation
        if not (v.startswith('http://') or v.startswith('https://')):
            v = f"https://{v}"
        return v

class FAQUpdate(BaseModel):
    question: Optional[str] = None
    answer: Optional[str] = None
    category: Optional[str] = None
    video_url: Optional[str] = None
    approved: Optional[bool] = None

class FAQResponse(BaseModel):
    id: str
    question: str
    answer: str
    category: str
    video_url: Optional[str] = None
    approved: bool = True
    created_at: datetime
    updated_at: Optional[datetime] = None

class FAQListResponse(BaseModel):
    total: int
    faqs: List[FAQResponse]
    categories: List[str]

class ChatRequest(BaseModel):
    user_id: str
    query: str

class ChatResponse(BaseModel):
    answer: str = "No answer available"  # Default value to prevent null
    source: str = "system"
    confidence: float = 0.0
    faq_id: Optional[str] = None
    video_url: Optional[str] = None
    suggested: bool = True
    
    class Config:
        schema_extra = {
            "example": {
                "answer": "Vision Help is a non-profit organization focused on community welfare.",
                "source": "faq",
                "confidence": 0.92,
                "faq_id": "60d21b4c67d0d8992e610c31",
                "suggested": False
            }
        }

class AIQuery(BaseModel):
    query: str
    user_id: str
    previous_context: Optional[List[Dict[str, Any]]] = None

class AISuggestion(BaseModel):
    query: str
    answer: str
    suggested_category: str
    user_id: str
    created_at: datetime = Field(default_factory=datetime.now)
    reviewed: bool = False
    
class SearchQuery(BaseModel):
    q: str
    category: Optional[str] = None
    limit: int = 10