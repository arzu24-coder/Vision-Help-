from pydantic import BaseModel
from typing import Literal, Optional, List

class MediaUpload(BaseModel):
    description: str
    media_url: str
    region: Optional[str] = None
    content_type: Optional[Literal["article", "video", "image", "document", "other"]] = "other"
    tags: Optional[List[str]] = []

class MediaReview(BaseModel):
    action: Literal["approve", "reject", "flag", "in_review"]
    feedback: Optional[str] = None
    accuracy_check: Optional[bool] = True
    appropriateness_check: Optional[bool] = True
    relevance_check: Optional[bool] = True
    moderation_notes: Optional[str] = None
