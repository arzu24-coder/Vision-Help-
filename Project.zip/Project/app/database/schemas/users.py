from pydantic import BaseModel, EmailStr
from typing import Optional

class UserCreate(BaseModel):
    first_name: str
    last_name: str
    role: Optional[str] = "user"   # default role if not provided
    phone: str
    email: EmailStr
    website: Optional[str] = None
    profile_photo: Optional[str] = None  # can store image URL or file path
    password: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserOut(BaseModel):
    id: str
    email: EmailStr
    username: str
    is_active: Optional[bool] = True

    model_config = {"from_attributes": True}


