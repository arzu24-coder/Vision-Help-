from pydantic import BaseModel, HttpUrl
from typing import Optional, List, Literal
from datetime import datetime


# Used when admin adds a manual entry
class CreateHonorEntry(BaseModel):
    user_id: str
    name: str
    role: Literal["learner", "educator", "admin", "mentor", "top contributor"]
    description: Optional[str] = None
    region: Optional[str] = None
    contribution_type: Optional[str] = None
    certificate_url: Optional[HttpUrl] = None
    badge_url: Optional[HttpUrl] = None
    timestamp: Optional[datetime] = None


# Used when filtering honor board (GET /honor-board?region=...&role=...)
class FilterHonorBoard(BaseModel):
    region: Optional[str]
    role: Optional[str]
    contribution_type: Optional[str]


# Used to define a contribution made by a user
class ContributionCreate(BaseModel):
    user_id: str
    name: str
    role: Literal["learner", "educator", "mentor"]
    region: Optional[str]
    description: Optional[str]
    contribution_type: Literal["course", "webinar", "article", "community_help"]
    timestamp: Optional[datetime] = None


# Used for outputting honor board or weekly result
class ContributionOut(BaseModel):
    id: Optional[str]  # MongoDB ObjectId as str
    user_id: str
    name: str
    role: str
    description: Optional[str]
    region: Optional[str]
    contribution_type: Optional[str]
    certificate_url: Optional[HttpUrl]
    badge_url: Optional[HttpUrl]
    timestamp: Optional[datetime]
