from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List, Union
from datetime import date, datetime

class RegisterSchema(BaseModel):
    name: str
    email: EmailStr
    password: str
    is_employer: bool

class RegisterOut(BaseModel):
    id: str
    name: str
    email: EmailStr
    is_employer: bool
    verified: bool

class RegistrationResponse(BaseModel):
    message: str
    id: str

class LoginSchema(BaseModel):
    email: EmailStr
    password: str

class JobPostRequest(BaseModel):
    title: str
    description: str
    requirements: list[str]
    location: str
    salary_range: str
    job_type: str
    skills_required: list[str]
    experience_level: str
    application_deadline: datetime
    is_active: bool
    salary_range: Union[str, dict]
    is_remote: Optional[bool] = None
    company_name: str
    company_description: str

class JobBase(BaseModel):
    companyName: str
    location: str
    title: str
    description: str
    salary: str
    qualification: str
    jobType: str
    experience: str
    skills: list[str]    # accepts an array
    benefits: str
    class Config:
        allow_population_by_field_name = True  # Allow using both aliases and field names

class ApplyJobSchema(BaseModel):
    job_id: str

class RatingSchema(BaseModel):
    job_id: Optional[str]
    score: int
    review: Optional[str]

class VolunteerProjectCreate(BaseModel):
    title: str
    description: str
    location: str
    start_date: date
    end_date: date
    volunteers_needed: int
    skills_required: List[str]
    category: str
    status: str = "open"

class VolunteerProjectOut(VolunteerProjectCreate):
    id: str
    volunteers_joined: int = 0
    project_link: str


class ResumeUploadSchema(BaseModel):
    name: str
    email: str
    phone_number: str
    skill: str
    location: str
    experience: str
    brief_bio: str
    education: str
    

class ProjectCreate(BaseModel):
    title: str
    description: str