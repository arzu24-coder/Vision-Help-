# app/database/schemas/vision_user.py
from fastapi import  UploadFile, File
from pydantic import BaseModel, EmailStr, validator
from typing import ClassVar, Literal, Optional


class VisionUserCreate(BaseModel):
    first_name: str
    last_name: Optional[str] = ""
    email: EmailStr
    phone_number: str
    location: str
    password: str
    confirm_password: str
    role: Optional[Literal["Career Seeker", "Vision Marshal", "Career Supporter", "Skill Guru", "Skill Learner", "Admin"]] = None

    @validator('role')
    def validate_role(cls, v, values):
        if v == "Admin" and values.get('email') != "arzumehreen050@gmail.com":
            raise ValueError("Admin role is reserved for super admin only")
        return v

    @validator('confirm_password')
    def passwords_match(cls, v, values, **kwargs):
        if 'password' in values and v != values['password']:
            raise ValueError('Passwords do not match')
        return v
    
    @validator('phone_number')
    def validate_phone(cls, v):
        # Basic phone validation - you can make this more sophisticated
        if len(v) < 10:
            raise ValueError('Phone number must be at least 10 digits')
        return v
    
    @validator('first_name')
    def validate_first_name(cls, v):
        if len(v.strip()) < 2:
            raise ValueError('First name must be at least 2 characters')
        return v.strip()
    
    @validator('last_name')
    def validate_last_name(cls, v):
        if v and len(v.strip()) < 2:
            raise ValueError('Last name must be at least 2 characters')
        return v.strip() if v else ""

    model_config = {"from_attributes": True}

    # Add property to get full name
    @property
    def full_name(self) -> str:
        if self.last_name:
            return f"{self.first_name} {self.last_name}"
        return self.first_name

class VisionUserResponse(BaseModel):
    id: str
    first_name: str
    last_name: Optional[str] = ""
    email: EmailStr
    phone_number: str
    location: str
    role: Optional[Literal["Career Seeker", "Vision Marshal", "Career Supporter", "Skill Guru", "Skill Learner", "Admin"]] = None
    ID: str
    qr_code_base64: str



class LoginRequest(BaseModel):
    email: str
    password: str

class ForgotPasswordRequest(BaseModel):
    email: EmailStr

from pydantic import BaseModel, EmailStr

class VerifyOTPRequest(BaseModel):
    otp: str

class ResetPasswordRequest(BaseModel):
    new_password: str
    confirm_password: str

class User(BaseModel):
    email: EmailStr
    password_hash: str

class IDCardRequest(BaseModel):
    vision_id: str
    first_name: str
    last_name: str
    role: str
    phone: str
    email: str
    website: Optional[str] = None