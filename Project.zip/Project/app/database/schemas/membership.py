from pydantic import BaseModel, Field
from typing import Optional, Literal, List, Dict, Any
from datetime import datetime
import uuid


class PaymentMethod(BaseModel):
    method: Literal["wallet", "direct_payment", "bank_transfer", "credit_card"]
    transaction_id: Optional[str] = None
    details: Optional[dict] = None

class MembershipPlan(BaseModel):
    plan_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    role: str
    price: float
    duration_days: int
    benefits: List[str]
    description: Optional[str] = None
    is_popular: bool = False
    discount_percent: Optional[float] = 0
    impact: Optional[str] = None

class MembershipSubscription(BaseModel):
    user_id: str
    plan_id: str
    role: str
    start_date: datetime = Field(default_factory=datetime.utcnow)
    end_date: Optional[datetime] = None
    is_active: bool = True
    payment_info: Dict[str, Any]
    price_paid: float
    auto_renew: bool = False

class MembershipRequest(BaseModel):
    user_id: Optional[str] = None  # Added missing user_id field
    role: str
    sub_role: Optional[str] = None  # Added missing sub_role field
    membership_plan: str | None = None
    # Campaign donation fields
    campaign_id: Optional[str] = None
    donor_name: Optional[str] = None
    donor_email: Optional[str] = None
    donor_phone: Optional[str] = None
    amount: Optional[float] = None
    donation_type: Optional[str] = None