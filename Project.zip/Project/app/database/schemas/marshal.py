from pydantic import BaseModel, Field, EmailStr
from typing import Optional, Literal, List, Union, Dict, Any
from datetime import datetime
from enum import Enum
from fastapi import Form, Depends

# Marshal Signup Schema
class MarshalSignup(BaseModel):
    full_name: str 
    email: EmailStr
    phone_number: str 
    location: str 
    password: str
    confirm_password: str
    role: str

class MarshalLogin(BaseModel):
    email: EmailStr
    password: str

class MarshalOut(BaseModel):
    id: str
    full_name: str
    email: EmailStr
    phone_number: str
    location: str
    role: str
    is_active: bool = True
    created_at: datetime

class StoryUpload(BaseModel):
    title: str
    description: str
    category: str
    location: str
    media_url: Optional[str] = None  # URL/path to uploaded file


class StoryCreate(StoryUpload):
    pass

class StoryOut(StoryUpload):
    id: str

class BadgeInfo(BaseModel):
    user_id: str
    username: str
    email: EmailStr
    stories_uploaded: int
    badge: str

class BadgeResponse(BaseModel):
    badges: List[BadgeInfo]

class MarshalIDResponse(BaseModel):
    id: str
    name: str
    area: str
    qr_code_base64: str

class ReferralInput(BaseModel):
    name: str
    phone: str
    referred_by: Optional[str] = None

class QRCodeUpdate(BaseModel):
    qr_code_base64: str

class NotificationCreate(BaseModel):
    recipient: EmailStr
    type: str = "tag"  # or "certificate", "badge", etc.
    message: str
    link: str  # link to the story or related item
    created_at: datetime = datetime.utcnow()
    is_read: bool = False

# Request schema
class IDCardRequest(BaseModel):
    vision_id: str
    first_name: str
    last_name: str
    role: str
    phone: str
    email: str
    website: Optional[str] = None

class ReportIssueBase(BaseModel):
    title: str
    description: str
    location: str
    issue_category: str   # Infrastructure, Healthcare, Education, Environment, Safety, Utilities
    severity_level: Optional[str] = "Medium"  # Low, Medium, High, Critical
    local_issues: str  # Changed from List[str] to str for FormData compatibility
    tagged_emails: Optional[str] = ""
    local_authorities: Optional[str] = ""

class ReportIssueResponse(BaseModel):
    success: bool
    message: str
    issue_id: str
    report_id: str
    issue_data: Dict[str, Any]

class GetSummaryRequest(BaseModel):
    action: Literal["get_summary"] = "get_summary"
    location_filter: Optional[str] = "all"
    category_filter: Optional[str] = "all"
    severity_filter: Optional[str] = "all"
    time_period: Optional[str] = "30"  # or "all"
    limit: Optional[int] = 50


# ==== RESPONSE SCHEMAS ====

class NotificationData(BaseModel):
    total_sent: int
    tagged_users: int
    authorities: int
    platforms_used: List[str]


class TrackingData(BaseModel):
    reported_at: str
    status: str
    follow_up_required: bool


class FiltersApplied(BaseModel):
    location: str
    category: str
    severity: str
    time_period_days: str
    limit: int


class StatisticsData(BaseModel):
    total_issues: int
    trend_percentage: float
    trend_direction: str
    categories_affected: int
    locations_affected: int


class GetSummaryResponse(BaseModel):
    action: str
    success: bool
    summary_type: str
    filters_applied: FiltersApplied
    statistics: StatisticsData
    category_breakdown: list
    location_breakdown: list
    most_common_issues: list
    recent_reports: list
    insights: dict
    generated_at: datetime


# ==== UNION TYPE FOR FASTAPI ====

LocalIssuesRequest = Union[ReportIssueBase, GetSummaryRequest]
LocalIssuesResponse = Union[ReportIssueResponse, GetSummaryResponse]

class MarshalKitRequest(BaseModel):
    action: Literal["generate_id", "get_badges", "get_profile_kit"]
    marshal_name: Optional[str] = None
    marshal_location: Optional[str] = "Unknown"
    marshal_phone: Optional[str] = None

# Gamification request schemas
class GamificationRequest(BaseModel):
    action: Literal["award_points", "get_profile", "get_leaderboard"]
    activity_type: Optional[Literal["report_issue", "resolve_task", "spread_awareness"]] = None
    reference_id: Optional[str] = None
    limit: Optional[int] = 20

# Local work request schemas  
class LocalWorkRequest(BaseModel):
    action: Literal["assign", "update_status"]
    issue_id: Optional[str] = None  # For assign action
    task_id: Optional[str] = None   # For update_status action
    work_status: Optional[Literal["in_progress", "resolved"]] = None  # For update_status action

# Profile schemas
class ProfileBase(BaseModel):
    fullName: str
    email: EmailStr
    phone: Optional[str] = None
    location: Optional[str] = None
    skills_qualification: Optional[str] = None

class ProfileCreate(ProfileBase):
    pass

class ProfileResponse(ProfileBase):
    id: str

