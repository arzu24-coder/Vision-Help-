from pydantic import BaseModel, EmailStr
from typing import Optional
from typing import Literal

class ChangeUserRoleRequest(BaseModel):
    user_email: EmailStr
    new_role: str

# Request schema
class UserSearchRequest(BaseModel):
    query: str
    platform: Optional[str] = "all"


class DeleteUserRequest(BaseModel):
    user_email: EmailStr
    platform: Literal["skill_share", "career_connect", "vision_platform"]

class ChangeUserRoleRequest(BaseModel):
    user_email: EmailStr
    new_role: str