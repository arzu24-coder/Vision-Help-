from pydantic import BaseModel, EmailStr
from typing import Optional, Dict, Any
from datetime import datetime

class CertificateGenerate(BaseModel):
    certificate_type: str = "contribution_based"
    custom_message: Optional[str] = None

class ContributionSummary(BaseModel):
    media_uploads: int = 0
    applications: int = 0
    donations: int = 0
    support_activities: int = 0
    total_score: int = 0
    total_amount: Optional[float] = None

class CertificateOut(BaseModel):
    certificate_id: str
    user_email: EmailStr
    user_name: str
    user_role: str
    contributions: ContributionSummary
    issued_date: datetime
    certificate_type: str
    email_sent: bool

class BulkCertificateRequest(BaseModel):
    role_filter: Optional[str] = None
    min_score: int = 10
    send_email: bool = True

class CertificateStats(BaseModel):
    total_certificates: int
    certificates_by_role: Dict[str, int]
    recent_certificates: int
    email_success_rate: float
