from pydantic import BaseModel
from datetime import datetime
from enum import Enum
from typing import List, Dict, Any, Optional

class HeatmapZoneType(str, Enum):
    CRITICAL = "critical"     # Bright red - urgent needs
    HIGH = "high"             # Orange - high activity
    MEDIUM = "medium"         # Yellow - moderate activity
    IMPROVED = "improved"     # Light green - recently improved
    STABLE = "stable"         # Dark green - stable area

class HeatmapZone(BaseModel):
    zone_id: str
    name: str
    latitude: float
    longitude: float
    intensity: float  # 0.0 to 1.0 representing intensity of activity
    zone_type: HeatmapZoneType
    issues_count: int
    resolved_count: int
    resolution_rate: float
    active_marshals: int
    last_updated: datetime

class StoryCategory(str, Enum):
    CLEANUP = "cleanup"
    EDUCATION = "education"
    HEALTH = "health"
    INFRASTRUCTURE = "infrastructure"
    EMPLOYMENT = "employment"
    SANITATION = "sanitation"
    WATER = "water"
    COMMUNITY = "community"
    OTHER = "other"

class StoryMedia(BaseModel):
    media_type: str  # image, video, before_after
    url: str
    thumbnail_url: Optional[str] = None
    caption: Optional[str] = None

class SuccessStory(BaseModel):
    story_id: str
    title: str
    description: str
    location: Dict[str, Any]  # Contains name, latitude, longitude
    media: List[StoryMedia]
    category: StoryCategory
    created_at: datetime
    created_by: Dict[str, Any]  # Contains user_id, name, role
    metrics: Optional[Dict[str, Any]] = None  # Optional impact metrics
    reactions: Optional[Dict[str, int]] = None  # Optional reaction counts
