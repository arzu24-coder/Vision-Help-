# app/database/models/users.py
from bson import ObjectId
from typing import Optional
from pydantic import BaseModel, EmailStr, Field
from datetime import datetime

class PyObjectId(ObjectId):
    @classmethod
    def __get_validators__(cls):
        yield cls.validate

    @classmethod
    def validate(cls, v):
        if not ObjectId.is_valid(v):
            raise ValueError("Invalid ObjectId")
        return ObjectId(v)

    @classmethod
    def __get_pydantic_json_schema__(cls, core_schema, handler):
        return {"type": "string"}

class UserDB(BaseModel):
    id: Optional[PyObjectId] = Field(alias="_id", default=None)
    username: str
    email: EmailStr
    password: str
    is_active: bool

    model_config = {
        "populate_by_name": True,
        "json_encoders": {ObjectId: str}
    }

