from typing import Optional, List
from pydantic import BaseModel, Field, EmailStr
from bson import ObjectId

# Custom ObjectId support
class PyObjectId(ObjectId):
    @classmethod
    def __get_validators__(cls):
        yield cls.validate
    @classmethod
    def validate(cls, v):
        if not ObjectId.is_valid(v):
            raise ValueError("Invalid ObjectId")
        return ObjectId(v)
    @classmethod
    def __modify_schema__(cls, field_schema):
        field_schema.update(type="string")

# Story Model
class StoryModel(BaseModel):
    id: Optional[PyObjectId] = Field(alias="_id")
    title: str
    description: str
    category: Optional[str]
    location: Optional[str]
    author: EmailStr
    tags: Optional[List[str]] = []

    model_config = {
        "arbitrary_types_allowed": True,
        "json_encoders": {ObjectId: str}
    }



# Marshal (User) Model
class MarshalModel(BaseModel):
    id: Optional[PyObjectId] = Field(alias="_id")
    name: str
    email: EmailStr
    area: str
    qr_code: Optional[str]  # base64 QR

    model_config = {
        "arbitrary_types_allowed": True,
        "json_encoders": {ObjectId: str}
    }

# Referral Model
class ReferralModel(BaseModel):
    id: Optional[PyObjectId] = Field(alias="_id")
    name: str
    phone: str
    referred_by: Optional[str]

    model_config = {
        "arbitrary_types_allowed": True,
        "json_encoders": {ObjectId: str}
    }
