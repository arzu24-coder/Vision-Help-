from pydantic import BaseModel, Field, HttpUrl
from typing import Optional, List
from datetime import datetime
from bson import ObjectId
from typing import Optional

class PyObjectId(ObjectId):
    @classmethod
    def __get_validators__(cls):
        yield cls.validate
    
    @classmethod
    def validate(cls, v):
        if not ObjectId.is_valid(v):
            raise ValueError("Invalid ObjectId")
        return ObjectId(v)

    @classmethod
    def __get_pydantic_json_schema__(cls, core_schema, handler):
        return {"type": "string"}
from datetime import datetime
from typing import Optional, Literal, Any
from pydantic import BaseModel

class DonationModel(BaseModel):
    donor_name: str
    donor_email: str
    donor_phone: Optional[str] = None
    amount: float
    currency: str = "INR"
    campaign_id: str
    provider: Literal["razorpay", "stripe"]
    status: Literal["PENDING", "SUCCESS", "FAILED", "REFUNDED"] = "PENDING"
    provider_order_id: Optional[str] = None     # Razorpay order / Stripe PI id
    provider_payment_id: Optional[str] = None   # Razorpay payment id
    receipt_no: Optional[str] = None
    event_id: Optional[str] = None              # idempotency for webhooks
    created_at: datetime = datetime.utcnow()
    updated_at: datetime = datetime.utcnow()
