from bson import ObjectId
from pydantic import BaseModel, Field
from typing import Optional, List, Dict
from datetime import datetime


# Support for MongoDB ObjectId
class PyObjectId(ObjectId):
    @classmethod
    def __get_validators__(cls):
        yield cls.validate
    
    @classmethod
    def validate(cls, v):
        if not ObjectId.is_valid(v):
            raise ValueError("Invalid ObjectId")
        return ObjectId(v)

    @classmethod
    def __get_pydantic_json_schema__(cls, core_schema, handler):
        return {"type": "string"}


# ---------- Nested Emergency Contact ----------
class EmergencyContact(BaseModel):
    name: str
    phone: str
    relation: str


# ---------- Nested Safe Zone ----------
class SafeZone(BaseModel):
    name: str
    address: str
    lat: float
    lng: float


# ---------- Nested Family Member ----------
class FamilyMember(BaseModel):
    email: str
    role: str = "viewer"  # viewer, admin


# ---------- Main Safety Profile ----------
class SafetyProfileDB(BaseModel):
    id: Optional[PyObjectId] = Field(default_factory=PyObjectId, alias="_id")
    user_id: str = Field(..., description="Reference to Vision User ID")
    emergency_contacts: List[EmergencyContact] = []
    safe_zones: List[SafeZone] = []
    is_active: bool = True
    family_visibility: bool = True  # Controls if family members can see this profile
    admin_visibility: bool = True   # Controls if admins can see this profile
    family_members: List[FamilyMember] = []  # List of family members who can access this profile
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    model_config = {
        "populate_by_name": True,
        "json_encoders": {ObjectId: str}
    }


# -------- Safety Task (DB Model) --------
class SafetyTaskDB(BaseModel):
    id: Optional[PyObjectId] = Field(default_factory=PyObjectId, alias="_id")
    user_id: str
    task_name: str
    geo_lat: Optional[float] = None
    geo_lng: Optional[float] = None
    status: str = "pending"  # pending, completed, missed

    model_config = {
        "populate_by_name": True,
        "json_encoders": {ObjectId: str}
    }


# -------- Safety SOS (DB Model) --------
class SafetySOSDB(BaseModel):
    id: Optional[PyObjectId] = Field(default_factory=PyObjectId, alias="_id")
    user_id: str
    message: str = "SOS Emergency Triggered!"
    geo_lat: Optional[float] = None
    geo_lng: Optional[float] = None
    resolved: bool = False

    model_config = {
        "populate_by_name": True,
        "json_encoders": {ObjectId: str}
    }
