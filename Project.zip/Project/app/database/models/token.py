from bson import ObjectId
from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class TokenDB(BaseModel):
    id: ObjectId = Field(default_factory=ObjectId, alias="_id")
    user_id: str
    token: str
    created_at: Optional[datetime] = Field(default_factory=datetime.utcnow)

    model_config = {
        "arbitrary_types_allowed": True,
        "json_encoders": {ObjectId: str}
    }
