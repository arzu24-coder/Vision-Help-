from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime
from bson import ObjectId
from pydantic import BaseModel, EmailStr


# Utility class to support ObjectId in Pydantic
class PyObjectId(ObjectId):
    @classmethod
    def __get_validators__(cls):
        yield cls.validate
    @classmethod
    def validate(cls, v):
        if not ObjectId.is_valid(v):
            raise ValueError("Invalid ObjectId")
        return ObjectId(v)


# ------------------- Educator & Learner Users -------------------

class Learner(BaseModel):
    id: Optional[str] = Field(alias="_id")
    name: str
    email: EmailStr
    hashed_password: str
    badges: list[str] = []
    enrolled_classes: list[str] = []
    is_active: bool = True

    model_config = {
        "populate_by_name": True,
        "json_encoders": {ObjectId: str}
    }

# ------------------- Course -------------------

class Course(BaseModel):
    id: Optional[str] = Field(alias="_id")
    title: str
    description: str
    educator_id: str  # reference to educator
    tags: List[str]
    created_at: datetime = Field(default_factory=datetime.utcnow)
# ------------------- Enrollment -------------------

class Enrollment(BaseModel):
    id: Optional[PyObjectId] = Field(alias="_id")
    course_id: PyObjectId
    learner_id: PyObjectId
    enrolled_at: datetime = Field(default_factory=datetime.utcnow)
    progress_percent: float = 0.0


# ------------------- Quiz -------------------

class QuizQuestion(BaseModel):
    question: str
    options: List[str]
    correct_answer: str

class Quiz(BaseModel):
    id: Optional[PyObjectId] = Field(alias="_id")
    course_id: PyObjectId
    questions: List[QuizQuestion]
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ------------------- Quiz Result -------------------

class QuizResult(BaseModel):
    id: Optional[PyObjectId] = Field(alias="_id")
    learner_id: PyObjectId
    course_id: PyObjectId
    score: int
    submitted_at: datetime = Field(default_factory=datetime.utcnow)
    badge_awarded: bool = False


# ------------------- Certificate -------------------

class Achievement(BaseModel):
    learner_id: str
    course_id: str
    badge: str
    certificate_url: Optional[str]
    awarded_at: datetime


# ------------------- Q&A -------------------

class QuestionAnswer(BaseModel):
    id: Optional[PyObjectId] = Field(alias="_id")
    course_id: PyObjectId
    learner_id: PyObjectId
    question: str
    answer: Optional[str] = None
    asked_at: datetime = Field(default_factory=datetime.utcnow)

progress_model = {
    "learner_id": str,
    "course_id": str,
    "progress_percent": float,
    "completed_at": Optional[datetime]
}