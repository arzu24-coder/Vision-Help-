from fastapi import FastAPI, UploadFile, HTTPExceptionfrom fastapi.responses import JSONResponsefrom bson import ObjectIdfrom fastapi.encoders import jsonable_encoderapp = FastAPI()# Helper function to convert MongoDB documentsdef serialize_mongo_document(document):    if isinstance(document, dict):        for key, value in document.items():            if isinstance(value, ObjectId):                document[key] = str(value)    return document@app.post("/career/upload-resume")
async def upload_resume(file: UploadFile):
    try:
        # Simulate saving the file and returning a MongoDB document
        saved_document = {
            "_id": ObjectId(),
            "filename": file.filename,
            "status": "uploaded"
        }

        # Serialize the MongoDB document
        serialized_document = serialize_mongo_document(saved_document)

        # Use jsonable_encoder to ensure proper serialization
        json_compatible_data = jsonable_encoder(serialized_document)
        return JSONResponse(content=json_compatible_data)

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
