from bson import ObjectId
from pydantic import BaseModel, Field, EmailStr, HttpUrl
from typing import Optional, List, Literal
from datetime import datetime

class PyObjectId(ObjectId):
    @classmethod
    def __get_validators__(cls):
        yield cls.validate

    @classmethod
    def validate(cls, value, info):
        if not isinstance(value, (ObjectId, str)):
            raise TypeError('ObjectId required')
        if isinstance(value, str):
            try:
                value = ObjectId(value)
            except Exception as e:
                raise ValueError("Invalid ObjectId") from e
        return value

    @classmethod
    def __get_pydantic_json_schema__(cls, core_schema, handler):
        return {"type": "string"}

class User(BaseModel):
    id: str
    name: str
    email: EmailStr
    password: str
    is_employer: bool = False
    verified: bool = False
    resume_url: Optional[str] = None
    skills: List[str] = []
    created_at: datetime = datetime.utcnow()

class JobBaseModel(BaseModel):
    id: Optional[PyObjectId] = Field(alias="_id", default=None)
    
    class Config:
        arbitrary_types_allowed = True
        populate_by_name = True
        json_encoders = {ObjectId: str}

class JobPostModel(JobBaseModel):
    title: str = Field(..., min_length=3)
    description: str = Field(..., min_length=10)
    job_type: Literal["task", "job"] = Field(default="task")
    status: Literal["open", "in-progress", "completed", "cancelled"] = Field(default="open")
    payment_type: Literal["fixed", "hourly"]

    skills_required: list[str] = Field(default_factory=list)
    deadline: Optional[datetime] = None
    posted_by: str
    assigned_to: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: Optional[datetime] = None
    region: str
    is_remote: bool = Field(default=True)
    applications: list[dict] = Field(default_factory=list)
    views_count: int = Field(default=0)
    total_applications: int = Field(default=0)
    application_deadline: Optional[datetime] = None
    experience_required: Optional[float] = None
    salary_range: Optional[dict] = Field(default_factory=lambda: {"min": 0, "max": 0})
    required_documents: List[str] = Field(default_factory=list)
    company_name: str
    company_logo: Optional[str] = None
    qualifications_required: List[str] = Field(default_factory=list)
    benefits: List[str] = Field(default_factory=list)
    is_featured: bool = False

class Application(BaseModel):
    id: str
    user_id: str
    job_id: str
    status: str = "applied"
    applied_at: datetime = datetime.utcnow()

class Rating(BaseModel):
    id: str
    user_id: str
    job_id: Optional[str] = None
    score: int
    review: Optional[str]

class VolunteerProject(BaseModel):
    id: str
    title: str
    description: str
    skills_required: List[str]
    posted_by: str
    applicants: List[str] = []
    created_at: datetime = datetime.utcnow()

class JobApplicationRequest(BaseModel):
    cover_letter: str
    experience_years: Optional[int] = 0
    current_company: Optional[str] = None
    resume_url: Optional[str] = None
    expected_salary: Optional[int] = None
    relevant_skills: Optional[List[str]] = None
    notice_period: Optional[int] = None

    class Config:
        json_schema_extra = {
            "example": {
                "cover_letter": "I am interested in this position because...",
                "experience_years": 2,
                "current_company": "Current Company Name",
                "resume_url": "http://example.com/resume.pdf",
                "expected_salary": 75000,
                "relevant_skills": ["Python", "FastAPI", "MongoDB"],
                "notice_period": 30
            }
        }

class JobModel(BaseModel):
    id: str = Field(default_factory=lambda: str(ObjectId()), alias="_id")
    companyName: str
    location: str
    title: str
    description: str
    salary: str
    qualification: str
    jobType: str
    experience: str
    skills: str
    benefits: str

    class Config:
        allow_population_by_field_name = True
        arbitrary_types_allowed = True
        json_encoders = {
            ObjectId: str
        }
        
class JobApplicationResponse(BaseModel):
    application_id: str
    job_title: str
    company_name: str
    applied_date: datetime
    status: str = "pending"
    application_status: str = "completed"

    class Config:
        from_attributes = True

class JobResponse(BaseModel):
    id: str
    title: str
    status: str
    created_at: datetime

    class Config:
        from_attributes = True

class JobPostResponse(BaseModel):
    id: Optional[str] = Field(None, alias="_id")
    title: str
    description: str
    company_name: Optional[str] = None
    status: str
    posted_by: str
    created_at: datetime
    job_type: str
    location: str
    is_remote: bool = False
    salary_range: Optional[dict] = None
    applications_count: int = 0
    views_count: int = 0

    class Config:
        populate_by_name = True
        json_encoders = {ObjectId: str}
    applications_count: int = 0
    views_count: int = 0

    class Config:
        populate_by_name = True
        json_encoders = {ObjectId: str}
