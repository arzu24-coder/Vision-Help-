# app/database/models/vision_user.py

from bson import ObjectId
from pydantic import BaseModel, Field, EmailStr
from typing import Optional, Literal


class PyObjectId(ObjectId):
    @classmethod
    def __get_validators__(cls):
        yield cls.validate
    
    @classmethod
    def validate(cls, v):
        if not ObjectId.is_valid(v):
            raise ValueError("Invalid ObjectId")
        return ObjectId(v)

    @classmethod
    def __get_pydantic_json_schema__(cls, core_schema, handler):
        return {"type": "string"}


class VisionUserDB(BaseModel):
    id: Optional[PyObjectId] = Field(default_factory=PyObjectId, alias="_id")
    username: str
    email: EmailStr
    role: Literal["Vision Marshal", "Career Seeker", "Supporter", "Donor"]
    ID: str
    qr_code_base64: str  # Store QR image as base64
    is_active: bool = True

    model_config = {
        "populate_by_name": True,
        "json_encoders": {ObjectId: str}
    }
