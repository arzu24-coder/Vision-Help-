from datetime import datetime
from pydantic import BaseModel, Field
from typing import Literal

from bson import ObjectId
from pydantic import BaseModel, Field, EmailStr
from typing import Optional, Literal


class PyObjectId(ObjectId):
    @classmethod
    def __get_validators__(cls):
        yield cls.validate
    
    @classmethod
    def validate(cls, v):
        if not ObjectId.is_valid(v):
            raise ValueError("Invalid ObjectId")
        return ObjectId(v)

    @classmethod
    def __get_pydantic_json_schema__(cls, core_schema, handler):
        return {"type": "string"}

class HonorBoardEntry(BaseModel):
    id: Optional[str] = Field(default_factory=str)
    user_id: str
    role: str  # "learner" or "educator"
    contribution_type: str  # "quiz", "course", "answers", etc.
    region: Optional[str]
    badge: Optional[str]
    certificate_url: Optional[str]
    week: str  # e.g., "2025-W31"
    created_at: datetime = Field(default_factory=datetime.utcnow)