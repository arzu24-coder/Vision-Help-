from pydantic import BaseModel, Field
from typing import Optional
from bson import ObjectId
from datetime import datetime

# Updated PyObjectId for Pydantic v2 compatibility
class PyObjectId(ObjectId):
    @classmethod
    def __get_validators__(cls):
        # Legacy support - this is no longer used in Pydantic v2
        # but keeping for backward compatibility with other code
        yield cls.validate

    @classmethod
    def validate(cls, v):
        if not ObjectId.is_valid(v):
            raise ValueError("Invalid ObjectId")
        return ObjectId(v)
    
    # New method for Pydantic v2 validation
    @classmethod
    def __get_pydantic_core_schema__(cls, _source_type, _handler):
        from pydantic_core import core_schema
        return core_schema.union_schema([
            # First try to validate as ObjectId
            core_schema.is_instance_schema(ObjectId),
            # If that fails, try to convert from str to ObjectId
            core_schema.chain_schema([
                core_schema.str_schema(),
                core_schema.no_info_plain_validator_function(cls.validate)
            ])
        ])
    
    # New method for Pydantic v2 JSON schema generation
    @classmethod
    def __get_pydantic_json_schema__(
        cls, __core_schema, __field_schema, __model_schema
    ) -> None:
        # Update the JSON schema to indicate this is a string type
        __field_schema.update(type="string", format="objectid")


class FAQ(BaseModel):
    id: Optional[PyObjectId] = Field(default_factory=PyObjectId, alias="_id")
    question: str
    answer: str
    category: str
    video_url: Optional[str] = None
    approved: bool = True
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = None
    
    # Updated model config for Pydantic v2
    model_config = {
        "populate_by_name": True,
        "arbitrary_types_allowed": True,
        "json_encoders": {ObjectId: str}
    }
