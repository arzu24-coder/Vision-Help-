from datetime import datetime
from typing import Optional, List, Dict, Any
from bson import ObjectId

class Project:
    def __init__(
        self,
        name: str,
        description: str,
        region: str,
        budget: float = 0,
        budget_utilized: float = 0,
        status: str = "planning",
        beneficiaries: int = 0,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        project_type: str = "general",
        team_members: List[Dict[str, Any]] = None,
        created_at: Optional[datetime] = None,
        updated_at: Optional[datetime] = None,
        tags: List[str] = None,
        metrics: Dict[str, Any] = None,
        **kwargs
    ):
        self.name = name
        self.description = description
        self.region = region
        self.budget = budget
        self.budget_utilized = budget_utilized
        self.status = status
        self.beneficiaries = beneficiaries
        self.start_date = start_date or datetime.utcnow()
        self.end_date = end_date
        self.project_type = project_type
        self.team_members = team_members or []
        self.created_at = created_at or datetime.utcnow()
        self.updated_at = updated_at or datetime.utcnow()
        self.tags = tags or []
        self.metrics = metrics or {}
        self._id = kwargs.get('_id', ObjectId())

    def to_dict(self):
        return {
            "_id": self._id,
            "name": self.name,
            "description": self.description,
            "region": self.region,
            "budget": self.budget,
            "budget_utilized": self.budget_utilized,
            "status": self.status,
            "beneficiaries": self.beneficiaries,
            "start_date": self.start_date,
            "end_date": self.end_date,
            "project_type": self.project_type,
            "team_members": self.team_members,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "tags": self.tags,
            "metrics": self.metrics
        }

    @classmethod
    def from_dict(cls, data):
        return cls(**data)
